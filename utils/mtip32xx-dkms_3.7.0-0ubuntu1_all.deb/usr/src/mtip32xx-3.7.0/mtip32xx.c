/*
 * Driver for the Micron P320/P420 family of SSDs
 *   Copyright (C) 2013 Micron Technology, Inc.
 *
 * Portions of this code were derived from works subjected to the
 * following copyright:
 *    Copyright (C) 2009 Integrated Device Technology, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/ata.h>
#include <linux/delay.h>
#include <linux/hdreg.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/smp.h>
#include <linux/compat.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/genhd.h>
#include <linux/bio.h>
#include <linux/dma-mapping.h>
#include <linux/idr.h>
#include <linux/kthread.h>
#include <linux/fs.h>
#include <linux/blkdev.h>
#include <linux/debugfs.h>
#include <linux/buffer_head.h>
#include <linux/vmalloc.h>
#include "mtip32xx.h"
#if (LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 32) && \
    ((defined(RHEL_MAJOR) && RHEL_MAJOR == 6)       && \
     (defined(RHEL_MINOR) && RHEL_MINOR != 0))      || \
    LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37))
	#include <linux/pci-aspm.h>
#endif

/* Needs to be defined before extra.c is included */
int mtip_simple_open(struct inode *inode, struct file *file)
{
	file->private_data = inode->i_private;
	return 0;
}

#include "extra.c"

/* DMA region containing RX Fis, Identify, RLE10, and SMART buffers */
#define AHCI_RX_FIS_SZ          0x100
#define AHCI_RX_FIS_OFFSET      0x0
#define AHCI_IDFY_SZ            ATA_SECT_SIZE
#define AHCI_IDFY_OFFSET        0x400
#define AHCI_SECTBUF_SZ         ATA_SECT_SIZE
#define AHCI_SECTBUF_OFFSET     0x800
#define AHCI_SMARTBUF_SZ        ATA_SECT_SIZE
#define AHCI_SMARTBUF_OFFSET    0xC00
/* 0x100 + 0x200 + 0x200 + 0x200 is smaller than 4k but we pad it out */
#define BLOCK_DMA_ALLOC_SZ      4096

/* DMA region containing command table (should be 8192 bytes) */
#define AHCI_CMD_SLOT_SZ        sizeof(struct mtip_cmd_hdr)
#define AHCI_CMD_TBL_SZ         (MTIP_MAX_COMMAND_SLOTS * AHCI_CMD_SLOT_SZ)
#define AHCI_CMD_TBL_OFFSET     0x0

/* DMA region per command (contains header and SGL) */
#define AHCI_CMD_TBL_HDR_SZ     0x80
#define AHCI_CMD_TBL_HDR_OFFSET 0x0
#define AHCI_CMD_TBL_SGL_SZ     (MTIP_MAX_SG * sizeof(struct mtip_cmd_sg))
#define AHCI_CMD_TBL_SGL_OFFSET AHCI_CMD_TBL_HDR_SZ
#define CMD_DMA_ALLOC_SZ        (AHCI_CMD_TBL_SGL_SZ + AHCI_CMD_TBL_HDR_SZ)

#define HOST_CAP_NZDMA		(1 << 19)
#define HOST_HSORG		0xFC
#define HSORG_DISABLE_SLOTGRP_INTR (1 << 24)
#define HSORG_DISABLE_SLOTGRP_PXIS (1 << 16)
#define HSORG_HWREV		0xFF00
#define HSORG_STYLE		0x8
#define HSORG_SLOTGROUPS	0x7

#define PORT_COMMAND_ISSUE	0x38
#define PORT_SDBV		0x7C

#define PORT_OFFSET		0x100
#define PORT_MEM_SIZE		0x80

#define PORT_IRQ_ERR \
	(PORT_IRQ_HBUS_ERR | PORT_IRQ_IF_ERR | PORT_IRQ_CONNECT | \
	 PORT_IRQ_PHYRDY | PORT_IRQ_UNK_FIS | PORT_IRQ_BAD_PMP | \
	 PORT_IRQ_TF_ERR | PORT_IRQ_HBUS_DATA_ERR | PORT_IRQ_IF_NONFATAL | \
	 PORT_IRQ_OVERFLOW)
#define PORT_IRQ_LEGACY \
	(PORT_IRQ_PIOS_FIS | PORT_IRQ_D2H_REG_FIS)
#define PORT_IRQ_HANDLED \
	(PORT_IRQ_SDB_FIS | PORT_IRQ_LEGACY | \
	 PORT_IRQ_TF_ERR | PORT_IRQ_IF_ERR | \
	 PORT_IRQ_CONNECT | PORT_IRQ_PHYRDY)
#define DEF_PORT_IRQ \
	(PORT_IRQ_ERR | PORT_IRQ_LEGACY | PORT_IRQ_SDB_FIS)

/* product numbers */
#define MTIP_PRODUCT_UNKNOWN	0x00
#define MTIP_PRODUCT_ASICFPGA	0x11

/* Device instance number, incremented each time a device is probed. */
static int instance;
spinlock_t orphan_lock;

/* CPU use counts for load balancing */
static int cpu_use[NR_CPUS];
static int next_node;

/*
 * Global variable used to hold the major block device number
 * allocated in mtip_init().
 */
int mtip_major;
static struct dentry *dfs_parent;

static DEFINE_SPINLOCK(rssd_index_lock);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
 static DEFINE_IDA(rssd_index_ida);
#else
 static DEFINE_IDR(rssd_index_ida);
#endif

#ifndef fuaflag
 #define fuaflag		0
#endif

#ifndef mod_timer_pinned
 #define mod_timer_pinned(a, b)	mod_timer(a, b)
#endif

#ifndef add_timer_on
 #define add_timer_on(a, b)	add_timer(a)
#endif

/* define driver interface choice */
static int queue_mode;
module_param(queue_mode, int, 0644);
MODULE_PARM_DESC(queue_mode, "Selection of block stack interface.\n"
	"\t\t\t0 = make_request()\n\t\t\t1 = request queue  ");
static DEFINE_PER_CPU(int, pcpu_queue_mode);

/* # of cores to distribute completion work */
#define MTIP_COMP_CORES_DEFAULT 3
static int comp_cores = MTIP_COMP_CORES_DEFAULT;
module_param(comp_cores, int, 0644);
MODULE_PARM_DESC(comp_cores, "Number of cores to distribute completion work across.\n"
	"\t\t\tValid Range: [1 - 8], Default: " __stringify(MTIP_COMP_CORES_DEFAULT) "  ");

/* define how driver assigns devices to nodes */
static int numa_mode __read_mostly;
module_param(numa_mode, int, 0644);
MODULE_PARM_DESC(numa_mode, "How driver binds device contexts to NUMA nodes.\n"
	"\t\t\t0 = round robin\n\t\t\t1 = proximity based\n"
	"\t\t\t2 = follows probe cpu\n\t\t\t3 = follow dev_to_node()");

#ifdef MAX_NUMNODES
	#define MTIP_MAX_NUMA_NODES   MAX_NUMNODES
#else
	#define MTIP_MAX_NUMA_NODES   32
#endif

static int mtip_block_initialize(struct driver_data *dd);
static inline void release_slot(struct mtip_port *port, int tag);
static void mtip_async_complete(struct mtip_port *port,	int tag, void *data,
								int status);
static int mtip_read_log_page(struct mtip_port *port, u8 page, u16 *buffer,
				dma_addr_t buffer_dma, unsigned int sectors);
static int mtip_get_smart_attr(struct mtip_port *port, unsigned int id,
						struct smart_attr *attrib);
static void mtip_free_orphans(void);
static int mtip_complete_req(struct request *req, int status);

#ifdef CONFIG_COMPAT
struct mtip_compat_ide_task_request_s {
	__u8		io_ports[8];
	__u8		hob_ports[8];
	ide_reg_valid_t	out_flags;
	ide_reg_valid_t	in_flags;
	int		data_phase;
	int		req_cmd;
	compat_ulong_t	out_size;
	compat_ulong_t	in_size;
};
#endif

/* Helper functions for per-cpu test/set operations */
static inline void mtip_set_bit(u32 bit, unsigned long __percpu *pcpu)
{
	int i;
	unsigned long __percpu *flags = per_cpu_ptr(pcpu, smp_processor_id());
	set_bit(bit, flags);

	for_each_possible_cpu(i) {
		*per_cpu_ptr(pcpu, i) = *flags;
	}
}

static inline void mtip_clear_bit(u32 bit, unsigned long __percpu *pcpu)
{
	int i;
	unsigned long __percpu *flags = per_cpu_ptr(pcpu, smp_processor_id());
	clear_bit(bit, flags);

	for_each_possible_cpu(i) {
		*per_cpu_ptr(pcpu, i) = *flags;
	}
}

inline int mtip_test_bit(u32 bit, unsigned long __percpu *pcpu)
{
	return test_bit(bit, this_cpu_ptr(pcpu));
}

static int mtip_clear_ci(struct mtip_port *port)
{
	int i, rv = 0;
	u32 ci;
	for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++) {
		spin_lock(&port->cmd_issue_lock[i]);
		ci = readl(port->cmd_issue[i]);
		if (ci) {
			writel(ci, port->cmd_issue[i]);
			if (readl(port->cmd_issue[i]) != 0)
				rv = -1;
		}
		spin_unlock(&port->cmd_issue_lock[i]);
	}
	return rv;
}

static inline int mtip_count_nodes(void)
{
	int cpu, num_nodes = 0;
	/* Count nodes */
	for_each_online_cpu(cpu)
		if (cpu_to_node(cpu) > num_nodes)
			num_nodes++;
	return num_nodes + 1;
}

static void drop_cpu(int cpu)
{
	if (cpu_use[cpu])
		cpu_use[cpu]--;
}

static int get_least_used_cpu_on_node(int node)
{
	int cpu, least_used_cpu, least_cnt;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	const struct cpumask *node_mask;
	node_mask = cpumask_of_node(node);
	least_used_cpu = cpumask_first(node_mask);
#else
	int first_used_cpu = 0;
	least_used_cpu = 0;
#endif
	least_cnt = cpu_use[least_used_cpu];
	cpu = least_used_cpu;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	for_each_cpu(cpu, node_mask) {
#else
	for_each_online_cpu(cpu) {
		if (cpu_to_node(cpu) == node) {
			if (!first_used_cpu) {
				least_used_cpu = cpu;
				least_cnt = cpu_use[least_used_cpu];
				first_used_cpu = 1;
			}
#endif
			if (cpu_use[cpu] < least_cnt) {
				least_used_cpu = cpu;
				least_cnt = cpu_use[cpu];
			}
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 29)
		}
#endif
	}
	cpu_use[least_used_cpu]++;
	return least_used_cpu;
}

/* Helper for discontiguous nodes in round robin mode */
static int get_next_rr_node(int max)
{
	int i, node;

	for (i = 0, node = 0; i < MTIP_MAX_NUMA_NODES; i++) {
		node = next_node;
		next_node++;
		next_node %= max;
		if (nr_cpus_node(node) > 0)
			return node;
	}
	WARN_ON(nr_cpus_node(node) == 0);
	return 0;
}

/* Get the list of cpus on the node */
static void get_cpu_list(int node, char *list, int len)
{
	int cpu, j = 0;
	memset(list, 0, len);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	{
		const struct cpumask *node_mask = cpumask_of_node(node);
		for_each_cpu(cpu, node_mask) {
			snprintf(&list[j], len - j, "%d ", cpu);
			j = strlen(list);
		}
	}
#else
	for_each_online_cpu(cpu) {
		if (cpu_to_node(cpu) == node) {
			snprintf(&list[j], len - j, "%d ", cpu);
			j = strlen(list);
		}
	}
#endif
}

static void mtip_log_bindings(struct driver_data *dd)
{
	int i, j, cpu;
	char cpu_list[256];

	/* Log the bindings */
	for_each_online_cpu(cpu) {
		memset(cpu_list, 0, sizeof(cpu_list));

		for (i = 0, j = 0; i < MTIP_MAX_SLOT_GROUPS; i++) {
			if (dd->work[i].cpu_binding == cpu) {
				snprintf(&cpu_list[j], 256 - j, "%d ", i);
				j = strlen(cpu_list);
			}
		}
		if (j)
			dbg_printk("CPU %d: WQs %s\n", cpu, cpu_list);
	}
}

static int mtip_device_unaligned_constrained(struct driver_data *dd)
{
	switch (dd->pdev->device) {
	case P420M_DEVICE_ID:
	case P322H_DEVICE_ID:
		return 1;
	default:
		return 0;
	}
}

static int mtip_decode_flags(unsigned long __percpu *pcpu, char *buf, int len)
{
	int i, j;

	memset(buf, 0, len);
	for (i = 0, j = 0; i < MTIP_DDF_LAST_BIT; i++) {
		if (mtip_test_bit(i, pcpu)) {
			snprintf(&buf[j], len - j, "%s ", mtip_flag_str[i]);
			j = strlen(buf);
		}
	}
	return j;
}

/*
 * This function mtip_check_surprise_removal is called
 * while card is removed from the system and it will
 * read the vendor id from the configration space
 *
 * @dd Pointer to the driver_data structure
 *
 * return value
 *	 true if device removed, else false
 */
static bool mtip_check_surprise_removal(struct driver_data *dd)
{
	u16 vendor_id = 0;
	struct pci_dev *pdev = dd->pdev;

	if (mtip_test_bit(MTIP_DDF_SR_BIT, dd->flags)) {
		return true; /* device removed */
	} else {
		/* Read the vendorID from the configuration space */
		pci_read_config_word(pdev, 0x00, &vendor_id);
		if (vendor_id == 0xFFFF ||
			readl(dd->mmio + HOST_VERSION) == 0xffffffff) {
			mtip_set_bit(MTIP_DDF_SR_BIT, dd->flags);
			return true; /* device removed */
		}
	}

	return false; /* device present */
}

/*
 * This function is called for clean the pending command in the
 * command slot during the surprise removal of device and return
 * error to the upper layer.
 *
 * @dd        Pointer to the driver_data structure.
 * @max_iters Max number of times to walk the tagmap.
 *
 * return value
 *	None
 */
static void mtip_command_cleanup(struct driver_data *dd, int max_iters)
{
	int i, iters = 0, tag = 0;
	int allocated, active;
	unsigned int num_cmd_slots = MTIP_MAX_COMMAND_SLOTS;
	struct mtip_cmd *cmd;
	struct mtip_port *port = dd->port;
	static int in_progress;

	if (in_progress)
		return;

	in_progress = 1;

	/* Cleanup internal commands */
	cmd = &port->commands[MTIP_TAG_INTERNAL];
	if (atomic_read(&cmd->active)) {
		if ((readl(dd->port->cmd_issue[MTIP_TAG_INTERNAL]) &
					(1 << MTIP_TAG_INTERNAL)) &&
						cmd->comp_func) {
			/* Make callback */
			cmd->comp_func(dd->port,
					MTIP_TAG_INTERNAL,
					cmd->comp_data,
					-ENODEV);
			mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
				"Reported -ENODEV for internal cmd.\n");
		}
	}

	for (iters = 0; iters < max_iters; iters++) {
		allocated = 0;
		active = 0;
		
		for (i = 0, tag = 1; i < num_cmd_slots; i++) {
			
			tag = find_next_bit(port->allocated, num_cmd_slots,
									tag);
			if (tag < num_cmd_slots) {
				allocated++;
				cmd = &port->commands[tag];
				if (atomic_read(&cmd->active)) {
					atomic_set(&cmd->active, 0);
					active++;

					mtip_async_complete(port, tag, dd,
								-ENODEV);
				}
			} else
				break;
		}

		if (allocated == 0)
			break;

		/* Give some time for blocked IOs to get submitted */
		msleep(1);
	}

	in_progress = 0;
}

/*
 * Obtain an empty command slot.
 *
 * This function needs to be reentrant since it could be called
 * at the same time on multiple CPUs. The allocation of the
 * command slot must be atomic.
 *
 * @port Pointer to the port data structure.
 *
 * return value
 *	>= 0	Index of command slot obtained.
 *	-1	No command slots available.
 */
static int get_slot(struct mtip_port *port)
{
	int slot, i;

	/*
	 * Try 1000 times, because there is a small race here.
	 *  that's ok, because it's still cheaper than a lock.
	 *
	 * Race: Since this section is not protected by lock, same bit
	 * could be chosen by different process contexts running in
	 * different processor. So instead of costly lock, we are going
	 * with loop.
	 */
	for (i = 0; i < 1000; i++) {
		slot = find_next_zero_bit(port->allocated,
					 MTIP_MAX_COMMAND_SLOTS, 1);
		if ((slot < MTIP_MAX_COMMAND_SLOTS) &&
		    (!test_and_set_bit(slot, port->allocated))) {
			prefetch(port->commands[slot].sg);
			return slot;
		}
	}
	
	dev_warn(&port->dd->pdev->dev, "Failed to get a tag.\n");
	
	return -1;
}

/*
 * Release a command slot.
 *
 * @port Pointer to the port data structure.
 * @tag  Tag of command to release
 *
 * return value
 *	None
 */
static inline void release_slot(struct mtip_port *port, int tag)
{
	if (tag >= 0) {
		smp_mb__before_clear_bit();
		clear_bit(tag, port->allocated);
		smp_mb__after_clear_bit();
	}
}

/*
 * Reset the HBA
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0	The reset was successful.
 *	-1	The HBA Reset bit did not clear.
 */
static int mtip_hba_reset(struct driver_data *dd)
{
	unsigned long timeout;

	/* Set the reset bit */
	writel(HOST_RESET, dd->mmio + HOST_CTL);

	/* Flush */
	readl(dd->mmio + HOST_CTL);

	/*
	 * Spin for up to 10 seconds waiting for reset acknowledgement
	 * Spec is 1 sec but in LUN failure conditions, up to 10 secs are required
	 */
	timeout = jiffies + msecs_to_jiffies(10000);
	do {
		msleep(10);
		if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
			return -1;

	} while ((readl(dd->mmio + HOST_CTL) & HOST_RESET) &&
		  time_before(jiffies, timeout));

	if (readl(dd->mmio + HOST_CTL) & HOST_RESET)
		return -1;

	return 0;
}

/*
 * Issue Com Reset
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 * 	0  The reset was successful.
 * 	-1 The reset bit did not clear.
 */
static int mtip_com_reset(struct driver_data *dd)
{
	struct mtip_port *port = dd->port;
	unsigned long timeout;
	int i;

	/* Set PxSCTL.DET */
	writel(readl(port->mmio + PORT_SCR_CTL) | 1, port->mmio + PORT_SCR_CTL);
	readl(port->mmio + PORT_SCR_CTL);

	/* Wait at least 1 ms */
	for (i = 0; i < 100; i++) {
		cpu_relax();
		udelay(10);
	}

	/* Clear PxSCTL.DET */
	writel(readl(port->mmio + PORT_SCR_CTL) & ~1,
				port->mmio + PORT_SCR_CTL);
	readl(port->mmio + PORT_SCR_CTL);

	/* Wait for bit 0 of PORT_SCR_STS to be set */
	timeout = jiffies + msecs_to_jiffies(500);
	while (((readl(port->mmio + PORT_SCR_STAT) & 0x01) == 0) &&
		time_before(jiffies, timeout)) {

		if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
			return -1;

		cpu_relax();
		msleep(100);
	}

	if ((readl(port->mmio + PORT_SCR_STAT) & 0x01) == 0) {
		dev_warn(&dd->pdev->dev,
			"Timeout waiting for PxSSTS:0 to set.\n");
		return -1;
	}
	return 0;
}

/*
 * Issue a command to the hardware.
 *
 * Set the appropriate bit in the s_active and Command Issue hardware
 * registers, causing hardware command processing to begin.
 *
 * @port Pointer to the port structure.
 * @tag  The tag of the command to be issued.
 *
 * return value
 *      None
 */
static inline void mtip_issue_ncq_command(struct mtip_port *port, int tag)
{
	port->commands[tag].issue_time = jiffies;

	/* Set the command's timeout value */
	port->commands[tag].comp_time = jiffies +
			msecs_to_jiffies(MTIP_NCQ_COMMAND_TIMEOUT_MS);

	atomic_set(&port->commands[tag].active, 1);

	spin_lock(&port->cmd_issue_lock[tag >> 5]);
	writel((1 << MTIP_TAG_BIT(tag)),
			port->s_active[MTIP_TAG_INDEX(tag)]);
	writel((1 << MTIP_TAG_BIT(tag)),
			port->cmd_issue[MTIP_TAG_INDEX(tag)]);
	spin_unlock(&port->cmd_issue_lock[tag >> 5]);
}

/*
 * Enable/disable the reception of FIS
 *
 * @port   Pointer to the port data structure
 * @enable 1 to enable, 0 to disable
 *
 * return value
 *	Previous state: 1 enabled, 0 disabled
 */
static int mtip_enable_fis(struct mtip_port *port, int enable)
{
	u32 tmp;

	/* enable FIS reception */
	tmp = readl(port->mmio + PORT_CMD);
	if (enable)
		writel(tmp | PORT_CMD_FIS_RX, port->mmio + PORT_CMD);
	else
		writel(tmp & ~PORT_CMD_FIS_RX, port->mmio + PORT_CMD);

	/* Flush */
	readl(port->mmio + PORT_CMD);

	return (((tmp & PORT_CMD_FIS_RX) == PORT_CMD_FIS_RX));
}

/*
 * Enable/disable the DMA engine
 *
 * @port   Pointer to the port data structure
 * @enable 1 to enable, 0 to disable
 *
 * return value
 *	Previous state: 1 enabled, 0 disabled.
 */
static int mtip_enable_engine(struct mtip_port *port, int enable)
{
	u32 tmp;

	/* enable FIS reception */
	tmp = readl(port->mmio + PORT_CMD);
	if (enable)
		writel(tmp | PORT_CMD_START, port->mmio + PORT_CMD);
	else
		writel(tmp & ~PORT_CMD_START, port->mmio + PORT_CMD);

	readl(port->mmio + PORT_CMD);
	return (((tmp & PORT_CMD_START) == PORT_CMD_START));
}

/*
 * Enables the port DMA engine and FIS reception.
 *
 * return value
 *	None
 */
static inline void mtip_start_port(struct mtip_port *port)
{
	/* Enable FIS reception */
	mtip_enable_fis(port, 1);

	/* Enable the DMA engine */
	mtip_enable_engine(port, 1);
}

/*
 * Deinitialize a port by disabling port interrupts, the DMA engine,
 * and FIS reception.
 *
 * @port Pointer to the port structure
 *
 * return value
 *	None
 */
static inline void mtip_deinit_port(struct mtip_port *port)
{
	/* Disable interrupts on this port */
	writel(0, port->mmio + PORT_IRQ_MASK);

	/* Disable the DMA engine */
	mtip_enable_engine(port, 0);

	/* Disable FIS reception */
	mtip_enable_fis(port, 0);
}

/*
 * Initialize a port.
 *
 * This function deinitializes the port by calling mtip_deinit_port() and
 * then initializes it by setting the command header and RX FIS addresses,
 * clearing the SError register and any pending port interrupts before
 * re-enabling the default set of port interrupts.
 *
 * @port Pointer to the port structure.
 *
 * return value
 *	None
 */
static void mtip_init_port(struct mtip_port *port)
{
	int i;
	mtip_deinit_port(port);

	/* Program the command list base and FIS base addresses */
	if (readl(port->dd->mmio + HOST_CAP) & HOST_CAP_64) {
		writel((port->command_list_dma >> 16) >> 16,
			 port->mmio + PORT_LST_ADDR_HI);
		writel((port->rxfis_dma >> 16) >> 16,
			 port->mmio + PORT_FIS_ADDR_HI);
	}

	writel(port->command_list_dma & 0xFFFFFFFF,
			port->mmio + PORT_LST_ADDR);
	writel(port->rxfis_dma & 0xFFFFFFFF, port->mmio + PORT_FIS_ADDR);

	/* Clear SError */
	writel(readl(port->mmio + PORT_SCR_ERR), port->mmio + PORT_SCR_ERR);

	/* reset the completed registers */
	for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++)
		writel(0xFFFFFFFF, port->completed[i]);

	/* Clear any pending interrupts for this port */
	writel(readl(port->mmio + PORT_IRQ_STAT), port->mmio + PORT_IRQ_STAT);

	/* Enable port interrupts */
	writel(DEF_PORT_IRQ, port->mmio + PORT_IRQ_MASK);
}

/*
 * Restart a port
 *
 * @port Pointer to the port data structure.
 *
 * return value
 *	None
 */
static void mtip_restart_port(struct mtip_port *port)
{
	unsigned long timeout;

	/* Disable the DMA engine */
	mtip_enable_engine(port, 0);

	/* Chip quirk: wait up to 500ms for PxCMD.CR == 0 */
	timeout = jiffies + msecs_to_jiffies(500);
	while ((readl(port->mmio + PORT_CMD) & PORT_CMD_LIST_ON)
		 && time_before(jiffies, timeout)) {
		cpu_relax();
	}

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, port->dd->flags))
		return;

	/* Clear SError, the PxSERR.DIAG.x should be set so clear it */
	if (readl(port->mmio + PORT_IRQ_STAT) & PORT_IRQ_CONNECT) {
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
			"  %s: PxSERR.DIAG.x is set\n", __func__);
	}
	writel(readl(port->mmio + PORT_SCR_ERR), port->mmio + PORT_SCR_ERR);

	/* Clear any pending interrupts for this port */
	writel(readl(port->mmio + PORT_IRQ_STAT), port->mmio + PORT_IRQ_STAT);

	/* Clear any pending interrupts on the HBA */
	writel(readl(port->dd->mmio + HOST_IRQ_STAT),
					port->dd->mmio + HOST_IRQ_STAT);

	/*
	 * Chip quirk: escalate to hba reset if
	 * PxCMD.CR not clear after 500 ms
	 */
	if (readl(port->mmio + PORT_CMD) & PORT_CMD_LIST_ON) {
		dev_warn(&port->dd->pdev->dev,
			"  PxCMD.CR not clear, escalating reset\n");

		if (mtip_hba_reset(port->dd))
			dev_err(&port->dd->pdev->dev,
				"  HBA reset escalation failed.\n");
	} else {
		/* dev_warn(&port->dd->pdev->dev, "  Issuing COM reset\n"); */

		if (mtip_com_reset(port->dd))
			dev_warn(&port->dd->pdev->dev,
				"  COM reset failed.\n");
	}
	
	udelay(10);

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, port->dd->flags))
		return;

	mtip_init_port(port);
	mtip_start_port(port);

	/* Clear any pending interrupts for this port */
	writel(readl(port->mmio + PORT_IRQ_STAT), port->mmio + PORT_IRQ_STAT);

	/* Clear any pending interrupts on the HBA */
	writel(readl(port->dd->mmio + HOST_IRQ_STAT),
					port->dd->mmio + HOST_IRQ_STAT);
}

/*
 * Cleanup after command timeout, tfe, etc. (chip errata)
 *
 * @port Point to port structure
 *
 * return value
 *      0       Success
 *      -EFAULT Error
 */
static int mtip_error_cleanup(struct mtip_port *port, char *reason)
{
	int rv = 0;

	if (mtip_check_surprise_removal(port->dd)) {
		dev_warn(&port->dd->pdev->dev,
			"  %s: Skipping HbaReset due to removal\n", 
			reason ? reason : "");
		return 0;
	} else {
		dev_warn(&port->dd->pdev->dev,
			"  %s: Issuing HbaReset ...\n", reason ? reason : "");
	}

	/* Issue HBA reset */
	if (mtip_hba_reset(port->dd) < 0) {
		/* TODO: check bit 19 */
		dev_warn(&port->dd->pdev->dev, "    HbaReset failed.\n");
		rv = -EFAULT;
	}

	mdelay(1);

	mtip_init_port(port);
	mtip_start_port(port);

	/* Set GHC.IE to globally enable interrupts */
	writel(readl(port->dd->mmio + HOST_CTL) | HOST_IRQ_EN, 
						port->dd->mmio + HOST_CTL);

	/* Enable port interrupts */
	writel(DEF_PORT_IRQ, port->mmio + PORT_IRQ_MASK);

	return rv;
}

/*
 * Helper function for tag logging
 */
static void print_tags(struct driver_data *dd,
			char *msg,
			unsigned long *tagbits,
			int cnt)
{
	u32 tagmap[MTIP_MAX_SLOT_GROUPS];
	memcpy(tagmap, tagbits, sizeof(u32) * MTIP_MAX_SLOT_GROUPS);
	dev_warn(&dd->pdev->dev,
		"%s %3d cmd(s): %08x:%08x:%08x:%08x %08x:%08x:%08x:%08x\n",
		msg, cnt, 
		tagmap[7], tagmap[6], tagmap[5], tagmap[4], 
		tagmap[3], tagmap[2], tagmap[1], tagmap[0]);
}

/*
 * Handler for timeout conditions
 *
 * @dd        Pointer to the driver_data structure.
 * @fail_fast Directive to fail timed out IOs as quickly as possible.
 * 		No error recovery steps are taken.
 *
 * return value
 *	Number of timed out commands dispositioned
 */
static int mtip_timeout_handler(struct driver_data *dd, int fail_fast)
{
	struct mtip_port *port;
	struct host_to_dev_fis *fis;
	struct mtip_cmd *cmd;
	int tag, cmdto_cnt = 0, surp = 0, retry_cnt = 0, quiesce = 0;
	int reset_issued = fail_fast ? 1 : 0; /* skip reset in fail fast mode */
	unsigned int bit, group;
	unsigned long reissue[SLOTBITS_IN_LONGS], failed[SLOTBITS_IN_LONGS];

	if (!dd->port)
		return 0;

	port = dd->port;

	/* clear the tag accumulators */
	memset(reissue, 0, SLOTBITS_IN_LONGS * sizeof(long));
	memset(failed, 0, SLOTBITS_IN_LONGS * sizeof(long));

	for (tag = 0; tag < MTIP_MAX_COMMAND_SLOTS; tag++) {
		/*
		 * Skip internal command slot as it has
		 * its own timeout mechanism
		 */
		if (tag == MTIP_TAG_INTERNAL)
			continue;

		if (atomic_read(&port->commands[tag].active) &&
		   (time_after(jiffies, port->commands[tag].comp_time))) {
			group = tag >> 5;
			bit = tag & 0x1F;

			cmd = &port->commands[tag];
			fis = (struct host_to_dev_fis *) cmd->command;
			switch (__get_cpu_var(pcpu_debug_mode)) {
			case MTIP_DBG_MODE_HALT:
				dev_err(&dd->pdev->dev,
					"Debug mode HALT: Crashing system after timeout..\n");
				mtip_set_bit(MTIP_DDF_HALT_BIT, dd->flags);
				BUG();
				break;
			case MTIP_DBG_MODE_QUIESCE:
				if (!quiesce)
					dev_err(&dd->pdev->dev,
						"Debug mode QUIESCE: Quiescing driver ...\n");
				mtip_set_bit(MTIP_DDF_QUIESCE_BIT, dd->flags);
				quiesce = 1;
				break;
			}

			cmdto_cnt++;
			if (cmdto_cnt >= 1) {
				surp = mtip_check_surprise_removal(dd);
				if (surp && cmdto_cnt == 1) /* print once */
					dev_warn(&dd->pdev->dev,
						"%s: surprise removal detected\n",
						__func__);
			}

			/*
			 * Clear the completed bit. This should prevent
			 *  any interrupt handlers from trying to retire
			 *  the command.
			 */
			writel(1 << bit, port->completed[group]);

			/* de-activate */
			atomic_set(&port->commands[tag].active, 0);

			/* disposition IO */
			if (!reset_issued && !surp && !quiesce && !fail_fast) {
				if (mtip_error_cleanup(port, "timeout") == 0)
					reset_issued = 1;
			}

			if (!surp && reset_issued && !quiesce && !fail_fast &&
				(port->commands[tag].retries-- > 0)) {

				/* Safe to reissue */
				set_bit(tag, reissue);
				retry_cnt++;

				/* Queue a re-issue */
				set_bit(tag, port->cmds_to_issue);
				mtip_set_bit(MTIP_DDF_ISSUE_CMDS_BIT,
							port->dd->flags);
				/*
				 * already running in service thread,
				 * no need to wake
				 */

			} else {
				/* Fail back the command */
				set_bit(tag, failed);
				mtip_async_complete(port, tag, dd, -EIO);
			}
		}
	}

	if (cmdto_cnt) {
		if (cmdto_cnt - retry_cnt)
			print_tags(port->dd, "Timeout: failed  ", failed,
							cmdto_cnt - retry_cnt);

		if (retry_cnt)
			print_tags(port->dd, "Timeout: reissued", reissue,
							retry_cnt);
	}

	mtip_clear_bit(MTIP_DDF_TO_ACTIVE_BIT, port->dd->flags);
	atomic_set(&dd->timeout_cnt, 0);
	return cmdto_cnt;
}

/*
 * Called periodically to see if any read/write commands are
 * taking too long to complete.
 *
 * @data Pointer to the driver_data structure.
 *
 * return value
 *      None
 */
static void mtip_timeout_function(unsigned long int data)
{
	struct driver_data *dd = (struct driver_data *) data;
	struct mtip_port *port;
	int tag;

	if (!dd->port)
		return;

	port = dd->port;

	/* Give the resume some breathing room */
	if (mtip_test_bit(MTIP_DDF_RESUME_BIT, dd->flags)) {
		mod_timer_pinned(&port->cmd_timer,
			jiffies + msecs_to_jiffies(60000));
		return;
	}

	/* Stop tracking IOs in HALT mode */
	if (mtip_test_bit(MTIP_DDF_HALT_BIT, dd->flags))
		return;

	/* Walk all tags looking for timeouts */
	for (tag = 0; tag < MTIP_MAX_COMMAND_SLOTS; tag++) {
		/*
		 * Skip internal command slot as it has
		 * its own timeout mechanism
		 */
		if (tag == MTIP_TAG_INTERNAL)
			continue;

		if (atomic_read(&port->commands[tag].active) &&
		    (time_after(jiffies, port->commands[tag].comp_time))) {
			if (atomic_read(&dd->timeout_cnt) <
						MTIP_UNHANDLED_TO_THRESHOLD) {
				dev_warn(&dd->pdev->dev,
					"IO timeout (tag %d): activating handler ...\n",
					tag);
				atomic_inc(&dd->timeout_cnt);
				mtip_set_bit(MTIP_DDF_TO_ACTIVE_BIT, dd->flags);
			} else {
				dev_warn(&dd->pdev->dev,
					"IO timeout (tag %d): recovery thread stuck, handling inline ...\n",
					tag);
				/* Invoke handler directly with fail_fast=1 */
				mtip_timeout_handler(dd, 1);
				atomic_set(&dd->timeout_cnt, 0);
			}
			wake_up_interruptible(&dd->svc_wait);
			break;
		}
	}

	if (port->ic_pause_timer) {
		unsigned long to = port->ic_pause_timer +
						msecs_to_jiffies(1000);
		if (time_after(jiffies, to)) {
			mtip_clear_bit(MTIP_DDF_DM_ACTIVE_BIT, dd->flags);
			mtip_clear_bit(MTIP_DDF_SE_ACTIVE_BIT, dd->flags);
			port->ic_pause_timer = 0;
			wake_up_interruptible(&dd->svc_wait);
		}
	}

	/* Restart the timer */
	mod_timer_pinned(&port->cmd_timer,
		jiffies + msecs_to_jiffies(MTIP_TIMEOUT_CHECK_PERIOD));
}

/*
 * IO completion function.
 *
 * This completion function is called by the driver ISR when a
 * command that was issued by the kernel completes. It first calls the
 * asynchronous completion function which normally calls back into the block
 * layer passing the asynchronous callback data, then unmaps the
 * scatter list associated with the completed command, and finally
 * clears the allocated bit associated with the completed command.
 *
 * @port   Pointer to the port data structure.
 * @tag    Tag of the command.
 * @data   Pointer to driver_data.
 * @status Completion status.
 *
 * return value
 *	None
 */
static void mtip_async_complete(struct mtip_port *port,
				int tag,
				void *data,
				int status)
{
	struct mtip_cmd *cmd = &port->commands[tag];
	struct driver_data *dd = data;
	int unaligned, cb_status = status ? -EIO : 0;
	void (*func)(void *, int);

	prefetch(cmd->async_callback);

	BUG_ON(dd == NULL);

	if (unlikely(status < 0)) {
		struct host_to_dev_fis *fis = cmd->command;
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"Command tag %d failed: %s lba "
			"%02x%02x%02x%02x%02x%02x + %02x%02x\n", tag,
			cmd->direction == DMA_TO_DEVICE ? "W" : "R",
			fis->lba_hi_ex, fis->lba_mid_ex, fis->lba_low_ex,
			fis->lba_hi, fis->lba_mid, fis->lba_low,
			fis->features_ex, fis->features);
	}

	/* Clear active flag */
	atomic_set(&port->commands[tag].active, 0);

	/* Upper layer callback */
	func = cmd->async_callback;
	if (likely(func && cmpxchg(&cmd->async_callback, func, 0) == func)) {

		diskstat_end(dd, cmd);

#ifdef MTIP_DEBUGLOG
		{
			struct bio *bio = (struct bio *) cmd->async_data;
			debuglog_io_complete(dd, cmd, bio_data_dir(bio),
				bio->bi_sector, bio_sectors(bio), bio->bi_rw);
		}
#endif

		func(cmd->async_data, cb_status);
		/* cmd->comp_func = NULL;  ** necessary ?** */
		unaligned = cmd->unaligned;

		/* Unmap the DMA scatter list entries */
		dma_unmap_sg(&dd->pdev->dev,
			cmd->sg,
			cmd->scatter_ents,
			cmd->direction);
		pci_dev_put(dd->pdev);

		/* Clear the allocated bits for the command */
		release_slot(port, tag);

		if (unlikely(unaligned))
			up(&port->cmd_slot_unal);
		else
			up(&port->cmd_slot);
	} else {
		dev_warn(&port->dd->pdev->dev,
			"No callback function for tag %d\n", tag);
	}
}

/*
 * Internal command completion callback function.
 *
 * This function is normally called by the driver ISR when an internal
 * command completed. This function signals the command completion by
 * calling complete().
 *
 * @port   Pointer to the port data structure.
 * @tag    Tag of the command that has completed.
 * @data   Pointer to a completion structure.
 * @status Completion status.
 *
 * return value
 *	None
 */
static void mtip_completion(struct mtip_port *port,
			    int tag,
			    void *data,
			    int status)
{
	struct mtip_cmd *command;
	struct completion *waiting = data;
	struct driver_data *dd = port->dd;

	if (unlikely(!port))
		return;

	command = &port->commands[tag];

	if (unlikely(status < 0)) {
		port->int_cmd_status = port->dd->port_stat;
		port->dd->port_stat = 0;
		WARN_ON(port->int_cmd_status == 0xffffffff); /* SRSI? */

		/* this is normal */
		dbg_printk("Internal command w/tag %d completed "
				"with errors: %08x\n",
				tag, port->int_cmd_status);
	}

	command->async_callback = NULL;
	command->comp_func = NULL;

	if (waiting)
		complete(waiting);
}

static void mtip_null_completion(struct mtip_port *port,
			    int tag,
			    void *data,
			    int status)
{
	return;
}

/*
 * Handle an error.
 *
 * @dd Pointer to the driver_data structure.
 *
 * return value
 *	None
 */
static void mtip_error_handler(struct driver_data *dd)
{
	int group, tag, bit, reissue, rv, failed_tag = 0, quiesce = 0;
	struct mtip_port *port = dd->port;
	struct mtip_cmd *cmd;
	u32 completed, port_stat = dd->port_stat;
	struct host_to_dev_fis *fis;
	unsigned long comp_accum[SLOTBITS_IN_LONGS];
	unsigned long reissue_accum[SLOTBITS_IN_LONGS];
	unsigned long retire_accum[SLOTBITS_IN_LONGS];
	unsigned long fail_accum[SLOTBITS_IN_LONGS];
	unsigned int comp_cnt = 0, reissue_cnt = 0, ret_cnt = 0, fail_cnt = 0;
	u64 failed_lba = 0, failed_cnt = 0;
	u64 raw0, raw1, raw2, raw3, raw4, raw5;
	unsigned char *buf = NULL, failed_cmd = 0;
	char *fail_reason = NULL, *reason = NULL;
	int fail_all_ncq_write = 0, fail_all_ncq_cmds = 0;
	void (*func)(struct mtip_port *, int, void *, int);
	int rle10_valid = 0;

	if (port_stat & PORT_IRQ_TF_ERR)
		reason = "Taskfile error";
	else if (port_stat & PORT_IRQ_IF_ERR)
		reason = "Interface error";
	else
		reason = "Unknown error";

	dev_err(&dd->pdev->dev, "Dispositioning %s ...\n", reason);

	if (mtip_test_bit(MTIP_DDF_IC_ACTIVE_BIT, dd->flags)) {
		cmd = &port->commands[MTIP_TAG_INTERNAL];
		if (atomic_read(&cmd->active)) {
			if (cmd->comp_func) {
				func = cmd->comp_func;
				cmd->comp_func = NULL;
				/* Make callback */
				func(dd->port,
					MTIP_TAG_INTERNAL,
					cmd->comp_data,
					-EIO);
			} else {
				dev_warn(&dd->pdev->dev,
					"No callback for active command!\n");
			}
			/*
			 * just return, internal commands have their own
			 * recovery mechanism
			 */
			return;
		} else {
			/* TODO: decide whether to remove this */
			dev_warn(&dd->pdev->dev,
				"Internal command active? "
				"act %d ci %08x cb %p\n",
				atomic_read(&cmd->active),
				readl(dd->port->cmd_issue[MTIP_TAG_INTERNAL]),
				cmd->comp_func);
		}
	}

	/* clear the tag accumulators */
	memset(comp_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));
	memset(reissue_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));
	memset(retire_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));
	memset(fail_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));

	switch (__get_cpu_var(pcpu_debug_mode))	{
	case MTIP_DBG_MODE_HALT:
		dev_err(&dd->pdev->dev,
			"Debug mode HALT: Crashing system ...\n");
		mtip_set_bit(MTIP_DDF_HALT_BIT, dd->flags);
		BUG();
		break;
	case MTIP_DBG_MODE_QUIESCE:
		dev_err(&dd->pdev->dev,
			"Debug mode QUIESCE: Quiescing driver ...\n");
		mtip_set_bit(MTIP_DDF_QUIESCE_BIT, dd->flags);
		fail_all_ncq_cmds = 1;
		quiesce = 1;
		fail_reason = "quiesced";
		break;
	}
	/* Loop through all the groups */
	for (group = 0; group < MTIP_MAX_SLOT_GROUPS; group++) {

		if (mtip_check_surprise_removal(dd)) {
			dev_err(&port->dd->pdev->dev,
				"Skipping recovery due to removal.\n");
			/* don't proceed further */
			break;
		}

		completed = readl(port->completed[group]);

		/* clear completed status register in the hardware */
		if (completed)
			writel(completed, port->completed[group]);

		/* Process successfully completed commands */
		for (bit = 0; bit < 32 && completed; bit++) {
			if (!(completed & (1 << bit)))
				continue;
			tag = (group << 5) + bit;

			/* Skip the internal command slot */
			if (tag == MTIP_TAG_INTERNAL)
				continue;

			cmd = &port->commands[tag];
			if (likely(cmd->comp_func)) {
				cmd->comp_func(port,
					tag,
					cmd->comp_data,
					0);
				set_bit(tag, comp_accum);
				comp_cnt++;
			} else {
				dev_err(&port->dd->pdev->dev,
					"Missing completion func for tag %d",
					tag);
			}
		}
	}

	/* check device presence */
	if (mtip_check_surprise_removal(dd)) {
		mtip_set_bit(MTIP_DDF_SR_BIT, dd->flags);
		return;
	}
	if (!quiesce)
		/* Restart the port */
		mtip_restart_port(port);

	/* check device presence again */
	if (mtip_check_surprise_removal(dd)) {
		mtip_set_bit(MTIP_DDF_SR_BIT, dd->flags);
		return;
	}

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags) || quiesce) {
		fail_all_ncq_cmds = 1;
	} else {

		/* Trying to determine the cause of the error */
		rv = mtip_read_log_page(dd->port, ATA_LOG_SATA_NCQ,
					dd->port->log_buf,
					dd->port->log_buf_dma, 1);
		if (rv) {

			dev_warn(&dd->pdev->dev,
				"Error in READ LOG EXT (10h) command\n");
			/* non-critical error */
		} else {
			buf = (unsigned char *) dd->port->log_buf;
			failed_tag = buf[258];
			raw0 = buf[4];
			raw1 = buf[5];
			raw2 = buf[6];
			raw3 = buf[8];
			raw4 = buf[9];
			raw5 = buf[10];
			failed_lba = (raw5 << 40 | raw4 << 32 |
					raw3 << 24 | raw2 << 16 | 
					raw1 << 8 | raw0);
			failed_cnt = (buf[13] << 8 | buf[12]);
			failed_cmd = buf[257];
			if (buf[259] & 0x1) {
				dev_info(&dd->pdev->dev,
					"Write protect bit is set.\n");
				mtip_set_bit(MTIP_DDF_WRITE_PROTECT_BIT,
								dd->flags);
				fail_all_ncq_write = 1;
				fail_reason = "write protect";
			}
			if (buf[288] == 0xF7) {
				dev_info(&dd->pdev->dev,
					"Exceeded Tmax, drive in thermal shutdown.\n");
				mtip_set_bit(MTIP_DDF_OVER_TEMP_BIT,
								dd->flags);
				fail_all_ncq_cmds = 1;
				fail_reason = "thermal shutdown";
			}
			if (buf[288] == 0xBF) {
				dev_info(&dd->pdev->dev,
					"Drive indicates rebuild has failed.\n");
				fail_all_ncq_cmds = 1;
				fail_reason = "rebuild failed";
			}
			if (buf[289] == 0xCE) {
				dev_info(&dd->pdev->dev,
					"Drive is undergoing sanitization.\n");
				fail_all_ncq_cmds = 1;
				fail_reason = "sanitize in-progress";
			}
			WARN_ON(failed_tag > 0xff);
			dev_warn(&dd->pdev->dev,
				"RLE reported tag %d failed: %02x %llu + %llu\n",
				failed_tag, failed_cmd,	failed_lba,
				failed_cnt);

			/* Check RLE10 values for validity */
			cmd = &port->commands[failed_tag];
			if (failed_tag != MTIP_TAG_INTERNAL   &&
			    atomic_read(&cmd->active)         && 
			    (failed_cmd == ATA_CMD_FPDMA_READ || 
				failed_cmd == ATA_CMD_FPDMA_WRITE)) {
				rle10_valid = 1;
			}

			mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
				"  ReadLogExt 10h buffer:\n");
			mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
				"  %02x %02x %02x %02x %02x %02x %02x %02x "
				"%02x %02x %02x %02x %02x %02x :: %02x %02x "
				"%02x %02x :: %02x %02x\n",
				buf[0], buf[1], buf[2], buf[3], buf[4],
				buf[5], buf[6], buf[7], buf[8], buf[9],
				buf[10], buf[11], buf[12], buf[13], buf[256],
				buf[257], buf[258], buf[259],
				buf[288], buf[289]);
		}
	}

	/* Loop through all the groups */
	for (group = 0; group < MTIP_MAX_SLOT_GROUPS; group++) {
		for (bit = 0, reissue = 0; bit < 32; bit++) {
			tag = (group << 5) + bit;
			cmd = &port->commands[tag];

			if (mtip_check_surprise_removal(dd))
				return;

			if (tag == MTIP_TAG_INTERNAL)
				continue;

			/* If the active bit is set re-issue the command */
			if (atomic_read(&cmd->active) == 0)
				continue;

			/* Mark inactive */
			atomic_set(&cmd->active, 0);

			fis = (struct host_to_dev_fis *) cmd->command;

			/* Reissue? */
			if (tag == MTIP_TAG_INTERNAL ||
			    fis->command == ATA_CMD_SET_FEATURES ||
			    quiesce) {
				reissue = 0;
			} else {
				if (fail_all_ncq_cmds ||
					(fail_all_ncq_write &&
					fis->command == ATA_CMD_FPDMA_WRITE)) {
					dev_warn(&dd->pdev->dev,
						"  Fail: %s w/tag %d [%s].\n",
						fis->command ==
							ATA_CMD_FPDMA_WRITE ?
							"write" : "read",
						tag,
						fail_reason != NULL ?
						fail_reason : "unknown");
					if (cmd->comp_func) {
						cmd->comp_func(port, tag,
							cmd->comp_data,
							-ENODATA);
						set_bit(tag, fail_accum);
						fail_cnt++;
					}
					continue;
				}
				reissue = 1;
			}

			/*
			 * Adjust retry count if tag was reported by RLE10.
			 *  Assumes MTIP_TAG_INTERNAL uses tag 0
			 */
			if (rle10_valid) {
				/* 
				 * If tag triggered the failure, decrement its 
				 *  retry count only.  This is necessary
				 *  because error injection cases where TFE is
				 *  generated do not cause a tag to get 
				 *  reported by RLE10.
				 */
				if (tag == failed_tag)
					cmd->retries--;
			} else {
				cmd->retries--;
			}

			if (reissue && cmd->retries > 0) {

				set_bit(tag, reissue_accum);
				reissue_cnt++;

				/* dev_warn(&dd->pdev->dev, 
					"Re-queueing IO w/tag %d...\n", tag); */

				/* Re-queue the command */
				set_bit(tag, port->cmds_to_issue);
				mtip_set_bit(MTIP_DDF_ISSUE_CMDS_BIT,
							port->dd->flags);
				/* 
				 * already running in service thread,
				 * no need to wake
				 */
			} else
				reissue = 0;

			if (!reissue) {

				/* Retire the command */
				set_bit(tag, retire_accum);
				ret_cnt++;

				if (cmd->comp_func)
					cmd->comp_func(
						port,
						tag,
						cmd->comp_data,
						-EIO);
				else
					dev_warn(&port->dd->pdev->dev,
						"Unset compfunc for tag %d\n",
						tag);
			}
		}
	}
	
	if (comp_cnt)
		print_tags(dd, "  Completed", comp_accum, comp_cnt);
	if (reissue_cnt)
		print_tags(dd, "  Reissued ", reissue_accum, reissue_cnt);
	if (ret_cnt)
		print_tags(dd, "  Retired  ", retire_accum, ret_cnt);
	if (fail_cnt)
		print_tags(dd, "  Failed   ", fail_accum, fail_cnt);

	if (!quiesce) {
		if (mtip_clear_ci(port) < 0) {
			dev_warn(&dd->pdev->dev,
				"CI failed to clear, restarting port\n");
			mtip_restart_port(port);
		}
	}
}

/*
 * Handle a set device bits interrupt for a particular slot group
 */
static inline void workq_sdbfx(struct mtip_port *port, int group,
							u32 completed)
{
	struct driver_data *dd = port->dd;
	int tag, bit;
	struct mtip_cmd *command;

	if (!completed) {
		/* likely a spurious interrupt during port restart */
		WARN_ON_ONCE(!completed);
		return;
	}

	/* clear completed status register in the hardware */
	writel(completed, port->completed[group]);

	/* Process completed commands */
	for (bit = 0; (bit < 32) && completed; bit++) {
		if (completed & 0x01) {
			tag = (group << 5) | bit;

			/* skip internal command slot */
			if (unlikely(tag == MTIP_TAG_INTERNAL))
				continue;

			command = &port->commands[tag];
			/* make internal callback */
			if (likely(command->comp_func)) {
				command->comp_func(
					port,
					tag,
					command->comp_data,
					0);
			} else {
				if (mtip_check_surprise_removal(dd)) {
					goto exit_sdbfx;
				} else {
					dev_warn(&dd->pdev->dev,
						"Null completion "
						"for tag %d",
						tag);
				}
			}
		}
		completed >>= 1;
	}

exit_sdbfx:
	/* If last, re-enable interrupts */
	if (atomic_dec_return(&dd->irq_workers_active) == 0)
		writel(0xffffffff, dd->mmio + HOST_IRQ_STAT);
}

/* Define completion worker handlers */
DEFINE_HANDLER(0);
DEFINE_HANDLER(1);
DEFINE_HANDLER(2);
DEFINE_HANDLER(3);
DEFINE_HANDLER(4);
DEFINE_HANDLER(5);
DEFINE_HANDLER(6);
DEFINE_HANDLER(7);

/*
 * Process legacy pio and d2h interrupts
 */
static inline void mtip_process_legacy(struct driver_data *dd, u32 port_stat)
{
	struct mtip_port *port = dd->port;
	struct mtip_cmd *cmd = &port->commands[MTIP_TAG_INTERNAL];

	if (mtip_test_bit(MTIP_DDF_IC_ACTIVE_BIT, dd->flags) &&
	    !(readl(port->cmd_issue[MTIP_TAG_INTERNAL])	&
		(1 << MTIP_TAG_INTERNAL))) {
		if (cmd->comp_func) {
			cmd->comp_func(port,
				MTIP_TAG_INTERNAL,
				cmd->comp_data,
				0);
			return;
		} else {
			dev_warn(&dd->pdev->dev,
				"no callback func for internal command\n");
		}
	}

	return;
}

/*
 * Demux and handle errors
 */
static inline void mtip_process_errors(struct driver_data *dd, u32 port_stat)
{
	if (unlikely(port_stat & PORT_IRQ_CONNECT)) {
		dbg_printk("Clearing PxSERR.DIAG.x\n");
		writel((1 << 26), dd->port->mmio + PORT_SCR_ERR);
	}

	if (unlikely(port_stat & PORT_IRQ_PHYRDY)) {
		dbg_printk("Clearing PxSERR.DIAG.n\n");
		writel((1 << 16), dd->port->mmio + PORT_SCR_ERR);
	}

	if (unlikely(port_stat & ~PORT_IRQ_HANDLED)) {
		dev_err(&dd->pdev->dev,
			"Port stat errors %x unhandled\n",
			(port_stat & ~PORT_IRQ_HANDLED));
		if (mtip_check_surprise_removal(dd))
			return;
	}

	if (likely(port_stat & (PORT_IRQ_TF_ERR | PORT_IRQ_IF_ERR))) {
		dd->port_stat = port_stat;
		mtip_set_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags);
		wake_up_interruptible(&dd->svc_wait);
	}
}

static inline irqreturn_t mtip_handle_irq(struct driver_data *dd)
{
	struct mtip_port *port = dd->port;
	u32 hba_stat, port_stat, completed = 0;
	int rv = IRQ_NONE;
	int do_irq_enable = 1, i, workers;

	hba_stat = readl(dd->mmio + HOST_IRQ_STAT);
	if (hba_stat) {
		rv = IRQ_HANDLED;

		/* Acknowledge the interrupt status on the port */
		port_stat = readl(port->mmio + PORT_IRQ_STAT);
		if (unlikely(port_stat == 0xffffffff)) {
			if (mtip_check_surprise_removal(dd)) 
				return IRQ_HANDLED;
		}
		writel(port_stat, port->mmio + PORT_IRQ_STAT);

		/* Demux port status */
		if (likely(port_stat & PORT_IRQ_SDB_FIS)) {
			do_irq_enable = 0;
			WARN_ON_ONCE(atomic_read(&dd->irq_workers_active)
									!= 0);
			if (unlikely(atomic_read(&dd->irq_workers_active) 
									!= 0))
				goto check_next_port_bits;

			for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++)
				dd->work[i].completed =
						readl(port->completed[i]);

			for (i = 0, workers = 0; i < MTIP_MAX_SLOT_GROUPS;
									i++) {
				if (dd->work[i].completed) {
					completed &= dd->work[i].completed;
					workers++;
				}
			}

			/* SRSI hint */
			if (unlikely(completed == 0xffffffff)) {
				if (mtip_check_surprise_removal(dd)) {
					/* don't proceed further */
					return IRQ_HANDLED;
				}
			}

			atomic_set(&dd->irq_workers_active, workers);

			if (workers) {
				for (i = 1; i < MTIP_MAX_SLOT_GROUPS; i++) {
					if (dd->work[i].completed) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29) && \
	!defined(LEGACY_PPC)
						if (__get_cpu_var(pcpu_queue_mode) == 0) {
							queue_work_on(
								dd->work[i].cpu_binding,
								dd->isr_workq,
								&dd->work[i].work);
						} else 
#endif
							queue_work(dd->isr_workq,
								&dd->work[i].work);
					}
				}

				if (likely(dd->work[0].completed))
					workq_sdbfx(port, 0,
							dd->work[0].completed);

			} else {
				/*
				 * Chip quirk: SDB interrupt but nothing o
				 *  to complete
				 */
				do_irq_enable = 1;
			}
		}

check_next_port_bits:
		if (unlikely(port_stat & PORT_IRQ_ERR)) {

			if (mtip_check_surprise_removal(dd)) {
				/* don't proceed further */
				return IRQ_HANDLED;
			}

			if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
							dd->flags))
				return IRQ_HANDLED;

			mtip_process_errors(dd, port_stat & PORT_IRQ_ERR);
		}

		if (unlikely(port_stat & PORT_IRQ_LEGACY))
			mtip_process_legacy(dd, port_stat & PORT_IRQ_LEGACY);
	}

	/* acknowledge interrupt */
	if (unlikely(do_irq_enable))
		writel(hba_stat, dd->mmio + HOST_IRQ_STAT);

	return rv;
}

/*
 * HBA interrupt subroutine: wrapper for mtip_handle_irq()
 *
 * @irq		IRQ number.
 * @instance	Pointer to the driver data structure.
 *
 * return value
 *	IRQ_HANDLED	A HBA interrupt was pending and handled.
 *	IRQ_NONE	This interrupt was not for the HBA.
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 21)
static irqreturn_t mtip_irq_handler(int irq, void *instance)
#else
static irqreturn_t mtip_irq_handler(int irq, void *instance,
					struct pt_regs *pt_regs)
#endif
{
	return mtip_handle_irq(instance);
}

static void mtip_issue_non_ncq_command(struct mtip_port *port, int tag)
{
	WARN_ON(tag != MTIP_TAG_INTERNAL);
	atomic_set(&port->commands[tag].active, 1);
	spin_lock(&port->cmd_issue_lock[MTIP_TAG_INDEX(tag)]);
	writel(1 << MTIP_TAG_BIT(tag),
		port->cmd_issue[MTIP_TAG_INDEX(tag)]);
	spin_unlock(&port->cmd_issue_lock[MTIP_TAG_INDEX(tag)]);
}

static bool mtip_reconcile_flags(struct mtip_port *port,
				struct host_to_dev_fis *fis)
{
	switch (fis->command) {
	case ATA_CMD_SEC_ERASE_UNIT:
		mtip_clear_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags);
		return false;
	case 0xFC:
		if (fis->features == 0xA0 && !fis->lba_low) {
			dev_info(&port->dd->pdev->dev,
				"Restarting port after SQS enable.\n");
			mtip_restart_port(port);
		}
		return false;
	case ATA_CMD_SEC_ERASE_PREP:
		mtip_set_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags);
		port->ic_pause_timer = jiffies;
		return true;
	case ATA_CMD_DOWNLOAD_MICRO:
		if (fis->features == 0x03) {
			mtip_set_bit(MTIP_DDF_DM_ACTIVE_BIT, port->dd->flags);
			port->ic_pause_timer = jiffies;
			return true;
		}
		return false;
	}
	return false;
}

/*
 * Wait for port to quiesce
 *
 * @port    Pointer to port data structure
 * @timeout Max duration to wait (ms)
 * @atomic  gfp_t flag to indicate blockable context or not
 *
 * return value
 *	0	Success
 *	-EBUSY  Commands still active
 * 	-EINTR	Interrupted
 *	-ENODEV Device surprise removed
 */
static int mtip_quiesce_io(struct mtip_port *port,
				unsigned long timeout,
				gfp_t atomic)
{
	unsigned long to;
	unsigned int n;
	unsigned int active = 0xdeadc0de;

	to = jiffies + msecs_to_jiffies(timeout);
	do {
		if (mtip_check_surprise_removal(port->dd))
			return -ENODEV;

		if (atomic == GFP_KERNEL) {
			if (mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT,
							port->dd->flags)) {

				if (mtip_check_surprise_removal(port->dd))
					return -ENODEV;

				/*
				 * Service thread is issuing commands
				 * or error handler active
				 */
				if (msleep_interruptible(10))
					return -EINTR;

				continue;
			}
		}

		/*
		 * Ignore s_active bit 0 in slot group 0.
		 * This bit will always be set since it is
		 * exclusively used for non-queueable (AKA
		 * MTIP_TAG_INTERNAL) commands.
		 */
		active = readl(port->s_active[0]) & 0xFFFFFFFE;
		for (n = 1; n < MTIP_MAX_SLOT_GROUPS; n++)
			active |= readl(port->s_active[n]);

		if (!active)
			break;

		if (mtip_check_surprise_removal(port->dd))
			return -ENODEV;

		if (atomic == GFP_KERNEL) {
			if (msleep_interruptible(10))
				return -EINTR;
		} else {
			cpu_relax();
			udelay(10);
		}

	} while (time_before(jiffies, to));

	if (active) {
		if (mtip_check_surprise_removal(port->dd))
			return -ENODEV;

		mtip_printk(MTIP_AHCI, MTIP_WARNING, port->dd,
			"timeout waiting for queued commands to complete: "
			"active %08x (%s:%d)\n",
			active, current->comm, current->pid);

		mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
			"SAct: %08x %08x %08x %08x %08x %08x %08x %08x\n",
			readl(port->s_active[0]), readl(port->s_active[1]),
			readl(port->s_active[2]), readl(port->s_active[3]),
			readl(port->s_active[4]), readl(port->s_active[5]),
			readl(port->s_active[6]), readl(port->s_active[7]));
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
			"CI: %08x %08x %08x %08x %08x %08x %08x %08x\n",
			readl(port->cmd_issue[0]), readl(port->cmd_issue[1]),
			readl(port->cmd_issue[2]), readl(port->cmd_issue[3]),
			readl(port->cmd_issue[4]), readl(port->cmd_issue[5]),
			readl(port->cmd_issue[6]), readl(port->cmd_issue[7]));

		/* check again before failing */
		active = readl(port->s_active[0]) & 0xfffffffe;
		for (n = 1; n < MTIP_MAX_SLOT_GROUPS; n++)
			active |= readl(port->s_active[n]);
	}

	return active ? -EBUSY : 0;
}

static void mtip_set_timeout(struct driver_data *dd,
				struct host_to_dev_fis *fis,
				long unsigned int *timeout,
				u8 erasemode)
{
	switch (fis->command) {
	case ATA_CMD_DOWNLOAD_MICRO:
		*timeout = 120000; /* 2 minutes */
		break;
	case ATA_CMD_SEC_ERASE_UNIT:
	case 0xFC:
		if (dd->port->identify_valid) {
			if (erasemode)
				*timeout = ((*(dd->port->identify + 90) * 2) *
								60000);
			else
				*timeout = ((*(dd->port->identify + 89) * 2) *
								60000);
		} else 
			*timeout = 600000;

		if (fis->features == 0x14)
			*timeout *= 100;
		break;
	case ATA_CMD_STANDBYNOW1:
		*timeout = 120000;  /* 2 minutes */
		break;
	case 0xF7:
	case 0xFA:
		*timeout = 60000;  /* 60 seconds */
		break;
	case ATA_CMD_SMART:
		*timeout = 15000;  /* 15 seconds */
		break;
	case ATA_CMD_READ_LOG_EXT:
		*timeout = 2000;
		break;
	case ATA_CMD_FLUSH:
	case ATA_CMD_FLUSH_EXT:
		*timeout = 60000;
		break;
	case 0xFB:
		if (fis->features == 0x60) {
			*timeout = 240000;
			break;
		}
		/* fall through */
	default:
		*timeout = MTIP_INT_CMD_TIMEOUT_MS;
		break;
	}
}

/*
 * Execute an internal command and wait for the completion.
 *
 * @port    Pointer to the port data structure.
 * @fis     Pointer to the FIS that describes the command.
 * @fis_len Length in WORDS of the FIS.
 * @buffer  DMA accessible for command data.
 * @buf_len Length, in bytes, of the data buffer.
 * @opts    Command header options, excluding the FIS length
 *             and the number of PRD entries.
 * @timeout Time in ms to wait for the command to complete.
 *
 * return value
 *	0	 Command completed successfully.
 *	-EFAULT  The buffer address is not correctly aligned.
 *	-EBUSY   Internal command or other IO in progress.
 *	-EAGAIN  Time out waiting for command to complete.
 *	-EINTR   Interrupted by signal.
 *	-ENODEV  Device surprise removed.
 */
int mtip_exec_internal_command(struct mtip_port *port,
					struct host_to_dev_fis *fis,
					int fis_len,
					dma_addr_t buffer,
					int buf_len,
					u32 opts,
					gfp_t atomic,
					unsigned long timeout)
{
	struct mtip_cmd_sg *command_sg;
	DECLARE_COMPLETION_ONSTACK(wait);
	int rv = 0, ready2go = 1;
	struct mtip_cmd *int_cmd = &port->commands[MTIP_TAG_INTERNAL];
	unsigned long start, to;
	struct timeval start_tv, end_tv;

	/* Make sure the buffer is 8 byte aligned. This is asic specific. */
	if (buffer & 0x07) {
		dev_err(&port->dd->pdev->dev,
			"SG buffer is not 8 byte aligned\n");
		return -EFAULT;
	}

	/*
	 * spin on error handler completing its work
	 * TODO: figure out if this needs to time out ever
	*/
	if (atomic == GFP_KERNEL) {
		while (mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT,
							port->dd->flags)) {
			if (msleep_interruptible(100))
				return -EINTR;
		}
	}

	/* Spin wait for exclusive access to internal command slot */
	to = jiffies + msecs_to_jiffies(MTIP_QUIESCE_TIMEOUT_MS);
	do {
		ready2go = !test_and_set_bit(MTIP_TAG_INTERNAL,
						port->allocated);
		if (ready2go)
			break;
		if (atomic == GFP_KERNEL) {
			if (msleep_interruptible(100))
				return -EINTR;
		} else {
			cpu_relax();
			msleep(200);
		}	
	} while (time_before(jiffies, to));
	if (!ready2go) {
		dev_warn(&port->dd->pdev->dev,
			"Internal cmd active. new cmd [%02X]\n", fis->command);
		return -EBUSY;
	}
	mtip_set_bit(MTIP_DDF_IC_ACTIVE_BIT, port->dd->flags);
	port->ic_pause_timer = 0;
	/* Commenting out due to bug 19668 */
	/* mtip_clear_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags); */
	mtip_clear_bit(MTIP_DDF_DM_ACTIVE_BIT, port->dd->flags);

	/* In quiesce mode, just allow mgmt commands through */
	if (mtip_test_bit(MTIP_DDF_QUIESCE_BIT, port->dd->flags))
        	rv = 0;	
	else {
		/* Wait for outstanding queued commands to clear out */
		rv = mtip_quiesce_io(port, MTIP_QUIESCE_TIMEOUT_MS, atomic);
		if (rv < 0) {
			switch (rv) {
			case -EINTR:
				dev_info(&port->dd->pdev->dev,
					"Failed to quiesce IO: interrupted\n");
				break;
			case -ENODEV:
				dev_warn(&port->dd->pdev->dev,
					"Failed to quiesce IO: device removed\n");
				break;
			default:
				dev_err(&port->dd->pdev->dev,
					"Failed to quiesce IO\n");
				break;
			}
			mtip_clear_bit(MTIP_DDF_IC_ACTIVE_BIT, port->dd->flags);
			release_slot(port, MTIP_TAG_INTERNAL);
			wake_up_interruptible(&port->dd->svc_wait);
			return rv;
		}
	}

	/* Clear old taskfile data */
	memset(port->rxfis, 0xcc, AHCI_RX_FIS_SZ);

	switch (fis->command) {
	case ATA_CMD_SEC_ERASE_UNIT:
		/* Should already be set */
		mtip_set_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags);
		break;
	case ATA_CMD_SEC_ERASE_PREP:
		mtip_set_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags);
		break;
	case ATA_CMD_DOWNLOAD_MICRO:
		mtip_set_bit(MTIP_DDF_DM_ACTIVE_BIT, port->dd->flags);
		break;
	case ATA_CMD_ID_ATA:
		if (buffer == port->identify_dma) {
			/* Set identify information invalid and clear */
			port->identify_valid = 0;
			memset(port->identify, 0, sizeof(u16) * ATA_ID_WORDS);
		}
		break;
	}

	if (atomic == GFP_KERNEL) {
		/* Set the completion function and data for the command */
		int_cmd->comp_data = &wait;
		int_cmd->comp_func = mtip_completion;

	} else {
		/* Clear completion - we're going to poll */
		int_cmd->comp_data = NULL;
		int_cmd->comp_func = mtip_null_completion;
	}

	/* Copy the command to the command table */
	memcpy(int_cmd->command, fis, fis_len * 4);

	/* Populate the SG list */
	int_cmd->command_header->opts =
		 __force_bit2int cpu_to_le32(opts | fis_len);
	if (buf_len) {
		command_sg = int_cmd->command + AHCI_CMD_TBL_HDR_SZ;

		command_sg->info =
			__force_bit2int cpu_to_le32((buf_len-1) & 0x3FFFFF);
		command_sg->dba	=
			__force_bit2int cpu_to_le32(buffer & 0xFFFFFFFF);
		command_sg->dba_upper =
			__force_bit2int cpu_to_le32((buffer >> 16) >> 16);

		int_cmd->command_header->opts |=
			__force_bit2int cpu_to_le32((1 << 16));
	}

	/* Populate the command header */
	int_cmd->command_header->byte_count = 0;

	if (fis->command == ATA_CMD_FLUSH ||
	    fis->command == ATA_CMD_FLUSH_EXT) {
		do_gettimeofday(&start_tv);
	}

	start = jiffies;

	/* Issue the command to the hardware */
	mtip_issue_non_ncq_command(port, MTIP_TAG_INTERNAL);

	if (mtip_test_bit(MTIP_DDF_FW_RESET_BIT, port->dd->flags)) {
		rv = 0;
		ssleep(1);
		goto exec_ic_exit;
	}

	/*
	 * TODO: This is racy: what if preempt before entering wait()?
	 *	Add an atomic counter to check; calling context increments &
	 *	completion routine decrements counter.  If counter is 0 when
	 *	deciding to wait; assume completion has already occurred.
	 */

	/* Poll if atomic, wait_for_completion otherwise */
	if (atomic == GFP_KERNEL) {
		/* Wait for the command to complete or timeout. */
		 rv = wait_for_completion_interruptible_timeout(
				&wait, msecs_to_jiffies(timeout));
		if (rv <= 0) {

			if (rv == -ERESTARTSYS) {
				dev_info(&port->dd->pdev->dev,
					"Internal command (%02x) from %s:%d "
					"was interrupted after %u ms.\n",
					fis->command, current->comm,
					current->pid,
					jiffies_to_msecs(jiffies - start));
				rv = -EINTR;
				goto exec_ic_exit;
			} else if (rv == 0) { /* timeout */
				dev_err(&port->dd->pdev->dev,
					"Internal command (%02x) did not "
					"complete within timeout of %lu ms\n",
					fis->command,
					timeout);
			} else {
				dev_err(&port->dd->pdev->dev,
					"Return code %d unhandled\n", rv);
			}

			if (mtip_check_surprise_removal(port->dd))
				dev_warn(&port->dd->pdev->dev,
					"Surprise remove during wait\n");
 
			if (fis->command != 0xE0 && fis->command != 0x92) {
				if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
						port->dd->flags)) {
					rv = -EFAULT;
					goto exec_ic_exit;
				}
			}

			if (mtip_error_cleanup(port, rv == 0 ?
						"internal command timeout" :
						"internal command error") == 0)
				atomic_set(&int_cmd->active, 0);

			rv = -EBUSY;
			/* fall through */
		} else {
			rv = 0;
			if (port->int_cmd_status) {
				dev_warn(&port->dd->pdev->dev,
					"Internal command (%02x) completed"
					" with bad status %x\n",
					fis->command, port->int_cmd_status);
				rv = -EIO;
				port->int_cmd_status = 0;
				/*
				 * don't fall through
				 * we don't care whether CI flipped on TFE
				 */
				goto exec_ic_exit;
			}
		}

		if (readl(port->cmd_issue[MTIP_TAG_INTERNAL])
			& (1 << MTIP_TAG_INTERNAL)) {

			dev_warn(&port->dd->pdev->dev,
				"Retiring internal command but CI is 1.\n");

			if (!mtip_check_surprise_removal(port->dd)) {

				if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
							port->dd->flags)) {
					mtip_printk(MTIP_AHCI, MTIP_WARNING, 
						port->dd, "Removal during internal command: issuing HBAReset to cleanup\n");
					mtip_hba_reset(port->dd);
				} else {
					mtip_printk(MTIP_AHCI, MTIP_WARNING,
						port->dd, "Restarting port to clean drive state\n");
					mtip_restart_port(port);
				}
			}

			rv = -EFAULT;
			/* fall through */	
		}

	} else {
		u32 port_stat, ci;

		/* TODO: verify that multiple 512b chunk SMART commands work */

		/* Spin for <timeout> checking if command still outstanding */
		timeout = jiffies + msecs_to_jiffies(timeout);
		do {
			cpu_relax();
			msleep(200);

			if (mtip_check_surprise_removal(port->dd)) {
				mtip_printk(MTIP_AHCI, MTIP_WARNING, port->dd,
					"Aborting internal command %02x due to surprise removal\n",
					fis->command);
				rv = -EFAULT;
				goto exec_ic_exit;
			}

			/* Check orderly removal */
			if ((fis->command != ATA_CMD_STANDBYNOW1) &&
				mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
							port->dd->flags)) {
				mtip_printk(MTIP_AHCI, MTIP_WARNING, port->dd,
					"Aborting internal command %02x due to device removal.\n",
					fis->command);
				rv = -EFAULT;
				goto exec_ic_exit;
			}

			/* test for CI to flip */
			ci = readl(port->cmd_issue[MTIP_TAG_INTERNAL]);
			if (!(ci & (1 << MTIP_TAG_INTERNAL)))
				break;
			WARN_ON_ONCE(ci	& !(1 << MTIP_TAG_INTERNAL));

			cpu_relax();

			if ((port_stat = readl(port->mmio + PORT_IRQ_STAT))) {
				if (port_stat & (PORT_IRQ_ERR)) {
					dev_err(&port->dd->pdev->dev, 
						"Internal command %02x aborted [atomic].\n",
						fis->command);
					writel(port_stat,
						port->mmio + PORT_IRQ_STAT);
					mtip_error_cleanup(port, 
						"internal command abort");
					rv = -EFAULT;
					goto exec_ic_exit;
				} else {
					u32 hba_stat;
					dev_info(&port->dd->pdev->dev,
						"squelching port %08x (legacy %d)\n",
						port_stat,
						port_stat & (PORT_IRQ_LEGACY));
					writel(port_stat,
						port->mmio + PORT_IRQ_STAT);
					hba_stat = readl(port->dd->mmio +
								HOST_IRQ_STAT);
					if (hba_stat)
						writel(hba_stat, port->dd->mmio 
							+ HOST_IRQ_STAT);
				}
				break;
			}
		} while (time_before(jiffies, timeout));

		if (readl(port->cmd_issue[MTIP_TAG_INTERNAL])
			& (1 << MTIP_TAG_INTERNAL)) {
			dev_err(&port->dd->pdev->dev,
				"Internal cmd %02x did not complete [atomic]\n", fis->command);
			mtip_error_cleanup(port, "internal command timeout");
			rv = -EFAULT;
			/* fall through */	
		}
	}

	if (!rv && (fis->command == ATA_CMD_FLUSH ||
		    fis->command == ATA_CMD_FLUSH_EXT)) {
		do_gettimeofday(&end_tv);
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
			"%s %ld.%06ld\n",
			fis->command == ATA_CMD_FLUSH ? 
				"ATA_CMD_FLUSH" : "ATA_CMD_FLUSH_EXT",
			end_tv.tv_sec - start_tv.tv_sec,
			end_tv.tv_usec > start_tv.tv_usec ?
				end_tv.tv_usec - start_tv.tv_usec :
				(1000000 - start_tv.tv_usec) + end_tv.tv_usec);
       }

exec_ic_exit:
	/* Clear the allocated and active bits for the internal command */
	atomic_set(&int_cmd->active, 0);
	mtip_clear_bit(MTIP_DDF_IC_ACTIVE_BIT, port->dd->flags);

	if (rv < 0) {
		mtip_clear_bit(MTIP_DDF_DM_ACTIVE_BIT, port->dd->flags);
		mtip_clear_bit(MTIP_DDF_SE_ACTIVE_BIT, port->dd->flags);
		wake_up_interruptible(&port->dd->svc_wait);
	} else if (mtip_reconcile_flags(port, fis) == false) {
		wake_up_interruptible(&port->dd->svc_wait);
	}

	release_slot(port, MTIP_TAG_INTERNAL);

	return rv;
}

/*
 * Byte-swap ATA ID strings.
 *
 * ATA identify data contains strings in byte-swapped 16-bit words.
 * They must be swapped (on all architectures) to be usable as C strings.
 * This function swaps bytes in-place.
 *
 * @buf The buffer location of the string
 * @len The number of bytes to swap
 *
 * return value
 *	None
 */
static inline void ata_swap_string(u16 *buf, unsigned int len)
{
	int i;
	for (i = 0; i < (len/2); i++)
		be16_to_cpus(&buf[i]);
}

/*
 * Request the device identity information.
 *
 * If a user space buffer is not specified, i.e. is NULL, the
 * identify information is still read from the drive and placed
 * into the identify data buffer (port->identify) in the
 * port data structure.
 * When the identify buffer contains valid identify information 
 * port->identify_valid is non-zero.
 *
 * @port	 Pointer to the port structure.
 * @user_buffer  A user space buffer where the identify data should be
 *                    copied.
 *
 * return value
 *	0	Command completed successfully.
 *	-EFAULT An error occurred while copying data to/from the user buffer.
 *	For other values, see mtip_exec_internal_command() return codes.
 */
static int mtip_get_identify(struct mtip_port *port, void __user *user_buffer)
{
	int rv = 0;
	struct host_to_dev_fis fis;
	unsigned long to;

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, port->dd->flags))
		return -EFAULT;

	/* optimization: spit back cached copy without executing command */
	if (port->identify_valid && user_buffer) {
		if (copy_to_user(user_buffer, port->identify,
				ATA_ID_WORDS * sizeof(u16)))
			return -EFAULT;
		return 0;
	}

	down_write(&port->dd->sync_sem);

	/* Build the FIS */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= ATA_CMD_ID_ATA;

	mtip_set_timeout(port->dd, &fis, &to, 0);
	
	/* Execute the command */
	rv = mtip_exec_internal_command(port,
				&fis,
				5,
				port->identify_dma,
				sizeof(u16) * ATA_ID_WORDS,
				0,
				GFP_KERNEL,
				to);
	if (rv < 0)
		goto out;

	/*
	 * Perform any necessary byte-swapping.  Yes, the kernel does in fact
	 * perform field-sensitive swapping on the string fields.
	 * See the kernel use of ata_id_string() for proof of this.
	 */
#ifdef __LITTLE_ENDIAN
	ata_swap_string(port->identify + 27, 40);  /* model string    */
	ata_swap_string(port->identify + 23, 8);   /* firmware string */
	ata_swap_string(port->identify + 10, 20);  /* serial# string  */
#else
	{
		int i;
		for (i = 0; i < ATA_ID_WORDS; i++)
			port->identify[i] = le16_to_cpu(port->identify[i]);
	}
#endif

	/* Check security locked state */
	if (port->identify[128] & 0x4)
		mtip_set_bit(MTIP_DDF_SEC_LOCK_BIT, port->dd->flags);
	else
		mtip_clear_bit(MTIP_DDF_SEC_LOCK_BIT, port->dd->flags);

	if ((port->identify[69] & (1 << 14)) && port->identify[69] & (1 << 5))
		port->dd->trim_supp = 1;
	else
		port->dd->trim_supp = 0;

	/* Set the identify buffer as valid */
	port->identify_valid = 1;

	if (user_buffer &&
		copy_to_user(user_buffer, port->identify,
				ATA_ID_WORDS * sizeof(u16))) {
		rv = -EFAULT;
		goto out;
	}
out:
	up_write(&port->dd->sync_sem);
	return rv;
}

/*
 * Issue a standby immediate command to the device.
 * The synchronize RW Semaphore must be held on entrance.
 *
 * @port Pointer to the port structure.
 *
 * return value
 *	0	Command was executed successfully.
 *	-EFAULT	An error occurred while executing the command.
 */
static int mtip_standby_immediate(struct mtip_port *port)
{
	int rv = 0;
	struct host_to_dev_fis fis;
	unsigned long start, to;

	/* Build the FIS. */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= ATA_CMD_STANDBYNOW1;

	mtip_set_timeout(port->dd, &fis, &to, 0);

	start = jiffies;
	rv = mtip_exec_internal_command(port,
					&fis,
					5,
					0,
					0,
					0,
					GFP_KERNEL,
					to);

	if (rv) {
		dev_warn(&port->dd->pdev->dev,
			"Standby Immediate command failed.\n");
		rv = -EFAULT;
	} else {
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, port->dd,
			"Standby immediate time: %d ms\n",
			jiffies_to_msecs(jiffies - start));
	}
	return rv;
}

/*
 * Issue a READ LOG EXT command to the device.
 * The synchronize RW Semaphore must be held on entrance.
 *
 * @port	pointer to the port structure.
 * @page	page number to fetch
 * @buffer	pointer to buffer
 * @buffer_dma	dma address corresponding to @buffer
 * @sectors	page length to fetch, in sectors
 *
 * return value
 *	@rv	return value from mtip_exec_internal_command()
 */
static int mtip_read_log_page(struct mtip_port *port, u8 page, u16 *buffer,
				dma_addr_t buffer_dma, unsigned int sectors)
{
	struct host_to_dev_fis fis;
	unsigned long to;

	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= ATA_CMD_READ_LOG_EXT;
	fis.sect_count	= sectors & 0xFF;
	fis.sect_cnt_ex	= (sectors >> 8) & 0xFF;
	fis.lba_low	= page;
	fis.lba_mid	= 0;
	fis.device	= ATA_DEVICE_OBS;

	memset(buffer, 0, sectors * ATA_SECT_SIZE);

	mtip_set_timeout(port->dd, &fis, &to, 0);

	return mtip_exec_internal_command(port,
					&fis,
					5,
					buffer_dma,
					sectors * ATA_SECT_SIZE,
					0,
					GFP_ATOMIC,
					to);
}

/*
 * Issue a SMART READ DATA command to the device.
 * The synchronize RW Semaphore must be held on entrance.
 *
 * @port	pointer to the port structure.
 * @buffer	pointer to buffer
 * @buffer_dma	dma address corresponding to @buffer
 *
 * return value
 *	@rv	return value from mtip_exec_internal_command()
 */
static int mtip_get_smart_data(struct mtip_port *port, u8 *buffer,
					dma_addr_t buffer_dma)
{
	struct host_to_dev_fis fis;
	unsigned long to;

	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= ATA_CMD_SMART;
	fis.features	= 0xD0;
	fis.sect_count	= 1;
	fis.lba_mid	= 0x4F;
	fis.lba_hi	= 0xC2;
	fis.device	= ATA_DEVICE_OBS;

	mtip_set_timeout(port->dd, &fis, &to, 0);

	return mtip_exec_internal_command(port,
					&fis,
					5,
					buffer_dma,
					ATA_SECT_SIZE,
					0,
					GFP_KERNEL,
					to);
}

/*
 * Get the value of a smart attribute
 * The synchronize RW Semaphore must be held on entrance.
 *
 * @port	pointer to the port structure
 * @id		attribute number
 * @attrib	pointer to return attrib information corresponding to @id
 *
 * return value
 *	-EINVAL	NULL buffer passed or unsupported attribute @id.
 *	-EPERM	Identify data not valid, SMART not supported or not enabled
 *      For other values, see return codes from mtip_get_smart_data()
 */
static int mtip_get_smart_attr(struct mtip_port *port, unsigned int id,
						struct smart_attr *attrib)
{
	int rv, i;
	struct smart_attr *pattr;

	if (!attrib)
		return -EINVAL;

	if (!port->identify_valid) {
		dev_warn(&port->dd->pdev->dev,
			"IDENTIFY DATA not valid\n");
		return -EPERM;
	}

	if (!(port->identify[82] & 0x1)) {
		dev_warn(&port->dd->pdev->dev,
			"SMART not supported\n");
		return -EPERM;
	}

	if (!(port->identify[85] & 0x1)) {
		dev_warn(&port->dd->pdev->dev, "SMART not enabled\n");
		return -EPERM;
	}

	memset(port->smart_buf, 0, ATA_SECT_SIZE);
	rv = mtip_get_smart_data(port, port->smart_buf, port->smart_buf_dma);
	if (rv) {
		dev_warn(&port->dd->pdev->dev,
			"Failed to get SMART data\n");
		return rv;
	}

	pattr = (struct smart_attr *)(port->smart_buf + 2);
	for (i = 0; i < 29; i++, pattr++) {
		if (pattr->attr_id == id) {
			memcpy(attrib, pattr, sizeof(struct smart_attr));
			return 0;
		}
	}

	dev_warn(&port->dd->pdev->dev,
		"Query for invalid SMART attribute ID\n");

	return -EINVAL;
}

/*
 * Get the drive capacity.
 *
 * @dd      Pointer to the device data structure.
 * @sectors Pointer to the variable that will receive the sector count.
 *
 * return value
 *	1 Capacity was returned successfully.
 *	0 The identify information is invalid.
 */
static bool mtip_hw_get_capacity(struct driver_data *dd, sector_t *sectors)
{
	struct mtip_port *port = dd->port;
	u64 total, raw0, raw1, raw2, raw3;

	if (!dd->port)
		return 0;

	raw0 = port->identify[100];
	raw1 = port->identify[101];
	raw2 = port->identify[102];
	raw3 = port->identify[103];
	total = raw0 | raw1 << 16 | raw2 << 32 | raw3 << 48;
	*sectors = total;

	return (bool) !!port->identify_valid;
}

/*
 * Display the identify command data.
 *
 * @port Pointer to the port data structure.
 *
 * return value
 *	None
 */
static void mtip_dump_identify(struct mtip_port *port)
{
	sector_t sectors;
	char cbuf[42];

	if (!port->identify_valid)
		return;

	strlcpy(cbuf, (char *)(port->identify+10), 21);
	dev_info(&port->dd->pdev->dev,
		"Serial No.: %s\n", cbuf);

	strlcpy(cbuf, (char *)(port->identify+23), 9);
	dev_info(&port->dd->pdev->dev,
		"Firmware Ver.: %s\n", cbuf);

	strlcpy(cbuf, (char *)(port->identify+27), 41);
	dev_info(&port->dd->pdev->dev, "Model: %s\n", cbuf);

	dev_info(&port->dd->pdev->dev, "Security: %04x %s\n",
		port->identify[128], 
		port->identify[128] & 0x4 ? "(LOCKED)" : "");

	if (mtip_hw_get_capacity(port->dd, &sectors))
		dev_info(&port->dd->pdev->dev,
			"Capacity: %llu sectors (%llu MB)\n",
			 (u64)sectors,
			 ((u64)sectors) * ATA_SECT_SIZE >> 20);
}

/*
 * Map the commands scatter list into the command table.
 *
 * @command Pointer to the command.
 * @nents   Number of scatter list entries.
 *
 * return value
 *	None
 */
static inline void fill_command_sg(struct driver_data *dd,
				struct mtip_cmd *command,
				int nents)
{
	int n;
	unsigned int dma_len;
	struct mtip_cmd_sg *command_sg;
	struct scatterlist *sg = command->sg;

	command_sg = command->command + AHCI_CMD_TBL_HDR_SZ;

	for (n = 0; n < nents; n++) {
		dma_len = sg_dma_len(sg);
		if (dma_len > 0x400000)
			dev_err(&dd->pdev->dev,
				"DMA segment length truncated\n");
		/* ASIC Errata: Never use PRD I-bit */
		command_sg->info = __force_bit2int
			cpu_to_le32((dma_len-1) & 0x3FFFFF);
		command_sg->dba	= __force_bit2int
			cpu_to_le32(sg_dma_address(sg));
		command_sg->dba_upper = __force_bit2int
			cpu_to_le32((sg_dma_address(sg) >> 16) >> 16);
		command_sg++;
		sg++;
	}
}

/*
 * Execute a drive command.
 *
 * @port    Pointer to the port structure
 * @command Pointer to array containing a 7 byte FIS
 *
 * return value
 * 	 0  The command completed successfully.
 * 	 For other values, see return codes from mtip_exec_internal_command().
 */
static int exec_drive_task(struct mtip_port *port, u8 *command)
{
	struct host_to_dev_fis	fis;
	struct host_to_dev_fis *reply = (port->rxfis + RX_FIS_D2H_REG);
	unsigned long to;
	int rv = 0;

	/* Build the FIS */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= command[0];
	fis.features	= command[1];
	fis.sect_count	= command[2];
	fis.sector	= command[3];
	fis.cyl_low	= command[4];
	fis.cyl_hi	= command[5];
	fis.device	= command[6] & ~0x10; /* Clear the dev bit*/

	down_write(&port->dd->sync_sem);

	mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, port->dd,
		"   %s command: cmd 0x%x, feat 0x%x, nsect 0x%x, sect 0x%x, lcyl 0x%x, hcyl 0x%x, select 0x%x\n",
		__func__,
		command[0],
		command[1],
		command[2],
		command[3],
		command[4],
		command[5],
		command[6]);

	mtip_set_timeout(port->dd, &fis, &to, 0);

	/* Execute the command */
	rv = mtip_exec_internal_command(port,
				 &fis,
				 5,
				 0,
				 0,
				 0,
				 GFP_KERNEL,
				 to);
	if (rv < 0) {
		if (rv == -EIO) { /* Command ended with Taskfile or similar */
			mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_WARNING,
					port->dd, "Restarting port following failed internal cmd\n");
			mtip_restart_port(port);
		}
		up_write(&port->dd->sync_sem);
		return rv;
	}

	command[0] = reply->command; /* Status */
	command[1] = reply->features; /* Error */
	command[4] = reply->cyl_low;
	command[5] = reply->cyl_hi;

	up_write(&port->dd->sync_sem);

	mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, port->dd,
		"   %s completion: Status 0x%x, Err 0x%x, CylLow 0x%x, CylHi 0x%x\n",
		__func__,
		command[0],
		command[1],
		command[4],
		command[5]);

	return 0;
}

/*
 * Execute a drive command.
 *
 * @port        Pointer to the port data structure.
 * @command     Pointer to the user specified command parameters.
 * @user_buffer Pointer to the user space buffer where read sector
 *                   data should be copied.
 *
 * return value
 * 	0 	The command completed successfully.
 * 	-EFAULT An error occurred while copying the completion
 *                 data to the user space buffer.
 * 	-1 	An error occurred while executing the command.
 */
static int exec_drive_command(struct mtip_port *port, u8 *command,
				void __user *user_buffer)
{
	struct host_to_dev_fis	fis;
	u8 *buf = NULL;
	dma_addr_t dma_addr = 0;
	int rv = 0, xfer_sz = command[3];
	struct host_to_dev_fis *reply;
	unsigned long to;

	if (xfer_sz) {
		if (!user_buffer)
			return -EFAULT;
		/* Allocate a DMA buffer for the command */
		buf = dmam_alloc_coherent(&port->dd->pdev->dev,
			ATA_SECT_SIZE * xfer_sz,
			&dma_addr,
			GFP_KERNEL);

		if (!buf) 
			return -ENOMEM;

		memset(buf, 0x00, ATA_SECT_SIZE * xfer_sz);
	}

	down_write(&port->dd->sync_sem);

	/* Build the FIS */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= command[0];
	fis.features	= command[2];
	fis.sect_count	= command[3];

	if (fis.command == ATA_CMD_SMART) {
		fis.sector = command[1];
		fis.cyl_low = 0x4f;
		fis.cyl_hi  = 0xc2;
	}

	if (xfer_sz)
		reply = (port->rxfis + RX_FIS_PIO_SETUP);
	else
		reply = (port->rxfis + RX_FIS_D2H_REG);

	mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, port->dd,
		"   %s command: cmd 0x%x, sect 0x%x, feat 0x%x, nsect 0x%x\n",
		__func__, command[0], command[1], command[2], command[3]);

	mtip_set_timeout(port->dd, &fis, &to, 0);

	/* Execute the command */
	rv = mtip_exec_internal_command(port,
				&fis,
				5,
				(xfer_sz ? dma_addr : 0),
				(xfer_sz ? ATA_SECT_SIZE * xfer_sz : 0),
				0,
				GFP_KERNEL,
				to);
	if (rv < 0) {
		if (rv == -EIO) { /* Command ended with Taskfile or similar */
			mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_WARNING,
					port->dd, "Restarting port following failed internal cmd\n");
			mtip_restart_port(port);
		}
		goto exit_drive_command;
	}
	/* Collect the completion status */
	command[0] = reply->command;    /* Status */
	command[1] = reply->features;   /* Error */
	command[2] = reply->sect_count; /* Sectors */

	mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, port->dd,
		"   %s completion: status 0x%x, err 0x%x, nsect 0x%x\n",
		__func__, command[0], command[1], command[2]);

	if (user_buffer && command[3]) {
		if (copy_to_user(user_buffer, buf, ATA_SECT_SIZE * xfer_sz)) {
			rv = -EFAULT;
			goto exit_drive_command;
		}
	}

exit_drive_command:
	if (buf && xfer_sz)
		dmam_free_coherent(&port->dd->pdev->dev,
			ATA_SECT_SIZE * xfer_sz, buf, dma_addr);

	up_write(&port->dd->sync_sem);
	return rv;
}

/*
 *  Indicates whether a command has a single sector payload.
 *
 *  @command passed to the device to perform the certain event.
 *  @features passed to the device to perform the certain event.
 *
 *  return value
 *	1	command is one that always has a single sector payload,
 *		regardless of the value in the Sector Count field.
 *      0       otherwise
 *
 */
static unsigned int implicit_sector(unsigned char command,
				    unsigned char features)
{
	unsigned int rv = 0;

	/* list of commands that have an implicit sector count of 1 */
	switch (command) {
	case ATA_CMD_IDLEIMMEDIATE:
	case ATA_CMD_STANDBY:
	case ATA_CMD_IDLE:
	case ATA_CMD_SET_FEATURES:
	case ATA_CMD_SEC_SET_PASS:
	case ATA_CMD_SEC_UNLOCK:
	case ATA_CMD_SEC_ERASE_PREP:
	case ATA_CMD_SEC_ERASE_UNIT:
	case ATA_CMD_SEC_FREEZE_LOCK:
	case ATA_CMD_SEC_DISABLE_PASS:
	case ATA_CMD_PMP_READ:
	case ATA_CMD_PMP_WRITE:
		rv = 1;
		break;
	case ATA_CMD_SET_MAX:
		if (features == ATA_SET_MAX_UNLOCK)
			rv = 1;
		break;
	case ATA_CMD_SMART:
		if ((features == ATA_SMART_READ_VALUES) ||
				(features == ATA_SMART_READ_THRESHOLDS))
			rv = 1;
		break;
	case ATA_CMD_CONF_OVERLAY:
		if ((features == ATA_DCO_IDENTIFY) ||
				(features == ATA_DCO_SET))
			rv = 1;
		break;
	}
	return rv;
}

/*
 * Executes a taskfile
 * See ide_taskfile_ioctl() for derivation
 */
static int exec_drive_taskfile(struct driver_data *dd,
			       void __user *buf,
			       ide_task_request_t *req_task,
			       int outtotal)
{
	struct host_to_dev_fis fis;
	struct host_to_dev_fis *reply;
	u8 *outbuf = NULL;
	u8 *inbuf = NULL;
	dma_addr_t outbuf_dma = 0;
	dma_addr_t inbuf_dma = 0;
	dma_addr_t dma_buffer = 0;
	int err = 0;
	unsigned int taskin = 0;
	unsigned int taskout = 0;
	u8 nsect = 0;
	long unsigned int to;
	unsigned int force_single_sector;
	unsigned int transfer_size;
	unsigned long task_file_data;
	int intotal = outtotal + req_task->out_size;
	int do_id = 0;
	int erasemode = 0;

	taskout = req_task->out_size;
	taskin = req_task->in_size;

	/* 130560 = 512 * 0xFF */
	if (taskin > 130560 || taskout > 130560) {
		err = -EINVAL;
		goto abort;
	}

	if (taskout) {
		outbuf = kzalloc(taskout, GFP_KERNEL);
		if (outbuf == NULL) {
			err = -ENOMEM;
			goto abort;
		}
		if (copy_from_user(outbuf, buf + outtotal, taskout)) {
			err = -EFAULT;
			goto abort;
		}
		outbuf_dma = pci_map_single(dd->pdev,
					 outbuf,
					 taskout,
					 DMA_TO_DEVICE);
		if (outbuf_dma == 0) {
			err = -ENOMEM;
			goto abort;
		}
		dma_buffer = outbuf_dma;
	}

	if (taskin) {
		inbuf = kzalloc(taskin, GFP_KERNEL);
		if (inbuf == NULL) {
			err = -ENOMEM;
			goto abort;
		}

		if (copy_from_user(inbuf, buf + intotal, taskin)) {
			err = -EFAULT;
			goto abort;
		}
		inbuf_dma = pci_map_single(dd->pdev,
					 inbuf,
					 taskin, DMA_FROM_DEVICE);
		if (inbuf_dma == 0) {
			err = -ENOMEM;
			goto abort;
		}
		dma_buffer = inbuf_dma;
	}

	/* only supports PIO and non-data commands from this ioctl */
	switch (req_task->data_phase) {
	case TASKFILE_OUT:
		if (!taskout || 
		    (req_task->io_ports[2] * ATA_SECT_SIZE) > taskout) {
			err = -EINVAL;
			goto abort;
		}
		nsect = taskout / ATA_SECT_SIZE;
		reply = (dd->port->rxfis + RX_FIS_PIO_SETUP);
		break;
	case TASKFILE_IN:
		if (!taskin ||
		    (req_task->io_ports[2] * ATA_SECT_SIZE) > taskin) {
			err = -EINVAL;
			goto abort;
		}
		reply = (dd->port->rxfis + RX_FIS_PIO_SETUP);
		break;
	case TASKFILE_NO_DATA:
		reply = (dd->port->rxfis + RX_FIS_D2H_REG);
		break;
	default:
		err = -EINVAL;
		goto abort;
	}

	/* Build the FIS */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));

	fis.type	= 0x27;
	fis.opts	= 1 << 7;
	fis.command	= req_task->io_ports[7];
	fis.features	= req_task->io_ports[1];
	fis.sect_count	= req_task->io_ports[2];
	fis.lba_low	= req_task->io_ports[3];
	fis.lba_mid	= req_task->io_ports[4];
	fis.lba_hi	= req_task->io_ports[5];
	fis.device 	= req_task->io_ports[6] & ~0x10;

	if (mtip_test_bit(MTIP_DDF_FW_RESET_BIT, dd->flags)) {
		mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, dd,
			"Aborting internal command due to FW Reset\n");
		err = -EFAULT;
		goto abort;
	}

	if ((req_task->in_flags.all == 0) && (req_task->out_flags.all & 1)) {
		req_task->in_flags.all	=
			IDE_TASKFILE_STD_IN_FLAGS |
			(IDE_HOB_STD_IN_FLAGS << 8);
		fis.lba_low_ex		= req_task->hob_ports[3];
		fis.lba_mid_ex		= req_task->hob_ports[4];
		fis.lba_hi_ex		= req_task->hob_ports[5];
		fis.features_ex		= req_task->hob_ports[1];
		fis.sect_cnt_ex		= req_task->hob_ports[2];

	} else {
		req_task->in_flags.all = IDE_TASKFILE_STD_IN_FLAGS;
	}

	force_single_sector = implicit_sector(fis.command, fis.features);

	if ((taskin || taskout) && (!fis.sect_count)) {
		if (nsect)
			fis.sect_count = nsect;
		else {
			if (!force_single_sector) {
				dev_warn(&dd->pdev->dev,
					"data movement but sect_count is 0\n");
				err = -EINVAL;
				goto abort;
			}
		}
	}

	/* Lock the semaphore */
	down_write(&dd->sync_sem);

	/* Check for secure erase while fs mounted */
	if ((fis.command == ATA_CMD_SEC_SET_PASS)   ||
	    (fis.command == ATA_CMD_SEC_ERASE_PREP) ||
	    (fis.command == ATA_CMD_SEC_ERASE_UNIT) || 
	    (fis.command == 0xFC && fis.features == 0x12)) {
		if (dd->bdev && dd->bdev->bd_holders > 0) {
			dev_warn(&dd->pdev->dev, "Drive erase aborted due to non-zero refcount (%d)\n",
				dd->bdev->bd_holders);
			err = -ERESTARTSYS;
			up_write(&dd->sync_sem);
			goto abort;
		}
	}

	if (fis.command == 0xFC && fis.features == 0x12) {
		dev_info(&dd->pdev->dev,
			"Starting drive sanitize ...\n");
		do_id = 1;
	}

	dbg_printk("   %s: fis: cmd %x, feat %x, nsect %x, sect/lbal %x, lcyl/lbam %x, hcyl/lbah %x, head/dev %x\n",
		__func__,
		fis.command,
		fis.features,
		fis.sect_count,
		fis.lba_low,
		fis.lba_mid,
		fis.lba_hi,
		fis.device);

	if ((req_task->in_flags.all == 0) && (req_task->out_flags.all & 1)) {
		dbg_printk("   %s ext fis: lbal 0x%x, lbam 0x%x, lbah 0x%x, feat 0x%x, nsect 0x%x\n",
			__func__,
			fis.lba_low_ex,
			fis.lba_mid_ex,
			fis.lba_hi_ex,
			fis.features_ex,
			fis.sect_cnt_ex);
	}

	/* Internal IOCTL for getting the driver debug data */
	if (fis.command == 0xFC && fis.features == 0xC5 &&
	    fis.sector  == 0xA5 && fis.cyl_low  == 0x5A) {
		err = mtip_getdebugioctl(dd, &fis, req_task, inbuf, taskin);
		if (err == 0)
			goto cleanup;
	} else if (fis.command == 0xFC && 
		   fis.features == 0xE8) {
		mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, dd,
			"%s: Reset FW\n", __func__);
		mtip_set_bit(MTIP_DDF_FW_RESET_BIT, dd->flags);
	}

	/* Check if identify necessary */
	if (fis.command == 0xFB && fis.features == 0x94 && fis.lba_low == 0x6)
		do_id = 1;

	/* check for erase mode support during secure erase */
	if ((fis.command == ATA_CMD_SEC_ERASE_UNIT) && outbuf &&
			(outbuf[0] & MTIP_SEC_ERASE_MODE)) {
		erasemode = 1;
	}

	mtip_set_timeout(dd, &fis, &to, erasemode);

	/* Determine the correct transfer size */
	if (force_single_sector)
		transfer_size = ATA_SECT_SIZE;
	else
		transfer_size = ATA_SECT_SIZE * fis.sect_count;

	/* Execute the command */
	err = mtip_exec_internal_command(dd->port, &fis, 5, dma_buffer,
				 transfer_size, 0, GFP_KERNEL, to);
	if (err < 0) {
		switch (err) {
		case -EBUSY: /* Timeout */
		case -EFAULT: /* Generic error */
			do_id = 1;
			up_write(&dd->sync_sem);
			goto abort;
		case -EINTR: /* Interrupted */
			up_write(&dd->sync_sem);
			goto abort;
		case -EIO: /* Taskfile or similar error */
			do_id = 1;
			/* fall through */
		default:
			break;
		}
	}

	/* Fake successful command for FW Reset */
	if (mtip_test_bit(MTIP_DDF_FW_RESET_BIT, dd->flags)) {
		req_task->io_ports[7] = 0x50;
		req_task->io_ports[1] = 0;
		req_task->io_ports[2] = 0;
		req_task->io_ports[3] = 0;
		req_task->io_ports[4] = 0;
		req_task->io_ports[5] = 0;
		req_task->io_ports[6] = 0;
		err = 0;
		goto cleanup;
	}

	task_file_data = readl(dd->port->mmio + PORT_TFDATA);

	if ((req_task->data_phase == TASKFILE_IN) && !(task_file_data & 1)) {
		reply = dd->port->rxfis + RX_FIS_PIO_SETUP;
		req_task->io_ports[7] = reply->control;
	} else {
		reply = dd->port->rxfis + RX_FIS_D2H_REG;
		req_task->io_ports[7] = reply->command;
	}

	if (((fis.command == ATA_CMD_SEC_ERASE_PREP) && (reply->command & 1)) ||
		fis.command == ATA_CMD_SEC_ERASE_UNIT) {
		do_id = 1;
	}

	/* return the ATA registers to the caller */
	req_task->io_ports[1] = reply->features;
	req_task->io_ports[2] = reply->sect_count;
	req_task->io_ports[3] = reply->lba_low;
	req_task->io_ports[4] = reply->lba_mid;
	req_task->io_ports[5] = reply->lba_hi;
	req_task->io_ports[6] = reply->device;

	if (req_task->out_flags.all & 1)  {
		req_task->hob_ports[3] = reply->lba_low_ex;
		req_task->hob_ports[4] = reply->lba_mid_ex;
		req_task->hob_ports[5] = reply->lba_hi_ex;
		req_task->hob_ports[1] = reply->features_ex;
		req_task->hob_ports[2] = reply->sect_cnt_ex;
	}

	if (((fis.command == ATA_CMD_SEC_ERASE_UNIT) ||
	    ((fis.command == 0xFC) &&
		(fis.features == 0x27 || fis.features == 0x72 ||
		 fis.features == 0x62 || fis.features == 0x26))) &&
	    !(reply->command & 1)) {
		mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_DEBUG, dd,
			"Restarting port following sec erase / llformat\n");
		mtip_restart_port(dd->port);
	} else if (err == -EIO) { /* Command ended with Taskfile or similar */
		mtip_printk((MTIP_AHCI | MTIP_NONNCQ), MTIP_WARNING, dd,
			"Restarting port following failed internal cmd\n");
		mtip_restart_port(dd->port);
		/*
		 * Return good status to the caller
		 * Caller should parse taskfile registers to disposition
		 * command
		 */
		err = 0;
	}

	dbg_printk("   %s: completion: stat %x, err %x, sect_cnt %x, lbalo %x, lbamid %x, lbahi %x, dev %x\n",
		__func__,
		req_task->io_ports[7],
		req_task->io_ports[1],
		req_task->io_ports[2],
		req_task->io_ports[3],
		req_task->io_ports[4],
		req_task->io_ports[5],
		req_task->io_ports[6]);

	if (req_task->out_flags.all & 1) {
		dbg_printk("   %s: ext completion: lbal 0x%x, lbam 0x%x, lbah 0x%x, feat 0x%x, nsect 0x%x\n",
			__func__,
			req_task->hob_ports[3],
			req_task->hob_ports[4],
			req_task->hob_ports[5],
			req_task->hob_ports[1],
			req_task->hob_ports[2]);
	}

cleanup:
	up_write(&dd->sync_sem);

	if (taskout) {
		if (copy_to_user(buf + outtotal, outbuf, taskout))
			err = -EFAULT;
	}
	if (taskin) {
		if (copy_to_user(buf + intotal, inbuf, taskin))
			err = -EFAULT;
	}

abort:
	if (inbuf_dma)
		pci_unmap_single(dd->pdev, inbuf_dma,
					taskin, DMA_FROM_DEVICE);
	if (outbuf_dma)
		pci_unmap_single(dd->pdev, outbuf_dma,
					taskout, DMA_TO_DEVICE);
	if (outbuf)
		kfree(outbuf);

	if (inbuf)
		kfree(inbuf);

	if (do_id && !mtip_check_surprise_removal(dd))
		if (mtip_get_identify(dd->port, NULL) < 0)
			dev_warn(&dd->pdev->dev, "ID failed\n");

	return err;
}

/*
 * Handle IOCTL calls from the Block Layer.
 *
 * This function is called by the Block Layer when it receives an IOCTL
 * command that it does not understand. If the IOCTL command is not supported
 * this function returns -ENOTTY.
 *
 * @dd  Pointer to the driver data structure.
 * @cmd IOCTL command passed from the Block Layer.
 * @arg IOCTL argument passed from the Block Layer.
 *
 * return value
 *	0	The IOCTL completed successfully.
 *	-ENOTTY The specified command is not supported.
 *	-EFAULT An error occurred copying data to a user space buffer.
 *	-EIO	An error occurred while executing the command.
 */
static int mtip_hw_ioctl(struct driver_data *dd, unsigned int cmd,
			 unsigned long arg)
{
	switch (cmd) {
	case HDIO_GET_IDENTITY:
	{
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: HDIO_GET_IDENTITY from %s:%d\n",
			__func__, current->comm, current->pid);

		if (mtip_get_identify(dd->port, (void __user *) arg) < 0) {
			dev_warn(&dd->pdev->dev,
				"Unable to read identity\n");
			return -EIO;
		}
		break;
	}
	case HDIO_DRIVE_CMD:
	{
		u8 drive_command[4];

		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: HDIO_DRIVE_CMD from %s:%d\n",
			__func__, current->comm, current->pid);

		/* Copy the user command info to our buffer. */
		if (copy_from_user(drive_command,
					 (void __user *) arg,
					 sizeof(drive_command)))
			return -EFAULT;

		/* Execute the drive command. */
		if (exec_drive_command(dd->port,
					 drive_command,
					 (void __user *) (arg + 4)))
			return -EIO;

		/* Copy the status back to the users buffer. */
		if (copy_to_user((void __user *) arg,
					 drive_command,
					 sizeof(drive_command)))
			return -EFAULT;
		break;
	}
	case HDIO_DRIVE_TASK:
	{
		u8 drive_command[7];

		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: HDIO_DRIVE_TASK from %s:%d\n",
			__func__, current->comm, current->pid);

		/* Copy the user command info to our buffer. */
		if (copy_from_user(drive_command,
					 (void __user *) arg,
					 sizeof(drive_command)))
			return -EFAULT;

		/* Execute the drive command. */
		if (exec_drive_task(dd->port, drive_command) < 0)
			return -EIO;

		/* Copy the status back to the users buffer. */
		if (copy_to_user((void __user *) arg,
					 drive_command,
					 sizeof(drive_command)))
			return -EFAULT;
		break;
	}
	case HDIO_DRIVE_TASKFILE:
	{
		ide_task_request_t req_task;
		int ret, outtotal;

		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: HDIO_DRIVE_TASKFILE from %s:%d\n",
			__func__,
			current->comm,
			current->pid);

		if (copy_from_user(&req_task, (void __user *) arg,
					sizeof(req_task)))
			return -EFAULT;

		outtotal = sizeof(req_task);

		ret = exec_drive_taskfile(dd, (void __user *) arg,
						&req_task, outtotal);

		if (copy_to_user((void __user *) arg, &req_task,
							sizeof(req_task)))
			return -EFAULT;

		return ret;
	}
	case BLKFLSBUF:
	{
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: BLKFLSBUF from %s:%d\n",
			__func__,
			current->comm,
			current->pid);
		return 0;
	}
	default:
		mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
			"%s: Unknown ioctl 0x%x from %s:%d\n",
			__func__,
			cmd,
			current->comm,
			current->pid);
		return -EINVAL;
	}
	return 0;
}

/*
 * Release a command slot.
 *
 * @dd  Pointer to the driver data structure.
 * @tag Slot tag
 *
 * return value
 *      None
 */
static void mtip_hw_release_scatterlist(struct driver_data *dd, int tag,
								int unaligned)
{
	struct semaphore *sem = unaligned ? &dd->port->cmd_slot_unal :
							&dd->port->cmd_slot;
	release_slot(dd->port, tag);
	up(sem);
}

static int mtip_check_dd_flags(struct driver_data *dd, int is_write)
{
	int rv = 0;

	if (unlikely(*this_cpu_ptr(dd->flags) & MTIP_DDF_FAIL_IO)) {
		rv = -EIO;
		if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
			rv = -ENXIO;
		else if (mtip_test_bit(MTIP_DDF_SR_BIT, dd->flags))
			rv = -ENODEV;
		else if (mtip_test_bit(MTIP_DDF_OVER_TEMP_BIT, dd->flags))
			rv = -ENODATA;
		else if (mtip_test_bit(MTIP_DDF_FW_RESET_BIT, dd->flags))
			rv = -ENODATA;
		else if (mtip_test_bit(MTIP_DDF_QUIESCE_BIT, dd->flags))
			rv = -ENODATA;
		else if (mtip_test_bit(MTIP_DDF_SE_ACTIVE_BIT, dd->flags))
			rv = -ENODATA;
		else if (mtip_test_bit(MTIP_DDF_WRITE_PROTECT_BIT, dd->flags))
			rv = is_write ? -ENODATA : 0;
	}
	return rv;
}


/*
 * Submit an IO to the hw
 *
 * This function is called by the block layer to issue an io
 * to the device. Upon completion, the callback function will
 * be called with the data parameter passed as the callback data.
 *
 * @dd       Pointer to the driver data structure.
 * @start    First sector to read.
 * @nsect    Number of sectors to read.
 * @nents    Number of entries in scatter list for the read command.
 * @tag      The tag of this read command.
 * @callback Pointer to the function that should be called
 *	     when the read completes.
 * @data     Callback data passed to the callback function
 *	     when the read completes.
 * @dir      Direction (read or write)
 *
 * return value
 *	None
 */
static void mtip_hw_submit_io(struct driver_data *dd, sector_t sector,
			      int nsect, int nents, int tag, void *callback,
			      void *data, int dir, int fua,
			      unsigned long starttime, int unaligned)
{
	struct host_to_dev_fis *fis;
	struct mtip_port *port = dd->port;
	struct mtip_cmd *command = &port->commands[tag];
	int dma_dir = dir ? DMA_TO_DEVICE : DMA_FROM_DEVICE;
	u64 start = sector;
	int rv;

	prefetch(command->command);

	/* Map the scatter list for DMA access */
	pci_dev_get(dd->pdev);
	command->scatter_ents = dma_map_sg(&dd->pdev->dev, command->sg, nents,
								dma_dir);

	/*
	 * The number of retries for this command before it is
	 * reported as a failure to the upper layers.
	 */
	command->retries = MTIP_MAX_RETRIES;

	command->unaligned = unaligned;

	/* Save start time */
	command->start_time = starttime;

	/* Fill out fis */
	fis = command->command;
	fis->type        = 0x27;
	fis->opts        = 1 << 7;
	fis->command     =
		(dir == READ ? ATA_CMD_FPDMA_READ : ATA_CMD_FPDMA_WRITE);
	fis->lba_low     = start & 0xFF;
	fis->lba_mid     = (start >> 8) & 0xFF;
	fis->lba_hi      = (start >> 16) & 0xFF;
	fis->lba_low_ex  = (start >> 24) & 0xFF;
	fis->lba_mid_ex  = (start >> 32) & 0xFF;
	fis->lba_hi_ex   = (start >> 40) & 0xFF;
	fis->device	 = 1 << 6;
	if (unlikely(fua || unaligned || __get_cpu_var(pcpu_force_fua)))
		fis->device |= FUA_BIT;
	fis->features    = nsect & 0xFF;
	fis->features_ex = (nsect >> 8) & 0xFF;
	WARN_ON(((unsigned) nsect & 0xffff) == 0);
	fis->sect_count  = ((tag << 3) | (tag >> 5));
	fis->sect_cnt_ex = 0;
	fis->control     = 0;
	fis->res2        = 0;
	fis->res3        = 0;
	fill_command_sg(dd, command, command->scatter_ents);

#ifdef MTIP_DEBUGLOG
	debuglog_io_start(dd, command, dir == READ ? READ : WRITE, sector,
					nsect, ((struct bio *) data)->bi_rw);
#endif

	/* 
	 * Populate the command header
	 * No need to set Write bit in header for writes
	 */
	command->command_header->opts =
		__force_bit2int cpu_to_le32((command->scatter_ents << 16) | 5
						| AHCI_CMD_PREFETCH);
	command->command_header->byte_count = 0;

	/*
	 * Set the completion function and data for the command
	 * within this layer.
	 */
	command->comp_data = dd;
	command->comp_func = mtip_async_complete;
	command->direction = dma_dir;

	/*
	 * Set the completion function and data for the command passed
	 * from the upper layer.
	 */
	command->async_data = data;
	command->async_callback = callback;

	/* Synchronize with internal IO path */
	down_read(&dd->sync_sem);

	/* Re-check flags */
	if ((rv = mtip_check_dd_flags(dd, dma_dir == DMA_TO_DEVICE)) != 0) {
		if (__get_cpu_var(pcpu_queue_mode) == 1) { 
			mtip_complete_req((struct request *) data, -EIO);
		} else {
			struct bio *bio = (struct bio *) data;
			diskstat_abort(dd, bio);
			mtip_bio_endio(bio, bio->bi_size, -EIO);
		}
		dma_unmap_sg(&dd->pdev->dev, command->sg, nents, dma_dir);
		pci_dev_put(dd->pdev);

		command->comp_data = NULL;
		command->comp_func = NULL;
		command->async_data = NULL;
		command->async_callback = NULL;

		if (dd->port)
			mtip_hw_release_scatterlist(dd, tag, unaligned);

		up_read(&dd->sync_sem);
		return;
	}

	if (unlikely(*this_cpu_ptr(dd->flags) & MTIP_DDF_QUEUE_IO)) {
		/* Queue it */
		set_bit(tag, port->cmds_to_issue);
		mtip_set_bit(MTIP_DDF_ISSUE_CMDS_BIT, dd->flags);
		/* skip wakeup, clearing of QUEUE condition will wake thread */
		up_read(&dd->sync_sem);
		return;
	}

	/* Issue the command to the hardware */
	mtip_issue_ncq_command(port, tag);

	/* Synchronize with internal IO path */
	up_read(&dd->sync_sem);

	return;
}

/*
 * Obtain a command slot and return its associated scatter list.
 *
 * @dd  Pointer to the driver data structure.
 * @tag Pointer to an int that will receive the allocated command
 *            slot tag.
 *
 * return value
 *	Pointer to the scatter list for the allocated command slot
 *	or NULL if no command slots are available.
 */
static struct scatterlist *mtip_hw_get_scatterlist(struct driver_data *dd,
						   int *tag, int unaligned)
{
	struct semaphore *sem = unaligned ? &dd->port->cmd_slot_unal :
							&dd->port->cmd_slot;

	/*
	 * It is possible that, even with this semaphore, a thread
	 * may think that no command slots are available. Therefore, we
	 * need to make an attempt to get_slot().
	 */
	down(sem);
	*tag = get_slot(dd->port);

	if (unlikely(*tag < 0)) {
		up(sem);
		return NULL;
	}

	return dd->port->commands[*tag].sg;
}

/*
 * Sysfs status dump.
 *
 * @dev  Pointer to the device structure, passed by the kernel.
 * @attr Pointer to the device_attribute structure passed by the kernel.
 * @buf  Pointer to the char buffer that will receive the stats info.
 *
 * return value
 *      The size, in bytes, of the data copied into buf.
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
static ssize_t mtip_hw_show_status(struct device *dev,
				struct device_attribute *attr,
				char *buf)
#else
static ssize_t mtip_hw_show_status(struct gendisk *disk, char *buf)
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	struct driver_data *dd = dev_to_disk(dev)->private_data;
#else
	struct driver_data  *dd = disk->private_data;
#endif
	int size = 0;
	if (mtip_test_bit(MTIP_DDF_OVER_TEMP_BIT, dd->flags))
		size += sprintf(buf, "%s", "thermal_shutdown\n");
	else if (mtip_test_bit(MTIP_DDF_WRITE_PROTECT_BIT, dd->flags))
		size += sprintf(buf, "%s", "write_protect\n");
	else
		size += sprintf(buf, "%s", "online\n");
	return size;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
static DEVICE_ATTR(status, S_IRUGO, mtip_hw_show_status, NULL);
#else
static struct disk_attribute dev_attr_status = {
	/* filename, owner, attributes */
	.attr  = { "status", THIS_MODULE, S_IRUGO },
	.show  = mtip_hw_show_status,
	.store = NULL
};
#endif

/*
 * Create the sysfs related attributes.
 *
 * @dd   Pointer to the driver data structure.
 * @kobj Pointer to the kobj for the block device.
 *
 * return value
 *	0	Operation completed successfully.
 *	-EINVAL Invalid parameter.
 */
static int mtip_hw_sysfs_init(struct driver_data *dd, struct kobject *kobj)
{
	if (!kobj || !dd)
		return -EINVAL;

	if (sysfs_create_file(kobj, &dev_attr_status.attr))
		dev_warn(&dd->pdev->dev,
			"Error creating 'status' sysfs entry.\n");
	mtip_extra_sysfs_init(dd, kobj);
	mtip_set_bit(MTIP_DDF_SYSFS_INIT_BIT, dd->flags);
	return 0;
}

/*
 * Remove the sysfs related attributes.
 *
 * @dd   Pointer to the driver data structure.
 * @kobj Pointer to the kobj for the block device.
 *
 * return value
 *	0	Operation completed successfully.
 *	-EINVAL Invalid parameter.
 */
static int mtip_hw_sysfs_exit(struct driver_data *dd, struct kobject *kobj)
{
	if (!kobj || !dd)
		return -EINVAL;

	if (mtip_test_bit(MTIP_DDF_SYSFS_INIT_BIT, dd->flags)) {
		sysfs_remove_file(kobj, &dev_attr_status.attr);
		mtip_extra_sysfs_destroy(dd, kobj);
	}

	mtip_clear_bit(MTIP_DDF_SYSFS_INIT_BIT, dd->flags);
	return 0;
}

static ssize_t mtip_hw_read_registers(struct file *f, char __user *ubuf,
						size_t len, loff_t *offset)
{
	struct driver_data *dd = (struct driver_data *) f->private_data;
	char *buf;
	u32 group_allocated;
	int size = *offset;
	int n;

	if (!len || size)
		return 0;

	buf = kzalloc(MTIP_DFS_MAX_BUF_SIZE, GFP_KERNEL);
	if (!buf)
		return -ENOMEM;

	size += sprintf(&buf[size], "H/ S ACTive      : [ 0x");
	for (n = MTIP_MAX_SLOT_GROUPS - 1; n >= 0; n--)
		size += sprintf(&buf[size], "%08X ",
						readl(dd->port->s_active[n]));
	size += sprintf(&buf[size], "]\n");
	size += sprintf(&buf[size], "H/ Command Issue : [ 0x");
	for (n = MTIP_MAX_SLOT_GROUPS - 1; n >= 0; n--)
		size += sprintf(&buf[size], "%08X ",
						readl(dd->port->cmd_issue[n]));
	size += sprintf(&buf[size], "]\n");
	size += sprintf(&buf[size], "H/ Completed     : [ 0x");
	for (n = MTIP_MAX_SLOT_GROUPS - 1; n >= 0; n--)
		size += sprintf(&buf[size], "%08X ",
						readl(dd->port->completed[n]));
	size += sprintf(&buf[size], "]\n");
	size += sprintf(&buf[size], "H/ PORT IRQ STAT : [ 0x%08X ]\n",
					readl(dd->port->mmio + PORT_IRQ_STAT));
	size += sprintf(&buf[size], "H/ HOST IRQ STAT : [ 0x%08X ]\n",
					readl(dd->mmio + HOST_IRQ_STAT));
	size += sprintf(&buf[size], "\n");
	size += sprintf(&buf[size], "L/ Allocated     : [ 0x");
	for (n = MTIP_MAX_SLOT_GROUPS - 1; n >= 0; n--) {
		if (sizeof(long) > sizeof(u32))
			group_allocated =
			dd->port->allocated[n/2] >> (32 * (n & 1));
		else
			group_allocated = dd->port->allocated[n];
		size += sprintf(&buf[size], "%08X ", group_allocated);
	}
	size += sprintf(&buf[size], "]\n");
	size += sprintf(&buf[size], "L/ Commands in Q : [ 0x");
	for (n = MTIP_MAX_SLOT_GROUPS - 1; n >= 0; n--) {
		if (sizeof(long) > sizeof(u32))
			group_allocated =
				dd->port->cmds_to_issue[n/2] >> (32 * (n & 1));
		else
			group_allocated = dd->port->cmds_to_issue[n];
		size += sprintf(&buf[size], "%08X ", group_allocated);
	}

	size += sprintf(&buf[size], "]\n");
	*offset = size <= len ? size : len;
	size = copy_to_user(ubuf, buf, *offset);
	kfree(buf);

	if (size)
		return -EFAULT;
	return *offset;
}

static ssize_t mtip_hw_read_flags(struct file *f, char __user *ubuf,
					size_t len, loff_t *offset)
{
	struct driver_data *dd = (struct driver_data *) f->private_data;
	char *buf;
	int size = *offset;

	if (!len || size)
		return 0;

	buf = kzalloc(MTIP_DFS_MAX_BUF_SIZE, GFP_KERNEL);
	if (!buf)
		return -ENOMEM;

	size += sprintf(&buf[size], "Flag-dd   : [ %08lX ]\n",
					*this_cpu_ptr(dd->flags));
	*offset = size <= len ? size : len;
	size = copy_to_user(ubuf, buf, *offset);
	kfree(buf);

	if (size)
		return -EFAULT;
	return *offset;
}

static const struct file_operations mtip_regs_fops = {
	.owner  = THIS_MODULE,
	.open   = mtip_simple_open,
	.read   = mtip_hw_read_registers,
	.llseek = no_llseek,
};

static const struct file_operations mtip_flags_fops = {
	.owner  = THIS_MODULE,
	.open   = mtip_simple_open,
	.read   = mtip_hw_read_flags,
	.llseek = no_llseek,
};

static int mtip_hw_debugfs_init(struct driver_data *dd)
{
	if (!dfs_parent) {
		dev_warn(&dd->pdev->dev,
			"Unable to create debugfs entries: no parent\n");
		return -EFAULT;
	}
	dd->dfs_node = debugfs_create_dir(dd->disk->disk_name, dfs_parent);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
	if (IS_ERR_OR_NULL(dd->dfs_node)) {
#else
	if (!dd->dfs_node) {
#endif
		dev_warn(&dd->pdev->dev,
			"Error creating node %s under debugfs\n",
			dd->disk->disk_name);
		dd->dfs_node = NULL;
		return -EFAULT;
	}

	dd->dfs_flags = debugfs_create_file("flags", S_IRUGO, dd->dfs_node, dd,
							&mtip_flags_fops);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
	if (IS_ERR_OR_NULL(dd->dfs_flags)) {
#else
	if (!dd->dfs_flags) {
#endif
		dev_warn(&dd->pdev->dev,
			"Error creating node %s/flags under debugfs\n",
			dd->disk->disk_name);
		dd->dfs_flags = NULL;
	}

	dd->dfs_registers = debugfs_create_file("registers", S_IRUGO,
							dd->dfs_node, dd,
							&mtip_regs_fops);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
	if (IS_ERR_OR_NULL(dd->dfs_registers)) {
#else
	if (!dd->dfs_registers) {
#endif
		dev_warn(&dd->pdev->dev,
			"Error creating node %s/registers under debugfs\n",
			dd->disk->disk_name);
		dd->dfs_registers = NULL;
	}

	return 0;
}

static void mtip_hw_debugfs_exit(struct driver_data *dd)
{
	if (dfs_parent && dd->dfs_node) {
		if (dd->dfs_registers) {
			debugfs_remove(dd->dfs_registers);
			dd->dfs_registers = NULL;
		}
		if (dd->dfs_flags) {
			debugfs_remove(dd->dfs_flags);
			dd->dfs_flags = NULL;
		}
		debugfs_remove(dd->dfs_node);
	}
	dd->dfs_node = NULL;
}

/*
 * Perform any init/resume time hardware setup
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	None
 */
static inline void hba_setup(struct driver_data *dd)
{
	u32 hwdata;
	hwdata = readl(dd->mmio + HOST_HSORG);

	/* interrupt bug workaround: use only 1 IS bit */
	writel(hwdata |
		HSORG_DISABLE_SLOTGRP_INTR |
		HSORG_DISABLE_SLOTGRP_PXIS,
		dd->mmio + HOST_HSORG);
}

/*
 * Detect the details of the product, and store anything needed
 * into the driver data structure.  This includes product type and
 * version and number of slot groups.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	None
 */
static int mtip_detect_product(struct driver_data *dd)
{
	u32 hwdata;
	unsigned int rev, slotgroups;

	/*
	 * HBA base + 0xFC [15:0] - vendor-specific hardware interface
	 * info register:
	 * [15:8] hardware/software interface rev#
	 * [   3] asic-style interface
	 * [ 2:0] number of slot groups, minus 1 (only valid for asic-style)
	 */
	hwdata = readl(dd->mmio + HOST_HSORG);
	if (hwdata & 0x8) {
		rev = (hwdata & HSORG_HWREV) >> 8;
		slotgroups = (hwdata & HSORG_SLOTGROUPS) + 1;
		dev_info(&dd->pdev->dev,
			"ASIC-FPGA design, HS rev 0x%x, %i slot groups [%i slots]\n",
			rev, slotgroups, slotgroups * 32);
		WARN_ON(slotgroups != MTIP_MAX_SLOT_GROUPS);
		return MTIP_PRODUCT_ASICFPGA;
	}

	dev_warn(&dd->pdev->dev, "Unrecognized product id\n");
	return MTIP_PRODUCT_UNKNOWN;
}

static int mtip_drive_rebuild(struct driver_data *dd)
{
	if (dd && dd->port) {
		if (dd->port->identify_valid &&
			(*(dd->port->identify + MTIP_FTL_REBUILD_OFFSET) ==
				MTIP_FTL_REBUILD_MAGIC)) {
			return 1;
		}
	}
	return 0;
}

/*
 * Blocking wait for FTL rebuild to complete
 *
 * @dd Pointer to the driver_data structure.
 *
 * return value
 *	0	FTL rebuild completed successfully
 *	-EFAULT FTL rebuild error/timeout/interruption
 *      For other values, see return codes from mtip_block_initialize()
 */
static int mtip_ftl_rebuild_poll(struct driver_data *dd)
{
	unsigned long timeout, cnt = 0, start;

	dev_warn(&dd->pdev->dev,
		"FTL rebuild in progress. Polling for completion.\n");

	if (dd->port->identify_valid &&
		(dd->port->identify[89] & 0xf))
		timeout = (dd->port->identify[89] & 0xf) * 2 * 60 * 1000 * 100;
	else
		timeout = MTIP_FTL_REBUILD_TIMEOUT_MS;

	start = jiffies;
	timeout = jiffies + msecs_to_jiffies(timeout);

	do {
		if (kthread_should_stop() ||
			mtip_test_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags) ||
			mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
			return -EFAULT;

		if (mtip_check_surprise_removal(dd))
			return -EFAULT;

		if (mtip_get_identify(dd->port, NULL) < 0)
			return -EFAULT;

		if (mtip_drive_rebuild(dd)) {
			/* Print message every 3 minutes */
			if (cnt++ >= 180) {
				dev_warn(&dd->pdev->dev,
					"FTL rebuild in progress "
					"(%d secs).\n",
					jiffies_to_msecs(jiffies - start)
					/ 1000);
				cnt = 0;
			}
			ssleep(1);
		} else {
			dev_warn(&dd->pdev->dev,
				"FTL rebuild complete (%d secs).\n",
				jiffies_to_msecs(jiffies - start) / 1000);

			/* Free any orphans */
			mtip_free_orphans();

			return mtip_block_initialize(dd);
		}
	} while (time_before(jiffies, timeout));

	/* Check for timeout */
	dev_err(&dd->pdev->dev,
		"Timed out waiting for FTL rebuild to complete (%d secs).\n",
		jiffies_to_msecs(jiffies - start) / 1000);

	return -EFAULT;
}

static int mtip_disposition_queued_cmds(struct mtip_port *port)
{
	int issue_cnt = 0, fail_cnt = 0;
	struct driver_data *dd = port->dd;
	unsigned long slot = 1, slot_wrap = 0;
	unsigned int num_cmd_slots = MTIP_MAX_SLOT_GROUPS * 32;
	unsigned long issue_accum[SLOTBITS_IN_LONGS];
	unsigned long fail_accum[SLOTBITS_IN_LONGS];

	memset(issue_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));
	memset(fail_accum, 0, SLOTBITS_IN_LONGS * sizeof(long));

	/* Lock out ioctl/make_request() path while submitting queued IO */
	down_write(&dd->sync_sem);
	while (1) {
		slot = find_next_bit(port->cmds_to_issue, num_cmd_slots, slot);
		if (slot >= num_cmd_slots) {
			slot = 1;
			if (++slot_wrap >= 2)
				break;
			continue;
		}

		WARN_ON(slot == MTIP_TAG_INTERNAL);

		if (*this_cpu_ptr(dd->flags) & MTIP_DDF_FAIL_IO) {
			int rv = -EIO;
			struct mtip_cmd *cmd = &port->commands[slot];
			if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
								dd->flags))
				rv = -ENXIO;
			else if (mtip_test_bit(MTIP_DDF_OVER_TEMP_BIT,
								dd->flags))
				rv = -ENODATA;
			else if (mtip_test_bit(MTIP_DDF_FW_RESET_BIT,
								dd->flags))
				rv = -ENODATA;
			else if (mtip_test_bit(MTIP_DDF_SR_BIT, dd->flags))
				rv = -ENODEV;
			else if (mtip_test_bit(MTIP_DDF_WRITE_PROTECT_BIT,
								dd->flags)) {
				if (cmd->direction == DMA_TO_DEVICE)
					rv = -ENODATA;
				else
					goto issue_io;
			}
			fail_cnt++;
			set_bit(slot, fail_accum);

			/* Mark inactive */
			atomic_set(&cmd->active, 0);

			if (cmd->comp_func)
				cmd->comp_func(port, slot, cmd->comp_data, rv);
			else
				dev_err(&dd->pdev->dev,
					"NULL completion for tag %ld\n", slot);

			clear_bit(slot, port->cmds_to_issue);
			continue;
		}

		if (mtip_test_bit(MTIP_DDF_SE_ACTIVE_BIT, dd->flags)) {
#if 0
			dev_info(&dd->pdev->dev, 
				"%s: skipping issue due to SE_ACTIVE\n",
				__func__);
#endif
			up_write(&dd->sync_sem);
			/* don't clear MTIP_DDF_ISSUE_CMDS_BIT */
			return -EINVAL;
		}

issue_io:
		/* Issue the command to the hardware */
		mtip_issue_ncq_command(port, slot);
		clear_bit(slot, port->cmds_to_issue);
		issue_cnt++;
		set_bit(slot, issue_accum);

		if (mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags)) {
			dev_info(&dd->pdev->dev,
				"%s: Interrupted after %d cmd(s) for TFE\n",
				__func__, issue_cnt);

			up_write(&dd->sync_sem);
			/* don't clear MTIP_DDF_ISSUE_CMDS_BIT */
			return -ERESTARTSYS;
		}
	}
	mtip_clear_bit(MTIP_DDF_ISSUE_CMDS_BIT, port->dd->flags);
	up_write(&dd->sync_sem);

	if (issue_cnt) {
		dev_info(&dd->pdev->dev, "%s: Issued %d command(s)\n",
						__func__, issue_cnt);
		print_tags(dd, "  Issued   ", issue_accum, issue_cnt);
	}
	if (fail_cnt) {
		dev_warn(&dd->pdev->dev, "%s: Failed %d command(s)\n",
			__func__, fail_cnt);
		print_tags(dd, "  Failed   ", fail_accum, fail_cnt);
	}

#if 0	/* This does not appear to be necessary */
	if (!mtip_check_surprise_removal(dd)) {
		u32 port_is, hba_is;

		/* re-enable interrupts */
		port_is = readl(port->mmio + PORT_IRQ_STAT);
		if (port_is) {
			printk(KERN_INFO "%s: clearing port %x\n", __func__, port_is);
			writel(port_is, port->mmio + PORT_IRQ_STAT);
		}
		hba_is = readl(dd->mmio + HOST_IRQ_STAT);
		if (hba_is) {
			printk(KERN_INFO "%s: clearing hba %x\n", __func__, hba_is);
			writel(hba_is, dd->mmio + HOST_IRQ_STAT);
		}
	}
#endif

	return issue_cnt;
}

/*
 * service thread to issue queued commands
 *
 * @data Pointer to the driver data structure.
 *
 * return value
 *	0
 */
static int mtip_service_thread(void *data)
{
	int rv = 0;
	struct driver_data *dd = (struct driver_data *) data;
	char buf[MTIP_FLAGS_BUFLEN];

	memset(buf, 0, MTIP_FLAGS_BUFLEN);

	while (1) {

		if (kthread_should_stop() ||
			mtip_test_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags))
			break;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 22)
			try_to_freeze();
#endif

		/*
		 * the condition is to check neither an internal command is
		 * is in progress nor error handling is active
		 */
		dbg_printk("%s:%d waiting ...\n", current->comm, current->pid);

		rv = wait_event_interruptible(dd->svc_wait,
			*this_cpu_ptr(dd->flags) & MTIP_DDF_SVC_THD_WORK);

		if (kthread_should_stop() ||
			mtip_test_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags))
			break;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 22)
			try_to_freeze();
#endif

		mtip_decode_flags(dd->flags, buf, MTIP_FLAGS_BUFLEN);
		dbg_printk("%s:%d woke up: surprise %d, remove_pending %d "
			"(flags: %08lx -> %s)\n", current->comm, current->pid,
			mtip_check_surprise_removal(dd),
			!!mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
								dd->flags),
			*this_cpu_ptr(dd->flags), buf);

restart_eh:
		/* Demux bits: start with error handling */
		if (mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags)) {

			mtip_error_handler(dd);
			mtip_clear_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags);

		}

		/* Next: timeout handling */
		if (mtip_test_bit(MTIP_DDF_TO_ACTIVE_BIT, dd->flags)) {

			mtip_timeout_handler(dd, 0);
			mtip_clear_bit(MTIP_DDF_TO_ACTIVE_BIT, dd->flags);

		}

		if (mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags))
			goto restart_eh;

		/* Next: reissue queued commands */
		if (mtip_test_bit(MTIP_DDF_ISSUE_CMDS_BIT, dd->flags)) {
			if (mtip_disposition_queued_cmds(dd->port) == 
								-ERESTARTSYS)
				goto restart_eh;
		} 

		/* Last: FTL rebuild */
		if (mtip_test_bit(MTIP_DDF_REBUILD_BIT, dd->flags)) {
			if (mtip_ftl_rebuild_poll(dd) < 0)
				mtip_set_bit(MTIP_DDF_REBUILD_FAILED_BIT,
							dd->flags);
			mtip_clear_bit(MTIP_DDF_REBUILD_BIT, dd->flags);
		}

		if (kthread_should_stop() ||
			mtip_test_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags))
			break;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 22)
			try_to_freeze();
#endif

		/* double check */
		if (mtip_test_bit(MTIP_DDF_TO_ACTIVE_BIT, dd->flags)  ||
		    mtip_test_bit(MTIP_DDF_EH_ACTIVE_BIT, dd->flags)) {
			dev_warn(&dd->pdev->dev,
				"Re-activated handler: flags %lx\n",
				*this_cpu_ptr(dd->flags));
			goto restart_eh;
		}

	} /* end while(1) { */

	__set_current_state(TASK_RUNNING);

	return 0;
}

/* Log some useful info about the state of the drive */
static void mtip_hw_info(struct driver_data *dd)
{
	int rv;
	struct smart_attr attr242;
 
	/* check write protect, over temp and rebuild statuses */
	rv = mtip_read_log_page(dd->port, ATA_LOG_SATA_NCQ,
				dd->port->log_buf,
				dd->port->log_buf_dma, 1);
	if (rv) {
		dev_warn(&dd->pdev->dev,
			"Error in READ LOG EXT (10h) command\n");
		/* non-critical error, don't fail the load */
	} else {
		unsigned char *buf = (unsigned char *) dd->port->log_buf;
		if (buf[259] & 0x1) {
			dev_info(&dd->pdev->dev,
				"Write protect bit is set.\n");
			mtip_set_bit(MTIP_DDF_WRITE_PROTECT_BIT, dd->flags);
		}
		if (buf[288] == 0xF7) {
			dev_info(&dd->pdev->dev,
				"Exceeded Tmax, drive in thermal shutdown.\n");
			mtip_set_bit(MTIP_DDF_OVER_TEMP_BIT, dd->flags);
		} else if (buf[288] == 0xBF) {
			char cbuf[42];
			memset(cbuf, 0, 42);

			mtip_set_bit(MTIP_DDF_SEC_LOCK_BIT, dd->flags);
			strlcpy(cbuf, (char *) (dd->port->identify + 10), 21);
			dev_warn(&dd->pdev->dev,
				"Physical device %s is in security locked "
				"state.\n", cbuf);
		}
		if (buf[289] == 0xCE) {
			dev_info(&dd->pdev->dev,
				"Drive is undergoing sanitization.\n");
			/* TODO: Add sanitize status checking/logging */
		}
	}

	/* Write protect progress */
	memset(&attr242, 0, sizeof(struct smart_attr));

	if (mtip_get_smart_attr(dd->port, 242, &attr242)) {
		dev_warn(&dd->pdev->dev,
			"Unable to check write protect progress\n");
	} else {
		dev_info(&dd->pdev->dev,
			"Write protect progress: %u%% (%u blocks)\n",
			attr242.cur, le32_to_cpu(attr242.data));
	}
}

/*
 * DMA region setup
 *
 * @dd Pointer to driver_data structure
 *
 * return value
 * 	None
 */
static void mtip_dma_free(struct driver_data *dd)
{
	int i;
	struct mtip_port *port = dd->port;

	if (port->block1) {
		dmam_free_coherent(&dd->pdev->dev, BLOCK_DMA_ALLOC_SZ,
					port->block1, port->block1_dma);
		port->block1        = NULL;
		port->block1_dma    = 0;
		port->rxfis         = NULL;
		port->rxfis_dma     = 0;
		port->identify      = NULL;
		port->identify_dma  = 0;
		port->log_buf       = NULL;
		port->log_buf_dma   = 0;
		port->smart_buf     = NULL;
		port->smart_buf_dma = 0;
	}

	if (port->command_list) {
		dmam_free_coherent(&dd->pdev->dev, AHCI_CMD_TBL_SZ,
				port->command_list, port->command_list_dma);
		port->command_list = NULL;
		port->command_list_dma = 0;
	}

	for (i = 0; i < MTIP_MAX_COMMAND_SLOTS; i++) {
		if (port->commands[i].command)
			dmam_free_coherent(&dd->pdev->dev, CMD_DMA_ALLOC_SZ,
				port->commands[i].command,
				port->commands[i].command_dma);
		port->commands[i].command            = NULL;
		port->commands[i].command_dma        = 0;
		port->commands[i].command_header     = NULL;
		port->commands[i].command_header_dma = 0;
	}
}

/*
 * DMA region setup
 *
 * @dd Pointer to driver_data structure
 *
 * return value
 * 	-ENOMEM	Not enough free DMA region space to initialize driver
 */
static int mtip_dma_alloc(struct driver_data *dd)
{
	struct mtip_port *port = dd->port;
	int i, rv = 0;
	u32 host_cap_64 = readl(dd->mmio + HOST_CAP) & HOST_CAP_64;

	/* Allocate dma memory for RX Fis, Identify, and Sector Bufffer */
	port->block1 =
		dmam_alloc_coherent(&dd->pdev->dev, BLOCK_DMA_ALLOC_SZ,
						&port->block1_dma, GFP_KERNEL);
	if (!port->block1) {
		dev_err(&dd->pdev->dev,
			"Memory allocation: first block\n");
		return -ENOMEM;
	}
	memset(port->block1, 0, BLOCK_DMA_ALLOC_SZ);

	/* Allocate dma memory for command list */
	port->command_list =
		dmam_alloc_coherent(&dd->pdev->dev, AHCI_CMD_TBL_SZ,
					&port->command_list_dma, GFP_KERNEL);
	if (!port->command_list) {
		dev_err(&dd->pdev->dev,
			"Memory allocation: command list\n");
		dmam_free_coherent(&dd->pdev->dev, BLOCK_DMA_ALLOC_SZ,
					port->block1, port->block1_dma);
		port->block1 = NULL;
		port->block1_dma = 0;
		return -ENOMEM;
	}
	memset(port->command_list, 0, AHCI_CMD_TBL_SZ);

	/* 
	 * Size of command_list should be 8192 if packing is correct
	 * (this may need to be changed in the SGL container size is increased)
	 */
	WARN_ON_ONCE(AHCI_CMD_TBL_SZ != 8192);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	/* Warn if memory somehow came from wrong node */
	if (page_to_nid(virt_to_page(port->block1)) != dd->numa_node ||
	    page_to_nid(virt_to_page(port->command_list)) != dd->numa_node) {
		dev_warn(&dd->pdev->dev,
			"Warning: DMA memory not on node %d: "
			"%p/%llu on %d, "
			"%p/%llu on %d\n",
			dd->numa_node, port->block1, port->block1_dma,
			(int) page_to_nid(virt_to_page(port->block1)),
			port->command_list, port->command_list_dma,
			(int) page_to_nid(virt_to_page(port->command_list)));
	}
#endif

	/* Setup all pointers into first DMA region */
	port->rxfis         = port->block1 + AHCI_RX_FIS_OFFSET;
	port->rxfis_dma     = port->block1_dma + AHCI_RX_FIS_OFFSET;
	port->identify      = port->block1 + AHCI_IDFY_OFFSET;
	port->identify_dma  = port->block1_dma + AHCI_IDFY_OFFSET;
	port->log_buf       = port->block1 + AHCI_SECTBUF_OFFSET;
	port->log_buf_dma   = port->block1_dma + AHCI_SECTBUF_OFFSET;
	port->smart_buf     = port->block1 + AHCI_SMARTBUF_OFFSET;
	port->smart_buf_dma = port->block1_dma + AHCI_SMARTBUF_OFFSET;

	dbg_printk("First Block @ %p/%llu (%d):\n"
		"\tRX FIS:   %p/%llu (%d)\n"
		"\tIdentify: %p/%llu (%d)\n"
		"\tRLE10:    %p/%llu (%d)\n"
		"\tSMART:    %p/%llu (%d)\n",
		port->block1, port->block1_dma, BLOCK_DMA_ALLOC_SZ,
		port->rxfis, port->rxfis_dma, AHCI_RX_FIS_SZ,
		port->identify, port->identify_dma, ATA_SECT_SIZE,
		port->log_buf, port->log_buf_dma, ATA_SECT_SIZE,
		port->smart_buf, port->smart_buf_dma, ATA_SECT_SIZE);

	dbg_printk("Command List @ %p/%llu (%lu)\n",
		port->command_list, port->command_list_dma,
		(unsigned long) AHCI_CMD_TBL_SZ);

	/* Setup per command SGL DMA region */

	/* Point the command headers at the command tables */
	for (i = 0; i < MTIP_MAX_COMMAND_SLOTS; i++) {
		port->commands[i].command =
			dmam_alloc_coherent(&dd->pdev->dev, CMD_DMA_ALLOC_SZ,
				&port->commands[i].command_dma, GFP_KERNEL);
		if (!port->commands[i].command) {
			dev_err(&dd->pdev->dev,
				"Memory allocation: command %d\n", i);
			rv = -ENOMEM;
			mtip_dma_free(dd);
			return rv;
		}
		memset(port->commands[i].command, 0, CMD_DMA_ALLOC_SZ);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
		/* Warn if memory somehow came from wrong node */
		if (page_to_nid(virt_to_page(port->commands[i].command))
							!= dd->numa_node) {
			dev_warn(&dd->pdev->dev,
				"Warning: cmd %d: DMA memory not on node %d: "
				"%p/%llu on %d\n",
				i, dd->numa_node, port->commands[i].command,
				port->commands[i].command_dma,
				(int) page_to_nid(virt_to_page(
					port->commands[i].command)));
		}
#endif

		port->commands[i].command_header = port->command_list +
					(sizeof(struct mtip_cmd_hdr) * i);
		port->commands[i].command_header_dma =
					dd->port->command_list_dma +
					(sizeof(struct mtip_cmd_hdr) * i);

		if (host_cap_64)
			port->commands[i].command_header->ctbau =
				__force_bit2int cpu_to_le32(
				(port->commands[i].command_dma >> 16) >> 16);

		port->commands[i].command_header->ctba =
			__force_bit2int cpu_to_le32(
				port->commands[i].command_dma & 0xFFFFFFFF);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
		sg_init_table(port->commands[i].sg, MTIP_MAX_SG);
#endif

		/* Mark command as currently inactive */
		atomic_set(&dd->port->commands[i].active, 0);

		dbg_printk("Command[%d] @ %p/%llu (%lu)\n",
			i, port->commands[i].command,
			port->commands[i].command_dma,
			(unsigned long) CMD_DMA_ALLOC_SZ);
	}
	return 0;
}

/*
 * Hardware initialization function. Called once for each card.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0	Successfully initialized hardware.
 *      MTIP_FTL_REBUILD_MAGIC Drive is rebuilding the FTL table.
 * 	-ENODEV Invalid/unknown hardware configuration or device removed.
 *	-ENOMEM Unable to allocate all the necessary memory.
 * 	-EFAULT Device removal during init or timeout waiting for drive ready.
 * 	-EIO	Drive did not reset properly.
 */
static int mtip_hw_init(struct driver_data *dd)
{
	int i, rv = 0;
	unsigned long timeout, timetaken;

	if (dd->port && mtip_test_bit(MTIP_DDF_REBUILD_BIT, dd->flags))
		goto post_ftlrebuild;

	dd->mmio = pcim_iomap_table(dd->pdev)[MTIP_ABAR];

	if (mtip_detect_product(dd) == MTIP_PRODUCT_UNKNOWN)
		return -ENODEV;

	hba_setup(dd);
	init_rwsem(&dd->sync_sem);

	dd->port = vmalloc_node(sizeof(struct mtip_port), dd->numa_node);
	if (!dd->port) {
		dev_err(&dd->pdev->dev,
			"Memory allocation: port structure\n");
		return -ENOMEM;
	}
	memset(dd->port, 0, sizeof(struct mtip_port));

	/* Enable unaligned IO constraints for some devices */
	if (mtip_device_unaligned_constrained(dd))
		dd->unal_qdepth = MTIP_MAX_UNALIGNED_SLOTS;
	else
		dd->unal_qdepth = 0;

	/* Counting semaphore to track command slot usage */
	sema_init(&dd->port->cmd_slot,
				MTIP_MAX_COMMAND_SLOTS - 1 - dd->unal_qdepth);
	sema_init(&dd->port->cmd_slot_unal, dd->unal_qdepth);

	/* Spinlock to prevent concurrent issue */
	for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++) {
		spin_lock_init(&dd->port->cmd_issue_lock[i]);
		dd->work[i].port = dd->port;
	}

	/* Set the port mmio base address */
	dd->port->mmio = dd->mmio + PORT_OFFSET;
	dd->port->dd   = dd;

	/* DMA allocations */
	rv = mtip_dma_alloc(dd);
	if (rv < 0)
		goto out1;

	/* Setup the pointers to the extended SAct and CI registers */
	for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++) {
		dd->port->s_active[i] =
			dd->port->mmio + i*0x80 + PORT_SCR_ACT;
		dd->port->cmd_issue[i] =
			dd->port->mmio + i*0x80 + PORT_COMMAND_ISSUE;
		dd->port->completed[i] =
			dd->port->mmio + i*0x80 + PORT_SDBV;
	}

	/* 
	 * Poll for up to 30 sec for PxSSTS.DET to be set to 0x3.
	 * Fail the binding if FW doesn't assert readiness.
	 */
	timetaken = jiffies;
	timeout = jiffies + msecs_to_jiffies(30000);
	while (((readl(dd->port->mmio + PORT_SCR_STAT) & 0x0F) != 0x03) &&
		 time_before(jiffies, timeout)) {

		if (mtip_check_surprise_removal(dd)) {
			timetaken = jiffies - timetaken;
			dev_warn(&dd->pdev->dev,
				"Surprise removal detected at %u ms\n",
				jiffies_to_msecs(timetaken));
			rv = -ENODEV;
			goto out2;
		}

		msleep(10);

		if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags)) {
			timetaken = jiffies - timetaken;
			dev_warn(&dd->pdev->dev,
				"Removal detected at %u ms\n",
				jiffies_to_msecs(timetaken));
			rv = -EFAULT;
			goto out2;
		}
	}

	/* Log how long initialization took */
	timetaken = jiffies - timetaken;
	if ((readl(dd->port->mmio + PORT_SCR_STAT) & 0x0F) != 0x03) {
		dev_err(&dd->pdev->dev,
			"Device not ready after %u ms\n",
			jiffies_to_msecs(timetaken));
		rv = -EFAULT;
		goto out2;
	} else {
		dev_info(&dd->pdev->dev,
			"Time to device ready: %u ms\n",
			jiffies_to_msecs(timetaken));
	}

	/* Conditionally reset the HBA */
	if (!(readl(dd->mmio + HOST_CAP) & HOST_CAP_NZDMA)) {
		if (mtip_hba_reset(dd) < 0) {
			dev_err(&dd->pdev->dev,
				"Drive did not reset within timeout\n");
			rv = -EIO;
			goto out2;
		}
	} else {
		/* Clear any pending interrupts on the HBA */
		writel(readl(dd->mmio + HOST_IRQ_STAT),
			dd->mmio + HOST_IRQ_STAT);
	}

	mtip_init_port(dd->port);
	mtip_start_port(dd->port);

	/* Setup the ISR and enable interrupts */
	rv = devm_request_irq(&dd->pdev->dev,
				dd->pdev->irq,
				mtip_irq_handler,
				IRQF_SHARED,
				dev_driver_string(&dd->pdev->dev),
				dd);

	if (rv) {
		dev_err(&dd->pdev->dev,
			"Unable to allocate IRQ %d\n", dd->pdev->irq);
		goto out2;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)       && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6         && \
		defined(RHEL_MINOR) && RHEL_MINOR != 0)) || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 35)
	/* IRQ affinitization */
	dev_info(&dd->pdev->dev, "Affinitizing IRQ %d to cpu %d on node %d\n",
		dd->pdev->irq, dd->isr_binding, cpu_to_node(dd->isr_binding));
	irq_set_affinity_hint(dd->pdev->irq, get_cpu_mask(dd->isr_binding));
#endif

	/* Enable interrupts on the HBA */
	writel(readl(dd->mmio + HOST_CTL) | HOST_IRQ_EN,
					dd->mmio + HOST_CTL);

	init_timer(&dd->port->cmd_timer);
	setup_timer(&dd->port->cmd_timer, mtip_timeout_function,
						(unsigned long int) dd);
	dd->port->cmd_timer.expires = jiffies +
				msecs_to_jiffies(MTIP_TIMEOUT_CHECK_PERIOD);
	add_timer_on(&dd->port->cmd_timer, dd->isr_binding);
	mod_timer_pinned(&dd->port->cmd_timer,
		jiffies + msecs_to_jiffies(MTIP_TIMEOUT_CHECK_PERIOD));

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags)) {
		rv = -EFAULT;
		goto out3;
	}
	if (mtip_get_identify(dd->port, NULL) < 0) {
		rv = -EFAULT;
		goto out3;
	}
	mtip_dump_identify(dd->port);

	if (mtip_drive_rebuild(dd)) {
		mtip_set_bit(MTIP_DDF_REBUILD_BIT, dd->flags);
		return MTIP_FTL_REBUILD_MAGIC;
	}

post_ftlrebuild:
	mtip_hw_info(dd);

	return rv;

out3:
	del_timer_sync(&dd->port->cmd_timer);

	/* Disable interrupts on the HBA */
	writel(readl(dd->mmio + HOST_CTL) & ~HOST_IRQ_EN,
			dd->mmio + HOST_CTL);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)	 && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6	 && \
		defined(RHEL_MINOR) && RHEL_MINOR != 0)) || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 35)
	/* Unset affinity hints */
	irq_set_affinity_hint(dd->pdev->irq, NULL);
#endif

	/* Release the IRQ */
	devm_free_irq(&dd->pdev->dev, dd->pdev->irq, dd);

	msleep(100);

out2:
	mtip_deinit_port(dd->port);
	mtip_dma_free(dd);

out1:
	/* Free the memory allocated for the for structure */
	if (dd->port) {
		vfree(dd->port);
		dd->port = NULL;
	}

	return rv;
}

/*
 * Called to deinitialize an interface.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0
 */
static int mtip_hw_exit(struct driver_data *dd)
{
	unsigned long flags;

	if (!mtip_test_bit(MTIP_DDF_SR_BIT, dd->flags)) {

		if (!(mtip_drive_rebuild(dd) ||
			mtip_test_bit(MTIP_DDF_SEC_LOCK_BIT, dd->flags) ||
			mtip_test_bit(MTIP_DDF_QUIESCE_BIT, dd->flags))) {

			/*
			 * Send standby immediate (E0h) to the drive so that it
			 * saves its state.
			 */
			down_write(&dd->sync_sem);
			mtip_standby_immediate(dd->port);
			up_write(&dd->sync_sem);
		}

		/* de-initialize the port */
		mtip_deinit_port(dd->port);

		/* Disable interrupts on the HBA */
		writel(readl(dd->mmio + HOST_CTL) & ~HOST_IRQ_EN,
					dd->mmio + HOST_CTL);
	}

	del_timer_sync(&dd->port->cmd_timer);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)	 && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6	 && \
		defined(RHEL_MINOR) && RHEL_MINOR != 0)) || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 35)
	/* Unset affinity hints (prevents warnings on some kernels) */
	irq_set_affinity_hint(dd->pdev->irq, NULL);
#endif

	/* Release the IRQ */
	devm_free_irq(&dd->pdev->dev, dd->pdev->irq, dd);

	msleep(100);

	/* Free dma regions */
	mtip_dma_free(dd);

	/* Free the memory allocated for the port structure */
	spin_lock_irqsave(&dev_lock, flags);
	vfree(dd->port);
	dd->port = NULL;
	spin_unlock_irqrestore(&dev_lock, flags);

	return 0;
}

/*
 * Issue a Standby Immediate command to the device.
 *
 * This function is called by the Block Layer just before the
 * system powers off during a shutdown.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0
 */
static int mtip_hw_shutdown(struct driver_data *dd)
{
	/*
	 * Send standby immediate (opcode 0xE0) to the drive so that it
	 * saves its state
	 */
	if (dd->port &&
		!mtip_test_bit(MTIP_DDF_REBUILD_BIT, dd->flags) &&
		!mtip_test_bit(MTIP_DDF_QUIESCE_BIT, dd->flags)) {
		down_write(&dd->sync_sem);
		mtip_standby_immediate(dd->port);
		up_write(&dd->sync_sem);
	}

	return 0;
}

/*
 * Suspend function
 *
 * This function is called by the Block Layer just before the
 * system hibernates.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0	Suspend was successful
 *	-EFAULT Suspend was not successful
 */
static int mtip_hw_suspend(struct driver_data *dd)
{
	WARN_ON(mtip_test_bit(MTIP_DDF_QUIESCE_BIT, dd->flags));

	down_write(&dd->sync_sem);

	/*
	 * Send standby immediate (opcode 0xE0) to the drive
	 * so that it saves its state
	 */
	if (dd->port && !mtip_test_bit(MTIP_DDF_REBUILD_BIT, dd->flags)) {
		if (mtip_standby_immediate(dd->port) != 0)
			return -EFAULT;
	}

	/* Disable interrupts on the HBA */
	writel(readl(dd->mmio + HOST_CTL) & ~HOST_IRQ_EN, dd->mmio + HOST_CTL);

	mtip_deinit_port(dd->port);

	/* Clear flags for re-discoverable conditions */
	mtip_clear_bit(MTIP_DDF_OVER_TEMP_BIT, dd->flags);
	mtip_clear_bit(MTIP_DDF_WRITE_PROTECT_BIT, dd->flags);
	mtip_clear_bit(MTIP_DDF_REBUILD_FAILED_BIT, dd->flags);
	mtip_clear_bit(MTIP_DDF_QUIESCE_BIT, dd->flags);


	return 0;
}

/*
 * Resume function
 *
 * This function is called by the Block Layer as the
 * system resumes.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0	Resume was successful
 *      -EFAULT Resume was not successful
 */
static int mtip_hw_resume(struct driver_data *dd)
{
	/* Perform any needed hardware setup steps */
	hba_setup(dd);

	/* Reset the HBA */
	if (mtip_hba_reset(dd) != 0) {
		dev_err(&dd->pdev->dev,
			"Unable to reset the HBA\n");
		return -EFAULT;
	}

	/*
	 * Enable the port, DMA engine, and FIS reception
	 */
	mtip_init_port(dd->port);
	mtip_start_port(dd->port);

	/* Enable interrupts on the HBA.*/
	writel(readl(dd->mmio + HOST_CTL) | HOST_IRQ_EN,
			dd->mmio + HOST_CTL);

	up_write(&dd->sync_sem);

	return 0;
}

/*
 * Helper function for reusing disk name
 * upon hot insertion.
 */
static int rssd_disk_name_format(char *prefix,
				 int index,
				 char *buf,
				 int buflen)
{
	const int base = 'z' - 'a' + 1;
	char *begin = buf + strlen(prefix);
	char *end = buf + buflen;
	char *p;
	int unit;

	p = end - 1;
	*p = '\0';
	unit = base;
	do {
		if (p == begin)
			return -EINVAL;
		*--p = 'a' + (index % unit);
		index = (index / unit) - 1;
	} while (index >= 0);

	memmove(begin, p, end - p);
	memcpy(buf, prefix, strlen(prefix));

	return 0;
}

/*
 * Block layer IOCTL handler.
 *
 * @dev  Pointer to the block_device structure.
 * @mode ignored
 * @cmd  IOCTL command passed from the user application.
 * @arg  Argument passed from the user application.
 *
 * return value
 *	0        IOCTL completed successfully.
 *	-ENOTTY  IOCTL not supported or invalid driver data
 *                 structure pointer.
 *	-EACCES	 Insufficient privileges for operation.
 * 	For other values, see the return codes from mtip_hw_ioctl()
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
static int mtip_block_ioctl(struct block_device *dev,
				fmode_t mode,
				unsigned cmd,
				unsigned long arg)
#else
static int mtip_block_ioctl(struct inode *inode,
				struct file *filp,
				unsigned int cmd,
				unsigned long arg)
#endif
{
	struct driver_data *dd = NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	if (dev && dev->bd_disk)
		dd = dev->bd_disk->private_data;
#else
	if (filp)
		dd = filp->private_data;
#endif

	if (!capable(CAP_SYS_ADMIN))
		return -EACCES;

	if (!dd || !dd->port)
		return -ENOTTY;

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
		return -ENOTTY;

	switch (cmd) {
	case BLKFLSBUF:
		return -ENOTTY;
	default:
		return mtip_hw_ioctl(dd, cmd, arg);
	}
}

#ifdef CONFIG_COMPAT
/*
 * Block layer compat IOCTL handler.
 *
 * @dev  Pointer to the block_device structure.
 * @mode ignored
 * @cmd  IOCTL command passed from the user application.
 * @arg  Argument passed from the user application.
 *
 * return value
 *	0        IOCTL completed successfully.
 *	-ENOTTY  IOCTL not supported or invalid driver data
 *                 structure pointer.
 *	-EACCES  Insufficient privileges for operation.
 *	For other values, see the return codes from mtip_hw_ioctl()
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
static int mtip_block_compat_ioctl(struct block_device *dev,
				fmode_t mode,
				unsigned cmd,
				unsigned long arg)
#else
static long mtip_block_compat_ioctl(struct file *filp,
				unsigned int cmd,
				unsigned long arg)
#endif
{
	struct driver_data *dd = NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	if (dev && dev->bd_disk)
		dd = dev->bd_disk->private_data;
#else
	if (filp)
		dd = filp->private_data;
#endif

	if (!capable(CAP_SYS_ADMIN))
		return -EACCES;

	if (!dd || !dd->port)
		return -ENOTTY;

	if (mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
		return -ENOTTY;

	switch (cmd) {
	case BLKFLSBUF:
		return -ENOTTY;
	case HDIO_DRIVE_TASKFILE: {
		struct mtip_compat_ide_task_request_s __user *compat_req_task;
		ide_task_request_t req_task;
		int compat_tasksize, outtotal, ret;

		compat_tasksize =
			sizeof(struct mtip_compat_ide_task_request_s);

		compat_req_task =
			(struct mtip_compat_ide_task_request_s __user *) arg;

		if (copy_from_user(&req_task, (void __user *) arg,
			compat_tasksize - (2 * sizeof(compat_long_t))))
			return -EFAULT;

		if (get_user(req_task.out_size, &compat_req_task->out_size))
			return -EFAULT;

		if (get_user(req_task.in_size, &compat_req_task->in_size))
			return -EFAULT;

		outtotal = sizeof(struct mtip_compat_ide_task_request_s);

		ret = exec_drive_taskfile(dd, (void __user *) arg,
						&req_task, outtotal);

		if (copy_to_user((void __user *) arg, &req_task,
				compat_tasksize -
				(2 * sizeof(compat_long_t))))
			return -EFAULT;

		if (put_user(req_task.out_size, &compat_req_task->out_size))
			return -EFAULT;

		if (put_user(req_task.in_size, &compat_req_task->in_size))
			return -EFAULT;

		return ret;
	}
	default:
		return mtip_hw_ioctl(dd, cmd, arg);
	}
}
#endif

/*
 * Obtain the geometry of the device.
 *
 * You may think that this function is obsolete, but some applications,
 * (fdisk for example) still used CHS values. This function describes the
 * device as having 224 heads and 56 sectors per cylinder. These values are
 * chosen so that each cylinder is aligned on a 4KB boundary. Since a
 * partition is described in terms of a start and end cylinder this means
 * that each partition is also 4KB aligned. Non-aligned partitions adversely
 * affects performance.
 *
 * @dev Pointer to the block_device strucutre.
 * @geo Pointer to a hd_geometry structure.
 *
 * return value
 *	0       Operation completed successfully.
 *	-ENOTTY An error occurred while reading the drive capacity.
 *	-ENODEV Device removed or being removed.
 */
static int mtip_block_getgeo(struct block_device *dev,
				struct hd_geometry *geo)
{
	struct driver_data *dd;
	sector_t capacity;

	if (!dev || !dev->bd_disk || !dev->bd_disk->private_data) {
		printk(KERN_INFO "%s called on orphaned device\n", __func__);
		return -ENOTTY;
	}

	dd = dev->bd_disk->private_data;

	if (mtip_test_bit(MTIP_DDF_FAIL_OPEN_BIT, dd->flags) ||
	    mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags))
		return -ENODEV;

	if (!dd->port || !(mtip_hw_get_capacity(dd, &capacity))) {
		dev_warn(&dd->pdev->dev,
			"Could not get drive capacity.\n");
		return -ENOTTY;
	}

	geo->heads = 224;
	geo->sectors = 56;
	sector_div(capacity, (geo->heads * geo->sectors));
	geo->cylinders = capacity;
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
static int mtip_block_open(struct block_device *dev, fmode_t mode)
{
	struct driver_data *dd;

	if (dev && dev->bd_disk) {
		dd = (struct driver_data *) dev->bd_disk->private_data;
		if (dd) {
			if (mtip_test_bit(MTIP_DDF_FAIL_OPEN_BIT,
							dd->flags) ||
				mtip_test_bit(MTIP_DDF_REMOVE_PENDING_BIT,
							dd->flags)) {
				return -ENODEV;
			} else {
				atomic_inc(&dd->refcount);
				return 0;
			}
		}
	}
	return -ENODEV;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
static void
#else
static int
#endif
mtip_block_release(struct gendisk *disk, fmode_t mode)
{
	struct driver_data *dd;

	if (disk) {
		dd = disk->private_data;
		if (dd)
			atomic_dec(&dd->refcount);
	}
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 10, 0)
	return 0;
#endif
}

#else

static int mtip_block_open(struct inode *inode, struct file *filp)
{
	/* Set the file pointer private data to the driver data */
	if (inode && inode->i_bdev && inode->i_bdev->bd_disk)
		filp->private_data = inode->i_bdev->bd_disk->private_data;
	return 0;
}

static int mtip_block_release(struct inode *inode, struct file *filp)
{
	return 0;
}
#endif

/*
 * Block device operation function.
 *
 * This structure contains pointers to the functions required by the block
 * layer.
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
static const struct block_device_operations mtip_block_ops = {
#else
static struct block_device_operations mtip_block_ops = {
#endif
	.open		= mtip_block_open,
	.release	= mtip_block_release,
	.ioctl		= mtip_block_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl	= mtip_block_compat_ioctl,
#endif
	.getgeo		= mtip_block_getgeo,
	.owner		= THIS_MODULE
};

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
static inline int bio_has_data(struct bio *bio)
{
	return bio && bio->bi_io_vec != NULL;
}
#endif

static int mtip_complete_req(struct request *req, int status)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25)
	int err = status ? status : 1;
#endif
	struct request_queue *queue = req->q;
	struct driver_data *dd = queue->queuedata;
	unsigned long flags;
	
	/*
	 * Have to use spin_lock_irq because if we need to
	 * restart the queue it calls our request function again
	 * which does a spin_unlock_irq before calling down
	 * to the protocol layer.
	 */
	spin_lock_irqsave(&dd->completion_lock, flags);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	__blk_end_request_all(req, status ? -EIO : 0);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	__blk_end_request_all(req, err, req->nr_sectors << 9);
#else
	if (!end_that_request_first(req, err, req->nr_sectors))
		end_that_request_last(req, err);
	else
		end_that_request_last(req, 0);
#endif

	spin_unlock_irqrestore(&dd->completion_lock, flags);

	return 0;
}



/**
 * BIO completion function.
 *
 * This function is called by the protocol layer to complete a BIO transfer.
 * A Pointer to this function is passed into the protocol layer read/write
 * functions as the completion callback.
 *
 * @bio    Pointer to the BIO that has completed.
 * @status Completion status, 0 = success, non-zero = error.
 *
 * return value
 *	None
 */
static void complete_bio(struct bio *bio, int status)
{
	mtip_bio_endio(bio, bio->bi_size, status);
}

/**
 * Request based interface to block layer.
 *
 * This function is called by the block layer whenever there
 * are pending requests on the request queue. 
 *
 * @queue Pointer to the request queue.
 *
 */
static void mtip_request(struct request_queue *queue)
{
	struct driver_data *dd = queue->queuedata;
	struct scatterlist *sg;
	struct request *req = NULL;
	int nents = 0, tag = 0, unaligned = 0;
	unsigned long start;
	int rv;

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
	while ((req = blk_fetch_request(queue))) {
#else
	while ((req = elv_next_request(queue))) {
		/* Remove the request from the queue */
		blkdev_dequeue_request(req);
#endif
		spin_unlock_irq(queue->queue_lock);

		if (unlikely(dd == NULL || dd->port == NULL)) {
			mtip_complete_req(req, -EIO);
			spin_lock_irq(queue->queue_lock);
			return;
		}

		rv = mtip_check_dd_flags(dd, rq_data_dir(req) == WRITE);
		if (rv != 0) {
			mtip_complete_req(req, rv);
			spin_lock_irq(queue->queue_lock);
			return;
		}

		start = jiffies;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
		if (req->cmd_type != REQ_TYPE_FS) {
#else
		if (!blk_fs_request(req)) {
#endif
			mtip_complete_req(req, -EIO);
			spin_lock_irq(queue->queue_lock);
			continue;
		}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
		if (!blk_rq_bytes(req)) {
#else
		if (req->data_len) {
#endif
			mtip_complete_req(req, -EIO);
			spin_lock_irq(queue->queue_lock);
			continue;
		}
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
		if (rq_data_dir(req) == WRITE && blk_rq_sectors(req) <= 64 &&
							dd->unal_qdepth) {
#else
		if (rq_data_dir(req) == WRITE && req->nr_sectors <= 64 &&
							dd->unal_qdepth) {
#endif
			/* Unaligned on 4k boundaries */
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
			if ((blk_rq_pos(req) % 8) != 0)
#else
			if ((req->sector % 8) != 0)
#endif
				unaligned = 1;
			/* Aligned but not 4k/8k */
			else {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
				if ((blk_rq_sectors(req) % 8) != 0)
#else
				if ((req->nr_sectors % 8) != 0)
#endif
					unaligned = 1;
			}
		}

		sg = mtip_hw_get_scatterlist(dd, &tag, unaligned);
		if (unlikely(!sg)) {
			mtip_complete_req(req, -EIO);
			spin_lock_irq(queue->queue_lock);
			return;
		}
		
		WARN_ON(req->nr_phys_segments > MTIP_MAX_SG);
		nents = blk_rq_map_sg(queue, req, sg);
		WARN_ON(nents == 0);
		if (nents == 0)  {
			mtip_complete_req(req, -EIO);
			spin_lock_irq(queue->queue_lock);
			continue;
		}

		mtip_hw_submit_io(dd,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 31)
			blk_rq_pos(req),
			blk_rq_sectors(req),
#else
			req->sector,
			req->nr_sectors,
#endif
			nents,
			tag,
			mtip_complete_req,
			req,
			rq_data_dir(req),
			0,
			start,
			unaligned);

		spin_lock_irq(queue->queue_lock);
	}
}

/*
 * Block layer make request function.
 *
 * This function is called by the kernel to process a BIO for
 * the P320 device.
 *
 * @queue Pointer to the request queue. Unused other than to obtain
 *              the driver data structure.
 * @bio   Pointer to the BIO.
 *
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 2, 0)
static void mtip_make_request(struct request_queue *queue, struct bio *bio)
#else
static int mtip_make_request(struct request_queue *queue, struct bio *bio)
#endif
{
	struct driver_data *dd = queue->queuedata;
	struct scatterlist *sg;
	struct bio_vec *bvec;
	int i, nents = 0, tag = 0, unaligned = 0;
	unsigned long start;
	int rv;

	if (unlikely(dd == NULL || dd->port == NULL)) {
		mtip_bio_endio(bio, bio->bi_size, -ENODEV);
		goto exit_make_request;
	}

	rv = mtip_check_dd_flags(dd, (bio_data_dir(bio) == WRITE));
	if (rv != 0) {
		diskstat_abort(dd, bio);

		/* Throttle IO failures a bit? */
		/* msleep_interruptible(1); */

		mtip_bio_endio(bio, bio->bi_size, rv);
		goto exit_make_request;
	}

	if (unlikely(trimflag)) {
		mtip_bio_endio(bio, bio->bi_size,
			mtip_trim(dd, bio->bi_sector, bio_sectors(bio)));
		goto exit_make_request;
	}

	start = jiffies;
	diskstat_start(dd, bio);

#ifdef MTIP_DEBUGLOG
	debuglog_io_queued(dd, bio_data_dir(bio), bio->bi_sector,
						bio_sectors(bio), bio->bi_rw);
#endif

	if (unlikely(!bio_has_data(bio))) {
		mtip_bio_endio(bio, 0, 0);
		goto exit_make_request;
	}

	if (bio_data_dir(bio) == WRITE && bio_sectors(bio) <= 64 &&
							dd->unal_qdepth) {
		if (bio->bi_sector % 8 != 0) /* Unaligned on 4k boundaries */
			unaligned = 1;
		else if (bio_sectors(bio) % 8 != 0) /* Aligned but not 4k/8k */
			unaligned = 1;
	}

	sg = mtip_hw_get_scatterlist(dd, &tag, unaligned);
	if (unlikely(!sg)) {
		diskstat_abort(dd, bio);
		mtip_bio_endio(bio, bio->bi_size, -EIO);
		goto exit_make_request;
	}

	blk_queue_bounce(queue, &bio);

	if (unlikely(((bio)->bi_vcnt > MTIP_MAX_SG) || (bio)->bi_vcnt <= 0)) {
		dev_warn(&dd->pdev->dev,
			"Maximum number of SGL entries exceeded: %d,%d\n",
			bio->bi_vcnt, bio->bi_idx);

		diskstat_abort(dd, bio);
		mtip_bio_endio(bio, bio->bi_size, -EINVAL);
		mtip_hw_release_scatterlist(dd, tag, unaligned);
		goto exit_make_request;
	}

	/* Create the scatter list for this bio */
	/* WARN_ON(bio->bi_idx != 0); */
	bio_for_each_segment(bvec, bio, i) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
		sg_set_page(&sg[nents],
				bvec->bv_page,
				bvec->bv_len,
				bvec->bv_offset);
#else
		sg[nents].page   = bvec->bv_page;
		sg[nents].length = bvec->bv_len;
		sg[nents].offset = bvec->bv_offset;
#endif
		nents++;
	}

	/* Issue the read/write. */
	mtip_hw_submit_io(dd,
			bio->bi_sector,
			bio_sectors(bio),
			nents,
			tag,
			complete_bio,
			bio,
			bio_data_dir(bio),
			fuaflag,
			start,
			unaligned);

exit_make_request:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 2, 0)
	return;
#else
	return 0;
#endif
}

/*
 * Block layer initialization function.
 *
 * This function is called once by the PCI layer for each P320
 * device that is connected to the system.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0 on success else an error code.
 */
static int mtip_block_initialize(struct driver_data *dd)
{
	int rv = 0;
	sector_t capacity;
	unsigned int index = 0;

	if (!dd->mtip_svc_handler) {
		dd->mtip_svc_handler =
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)
			kthread_create_on_node(mtip_service_thread, dd,
						dd->numa_node,
#else
			kthread_create(mtip_service_thread, dd,
#endif
						"mtip_svc_thd_%u", 
						dd->instance);
		if (IS_ERR(dd->mtip_svc_handler)) {
			dev_err(&dd->pdev->dev,
				"Couldn't create service thread.\n");
			dd->mtip_svc_handler = NULL;
			return -EFAULT;
		}
		wake_up_process(dd->mtip_svc_handler);

		/* Initialize the protocol layer */
		rv = mtip_hw_init(dd);
		if (rv < 0) {
			dev_err(&dd->pdev->dev,
				"Protocol layer initialization failed\n");
			mtip_set_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags);
			wake_up_interruptible(&dd->svc_wait);
			kthread_stop(dd->mtip_svc_handler);
			return rv;
		} else if (rv == MTIP_FTL_REBUILD_MAGIC) {
			dd->index = -1;
			wake_up_interruptible(&dd->svc_wait);
			return rv;
		}
	}

	dd->disk = alloc_disk_node(MTIP_MAX_MINORS, dd->numa_node);
	if (!dd->disk) {
		dev_err(&dd->pdev->dev,
			"Unable to allocate gendisk structure\n");
		rv = -EINVAL;
		goto alloc_disk_error;
	}

	/* Generate the disk name (implemented same as in sd.c) */
	do {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
		if (!ida_pre_get(&rssd_index_ida, GFP_KERNEL))
#else
		if (!idr_pre_get(&rssd_index_ida, GFP_KERNEL))
#endif
			goto ida_get_error;
		spin_lock(&rssd_index_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
		rv = ida_get_new(&rssd_index_ida, &index);
#else
		rv = idr_get_new(&rssd_index_ida, dd, &index);
#endif
		spin_unlock(&rssd_index_lock);
	} while (rv == -EAGAIN);

	if (rv)
		goto ida_get_error;

	rv = rssd_disk_name_format("rssd",
				index,
				dd->disk->disk_name,
				DISK_NAME_LEN);
	if (rv)
		goto disk_index_error;

	memcpy(dd->disk_name, dd->disk->disk_name, DISK_NAME_LEN);
	dd->disk->driverfs_dev	= &dd->pdev->dev;
	dd->disk->major		= dd->major;
	dd->disk->first_minor	= dd->instance * MTIP_MAX_MINORS;
	dd->disk->minors        = MTIP_MAX_MINORS;
	dd->disk->fops		= &mtip_block_ops;
	dd->disk->private_data	= dd;
	dd->index		= index;

	if (queue_mode == 1) {
		dev_info(&dd->pdev->dev,
			"Request queue (IO Elevator) mode enabled\n");
		/* Initialize the spinlock used to access the queue */
		spin_lock_init(&dd->completion_lock);
		dd->queue = blk_init_queue(mtip_request, &dd->completion_lock);
		if (!dd->queue) {
			dev_err(&dd->pdev->dev,
				"Unable to allocate request queue\n");
			rv = -ENOMEM;
			goto disk_index_error;
		}
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36) || \
	(defined(RHEL_MAJOR) && RHEL_MAJOR >=6)) && \
	!(defined(RHEL_MINOR) && RHEL_MINOR == 0)
		elevator_change(dd->queue, "noop");
#else
		elevator_init(dd->queue, "noop");
#endif
		dd->queue->nr_requests = 255;
	} else {
		/* Allocate the request queue */
		dd->queue = blk_alloc_queue_node(GFP_KERNEL, dd->numa_node);
		if (!dd->queue) {
			dev_err(&dd->pdev->dev,
				"Unable to allocate request queue\n");
			rv = -ENOMEM;
			goto disk_index_error;
		}

		/* Attach our request function to the request queue */
		blk_queue_make_request(dd->queue, mtip_make_request);
	}

	dd->disk->queue      = dd->queue;
	dd->queue->queuedata = dd;

	blk_queue_bounce_limit(dd->queue, BLK_BOUNCE_ANY);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36) || \
	(defined(RHEL_MAJOR) && RHEL_MAJOR >= 6 )
	spin_lock_irq(dd->queue->queue_lock);
	queue_flag_set(QUEUE_FLAG_NOMERGES, dd->queue);
	queue_flag_set(QUEUE_FLAG_NONROT, dd->queue);
#if !(defined(RHEL_MAJOR) && defined(RHEL_MINOR) && \
	RHEL_MAJOR >=6 && RHEL_MINOR == 0)
	queue_flag_clear(QUEUE_FLAG_ADD_RANDOM, dd->queue);
#endif
	queue_flag_clear(QUEUE_FLAG_SAME_COMP, dd->queue);
	spin_unlock_irq(dd->queue->queue_lock);
#endif

	/* Set device limits */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
	queue_flag_set_unlocked(QUEUE_FLAG_NONROT, dd->queue);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34) || \
	(defined(RHEL_MAJOR) && RHEL_MAJOR >= 6)   || \
	(defined(CONFIG_SUSE_KERNEL) && defined(SLES11SP2))
	blk_queue_max_segments(dd->queue, MTIP_MAX_SG);
#else
	blk_queue_max_phys_segments(dd->queue, MTIP_MAX_SG);
	blk_queue_max_hw_segments(dd->queue, MTIP_MAX_SG);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	blk_queue_physical_block_size(dd->queue, 4096);
	blk_queue_io_min(dd->queue, 4096);
	/* Queued FPDMA limits: 0xffff sectors per transfer */
	blk_queue_max_hw_sectors(dd->queue, 0xffff);
	/* Match max_sectors to max_hw_sectors */
	dd->queue->limits.max_sectors = 0xffff;
#else
	blk_queue_hardsect_size(dd->queue, 512);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6   && \
	defined(RHEL_MINOR) && RHEL_MINOR != 0))   || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37)
	/*
	 * write back cache is not supported in the device. FUA depends on
	 * write back cache support, hence setting flush support to zero.
	 */
	blk_queue_flush(dd->queue, 0);
#endif

#if 0 /* In-band (aka filesystem) trim support currently disabled */
 #if ((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6   && \
	defined(RHEL_MINOR) && RHEL_MINOR != 0)) || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(3, 0, 13) /* SLES 11 SP2 */
	if (dd->trim_supp) {
		/* indicate TRIM/discard support */
		set_bit(QUEUE_FLAG_DISCARD, &dd->queue->queue_flags);
		dd->queue->limits.discard_granularity = 4096;
		blk_queue_max_discard_sectors(dd->queue,
						0xfff8 * MAX_VU_TRIM_ENTRIES);
		dd->queue->limits.discard_zeroes_data = 0;
	}
 #endif
#endif

	blk_queue_max_segment_size(dd->queue, 0x400000);

	/* Set the capacity of the device in 512 byte sectors */
	if (!(mtip_hw_get_capacity(dd, &capacity))) {
		dev_warn(&dd->pdev->dev,
			"Could not read drive capacity\n");
		rv = -EIO;
		goto read_capacity_error;
	}
	set_capacity(dd->disk, capacity);

	/* Enable the block device and add it to /dev */
	add_disk(dd->disk);

	/* Store blockdev pointer */
	dd->bdev = bdget_disk(dd->disk, 0);
	if (!dd->bdev) {
		dev_warn(&dd->pdev->dev,
			"Failed to get block device handle\n");
		goto bdget_error;
	}
	dd->bdev->bd_private = (unsigned long) dd;

	/*
	 * Now that the disk is active, initialize any sysfs attributes
	 * managed by the protocol layer.
	 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	{
		struct kobject *kobj =
			kobject_get(&disk_to_dev(dd->disk)->kobj);
		mtip_hw_sysfs_init(dd, kobj);
		kobject_put(kobj);
	}
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	mtip_hw_sysfs_init(dd, &dd->disk->dev.kobj);
#else
	mtip_hw_sysfs_init(dd, &dd->disk->kobj);
#endif
	mtip_hw_debugfs_init(dd);

	return rv;

bdget_error:
	del_gendisk(dd->disk);

read_capacity_error:
	if (dd->queue) {
		dd->queue->queuedata = NULL;
		blk_cleanup_queue(dd->queue);
		dd->queue = NULL;
	}

disk_index_error:
	spin_lock(&rssd_index_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	ida_remove(&rssd_index_ida, index);
#else
	idr_remove(&rssd_index_ida, index);
#endif
	spin_unlock(&rssd_index_lock);

ida_get_error:
	if (dd->disk)
		put_disk(dd->disk);
	dd->disk = NULL;

alloc_disk_error:
	mtip_hw_exit(dd); /* De-initialize the protocol layer */
	mtip_set_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags);
	wake_up_interruptible(&dd->svc_wait);
	kthread_stop(dd->mtip_svc_handler);

	return rv;
}

/*
 * Functions to freeze/thaw any filesystem running on the device.
 */
static int mtip_block_lock_fs(struct driver_data *dd)
{
	WARN_ON(dd->frozen_sb);

	dev_info(&dd->pdev->dev, "Locking bdev ...\n");

	if (mtip_check_surprise_removal(dd))
		return 0;

	dd->frozen_sb = freeze_bdev(dd->bdev);
	if (IS_ERR(dd->frozen_sb)) {
		dev_warn(&dd->pdev->dev, "Error locking bdev.\n");
		return PTR_ERR(dd->frozen_sb);
	}

	mtip_set_bit(MTIP_DDF_FROZEN_BIT, dd->flags);

	dev_info(&dd->pdev->dev, "Successfully locked bdev.\n");

	return 0;
}

static void mtip_block_unlock_fs(struct driver_data *dd)
{
	if (!mtip_test_bit(MTIP_DDF_FROZEN_BIT, dd->flags)) {
		dev_warn(&dd->pdev->dev, "bdev not locked.\n");
		return;
	}

	dev_info(&dd->pdev->dev, "Thawing bdev ...\n");
	thaw_bdev(dd->bdev, dd->frozen_sb);
	dd->frozen_sb = NULL;
	mtip_clear_bit(MTIP_DDF_FROZEN_BIT, dd->flags);

	dev_info(&dd->pdev->dev, "Thawed bdev.\n");
}

/*
 * Block layer synchronization/cleanup routine
 */
static void mtip_block_sync_lock(struct driver_data *dd)
{
	/* Sync buffer cache */
	if (dd->bdev) {
		if (dd->disk && dd->disk->disk_name)
			dev_info(&dd->pdev->dev,
				"Syncing and cleaning up %s ...\n",
				dd->disk->disk_name);
		else
			dev_info(&dd->pdev->dev,
				"Syncing and cleaning up ...\n");

		fsync_bdev(dd->bdev);
		mtip_command_cleanup(dd, 10);

		if (dd->bdev->bd_holders) {
			struct super_block *sb = NULL;
#if ((defined(RHEL_MAJOR) && RHEL_MAJOR == 5 && \
	defined(RHEL_MINOR) && RHEL_MINOR == 3))
			mutex_lock(&dd->bdev->bd_mutex);
#else
			mutex_lock(&dd->bdev->bd_fsfreeze_mutex);
#endif
			sb = get_super(dd->bdev);
			if (sb)
				drop_super(sb);
#if ((defined(RHEL_MAJOR) && RHEL_MAJOR == 5 && \
	defined(RHEL_MINOR) && RHEL_MINOR == 3))
			mutex_unlock(&dd->bdev->bd_mutex);
#else
			mutex_unlock(&dd->bdev->bd_fsfreeze_mutex);
#endif

			if (sb) {
				if (dd->disk && dd->disk->disk_name)
					dev_info(&dd->pdev->dev,
						"Locking filesystem on %s\n",
						dd->disk->disk_name);
				mtip_block_lock_fs(dd);
			}
		}
	}
}

/*
 * Block layer deinitialization function.
 *
 * Called by the PCI layer as each P320 device is removed.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0
 */
static int mtip_block_remove(struct driver_data *dd)
{
	if (dd->mtip_svc_handler) {
		mtip_set_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags);
		wake_up_interruptible(&dd->svc_wait);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
		kthread_stop(dd->mtip_svc_handler);
#else
		if (mtip_test_bit(MTIP_DDF_REBUILD_BIT, dd->flags))
			kthread_stop(dd->mtip_svc_handler);
#endif
	}

	/* Clean up the sysfs attributes, if created */
	if (dd->disk) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
		struct kobject *kobj = 
			kobject_get(&disk_to_dev(dd->disk)->kobj);
		mtip_hw_sysfs_exit(dd, kobj);
		kobject_put(kobj);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
		mtip_hw_sysfs_exit(dd, &dd->disk->dev.kobj);
#else
		mtip_hw_sysfs_exit(dd, &dd->disk->kobj);
#endif
	}
	mtip_hw_debugfs_exit(dd);

	if (!mtip_test_bit(MTIP_DDF_ORPHAN_BIT, dd->flags)) {
		if (dd->bdev) {
			bdput(dd->bdev);
			dd->bdev = NULL;
		}

		/* Delete our gendisk. also removes the device from /dev */
		if (dd->disk) {
			dd->disk->fops = NULL;
			dd->disk->private_data = NULL;
			del_gendisk(dd->disk);
			put_disk(dd->disk);
			dd->disk = NULL;

			if (dd->index != -1) {
				spin_lock(&rssd_index_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
				ida_remove(&rssd_index_ida, dd->index);
#else
				idr_remove(&rssd_index_ida, dd->index);
#endif
				dd->index = -1;
				spin_unlock(&rssd_index_lock);
			}
		}

		if (dd->queue) {
			dd->queue->queuedata = NULL;
			blk_cleanup_queue(dd->queue);
			dd->queue = NULL;
		}
	}

	/* De-initialize the protocol layer */
	mtip_hw_exit(dd);

	return 0;
}

/*
 * Function called by the PCI layer when just before the
 * machine shuts down.
 *
 * If a protocol layer shutdown function is present it will be called
 * by this function.
 *
 * @dd Pointer to the driver data structure.
 *
 * return value
 *	0
 */
static int mtip_block_shutdown(struct driver_data *dd)
{
	if (dd->disk && dd->disk->disk_name) {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Shutting down %s ...\n", dd->disk->disk_name);
	} else {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Shutting down dd %p %s...\n", dd,
			mtip_drive_rebuild(dd) ? "(in rebuild) " : "");
	}

	if (dd->mtip_svc_handler && mtip_drive_rebuild(dd)) {
		mtip_set_bit(MTIP_DDF_SVC_THD_STOP_BIT, dd->flags);
		wake_up_interruptible(&dd->svc_wait);
		kthread_stop(dd->mtip_svc_handler);
		mtip_set_bit(MTIP_DDF_REBUILD_BIT, dd->flags);
	}

	if (!atomic_read(&dd->refcount)) {

		if (dd->bdev) {
			bdput(dd->bdev);
			dd->bdev = NULL;
		}

		/* Delete gendisk object. This also removes the device from /dev */
		if (dd->disk) {
			dd->disk->fops = NULL;
			dd->disk->private_data = NULL;
			del_gendisk(dd->disk);
			put_disk(dd->disk);
			dd->disk = NULL;
		}

		if (dd->index != -1) {
			spin_lock(&rssd_index_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
			ida_remove(&rssd_index_ida, dd->index);
#else
			idr_remove(&rssd_index_ida, dd->index);
#endif
			spin_unlock(&rssd_index_lock);
		}

		if (dd->queue) {
			blk_cleanup_queue(dd->queue);
			dd->queue = NULL;
		}
	} else {
		mtip_set_bit(MTIP_DDF_FAIL_OPEN_BIT, dd->flags);
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_WARNING, dd,
			"Non-zero refcount %d\n", atomic_read(&dd->refcount));
	}

	mtip_hw_shutdown(dd);
	return 0;
}

static int mtip_block_suspend(struct driver_data *dd)
{
	if (dd->disk && dd->disk->disk_name) {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Suspending %s ...\n", dd->disk->disk_name);
	} else {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Suspending dd %p ...\n", dd);
	}

	if (dd->bdev)
		mtip_block_sync_lock(dd);

	mtip_hw_suspend(dd);
	return 0;
}

static int mtip_block_resume(struct driver_data *dd)
{
	if (dd->disk && dd->disk->disk_name) {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Resuming %s ...\n", dd->disk->disk_name);
	} else {
		mtip_printk((MTIP_BLOCK | MTIP_INIT), MTIP_INFO, dd,
			"Resuming dd %p ...\n", dd);
	}

	mtip_hw_resume(dd);
	mtip_block_unlock_fs(dd);

	return 0;
}

static void
mtip_disable_link_opts(struct driver_data *dd, struct pci_dev *pdev)
{
	int pos;
	unsigned short pcie_dev_ctrl;

	pos = pci_find_capability(pdev, PCI_CAP_ID_EXP);
	if (pos) {
		pci_read_config_word(pdev,
			pos + PCI_EXP_DEVCTL,
			&pcie_dev_ctrl);
		if (pcie_dev_ctrl & (1 << 11) ||
		    pcie_dev_ctrl & (1 << 4)) {
			mtip_printk((MTIP_PCI | MTIP_INIT), MTIP_WARNING, dd,
				"Disabling ERO/No-Snoop on bridge device "
				"%04x:%04x\n", pdev->vendor, pdev->device);
			pcie_dev_ctrl &= ~((1 << 11) | (1 << 4));
			pci_write_config_word(pdev,
				pos + PCI_EXP_DEVCTL,
				pcie_dev_ctrl);
		}
	}
}

static void mtip_configure_workers(struct driver_data *dd)
{
	int i, irq_bindings = 0;
	
	MTIP_INIT_WORK(0);
	MTIP_INIT_WORK(1);
	MTIP_INIT_WORK(2);
	MTIP_INIT_WORK(3);
	MTIP_INIT_WORK(4);
	MTIP_INIT_WORK(5);
	MTIP_INIT_WORK(6);
	MTIP_INIT_WORK(7);

	dd->isr_binding = get_least_used_cpu_on_node(dd->numa_node);
	dbg_printk("Initial IRQ binding node:cpu %d:%d\n",
			cpu_to_node(dd->isr_binding), dd->isr_binding);

	/* first worker context always runs in ISR */
	dd->work[0].cpu_binding = dd->isr_binding;
	irq_bindings++;

	if (comp_cores < 1 || comp_cores > 8)
		comp_cores = MTIP_COMP_CORES_DEFAULT;

	for (i = 1; i < MTIP_MAX_SLOT_GROUPS; i++) {
		if (i < comp_cores)
			dd->work[i].cpu_binding =
				get_least_used_cpu_on_node(dd->numa_node);
		else {
			if (comp_cores >= 3 && irq_bindings >= 2) {
				dd->work[i].cpu_binding =
					dd->work[1 + (i % 
						(comp_cores - 1))].cpu_binding;
			} else {
				dd->work[i].cpu_binding =
					dd->work[i % comp_cores].cpu_binding;
			}
		}
		if (dd->work[i].cpu_binding == dd->isr_binding)
			irq_bindings++;
	}

	mtip_log_bindings(dd);
}

static void mtip_unconfigure_workers(struct driver_data *dd)
{
	int i;

	drop_cpu(dd->work[0].cpu_binding);
	
	for (i = 1; i < MTIP_MAX_SLOT_GROUPS; i++) {
		if (i < comp_cores)
			drop_cpu(dd->work[i].cpu_binding);
	} 
}

static void mtip_free_orphans(void)
{
	struct driver_data *orphan, *tmp;
	struct list_head to_free;

	INIT_LIST_HEAD(&to_free);

	spin_lock(&orphan_lock);
	list_for_each_entry_safe(orphan, tmp, &orphan_list, orphan_list) {
		if (orphan && atomic_read(&orphan->refcount) == 0)
			list_move_tail(&orphan->orphan_list, &to_free);
		else
			pr_info(MTIP_DRV_NAME "Skipping orphan %s "
				"(refcount %d)\n", orphan->disk_name,
				atomic_read(&orphan->refcount));
	}
	spin_unlock(&orphan_lock);

	orphan = tmp = NULL;
	if (!list_empty(&to_free)) {
		list_for_each_entry_safe(orphan, tmp, &to_free, orphan_list) {
			pr_info(MTIP_DRV_NAME " Deallocating orphan %s ...\n",
							orphan->disk_name);

			if (orphan->index != -1) {
				spin_lock(&rssd_index_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
				ida_remove(&rssd_index_ida, orphan->index);
#else
				idr_remove(&rssd_index_ida, orphan->index);
#endif
				spin_unlock(&rssd_index_lock);
			}

			if (orphan->bdev) {
				bdput(orphan->bdev);
				orphan->bdev = NULL;
			}

			if (orphan->disk) {
				orphan->disk->fops = NULL;
				orphan->disk->private_data = NULL;
				del_gendisk(orphan->disk);
				put_disk(orphan->disk);
			}

			if (orphan->queue) {
#if 0
				if (orphan->queue->queuedata)
					free_percpu(orphan->queue->queuedata);
#endif

				orphan->queue->queuedata = NULL;
				blk_cleanup_queue(orphan->queue);
			}

			free_percpu(orphan->flags);
			memset(orphan, 0, sizeof(struct driver_data));
			vfree(orphan);
		}
	}
}

/*
 * Initialize a single device.
 *
 * This function allocates the private data structure, enables the
 * PCI device and then calls the block layer initialization function.
 *
 * @pdev    Pointer to pci_dev structure
 * @ent     Pointer to pci_device_id structure
 * @my_node Numa node chosen for device bindings
 * @id      Device instance number
 *
 * return value
 *	0 on success else an error code.
 */
int mtip_init_device(struct pci_dev *pdev,
			const struct pci_device_id *ent,
			int my_node,
			int id)
{
	int i = 0, rv = 0;
	struct driver_data *dd = NULL;
	char cpu_list[256];
	unsigned long flags;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	dev_info(&pdev->dev, "NUMA node %d (closest: %d,%d, probe on %d:%d)\n",
		my_node, pcibus_to_node(pdev->bus), dev_to_node(&pdev->dev),
		cpu_to_node(smp_processor_id()), smp_processor_id());
	set_dev_node(&pdev->dev, my_node);
#else
	dev_info(&pdev->dev, "Using NUMA node %d\n", my_node);
#endif

	/* Allocate memory for this devices private data */
	dd = vmalloc_node(sizeof(struct driver_data), my_node);
	if (!dd) {
		dev_err(&pdev->dev,
			"Unable to allocate memory for driver data\n");
		return -ENOMEM;
	}
	memset(dd, 0, sizeof(struct driver_data));

	/* Allocate per-cpu region for flags */
	dd->flags = alloc_percpu(unsigned long);
	if (!dd->flags) {
		dev_err(&pdev->dev,
			"Unable to allocate per-cpu memory\n");
		vfree(dd);
		return -ENOMEM;
	}
	for_each_possible_cpu(i) {
		*per_cpu_ptr(dd->flags, i) = 0;
		per_cpu(pcpu_queue_mode, i) = queue_mode;
	}

	/* Attach the private data to this PCI device */
	pci_set_drvdata(pdev, dd);

	/* Copy needed info into the private data structure */
	dd->major       = mtip_major;
	dd->instance    = id;
	dd->pdev        = pdev;
	dd->numa_node	= my_node;
	dd->pent	= ent;

	atomic_set(&dd->irq_workers_active, 0);
	atomic_set(&dd->timeout_cnt, 0);
	init_waitqueue_head(&dd->svc_wait);

#if (LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 32) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR == 6)   && \
	 (defined(RHEL_MINOR) && RHEL_MINOR != 0))  || \
	LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37))

	/* Workaround for ASPM bug in RHEL 6.2 */
	pci_disable_link_state(pdev, PCIE_LINK_STATE_L0S |
				PCIE_LINK_STATE_L1 | PCIE_LINK_STATE_CLKPM);
#endif

	rv = pcim_enable_device(pdev);
	if (rv < 0) {
		dev_err(&pdev->dev, "Unable to enable device\n");
		goto cleanup_driver_data;
	}

	/* Initialize extra stuff */
	INIT_LIST_HEAD(&dd->online_list);
	INIT_LIST_HEAD(&dd->orphan_list);
	INIT_LIST_HEAD(&dd->remove_list);

	/*
	 * Read the subsystem Device id from the pci configuration space
	 * to check the Customer 08 specification card
	 */
	{
		int pos;
		unsigned short pcie_sub_deviceid;
		unsigned short pcie_up_ctrl, pcie_dev_ctrl;
		unsigned short pcie_up_cap_reg, pcie_dev_cap_reg;
		unsigned short pcie_up_cap, pcie_dev_cap;

		pci_read_config_word(pdev,
				PCI_SUBSYSTEM_DEVICEID,
				&pcie_sub_deviceid);
		if (!((pcie_sub_deviceid >> 8) & 0x0f) && pdev->bus->self) {
			pcie_up_ctrl = pcie_up_cap = 0;
			pcie_up_cap_reg =
				pci_find_capability(pdev->bus->self,
					PCI_CAP_ID_EXP);
			pci_read_config_word(pdev->bus->self,
				pcie_up_cap_reg + PCI_EXP_DEVCAP,
				&pcie_up_cap);
			pci_read_config_word(pdev->bus->self,
				pcie_up_cap_reg + PCI_EXP_DEVCTL,
				&pcie_up_ctrl);
			pos = pcie_dev_cap_reg =
				pci_find_capability(pdev,
					PCI_CAP_ID_EXP);
			pci_read_config_word(pdev,
				pcie_dev_cap_reg + PCI_EXP_DEVCAP,
				&pcie_dev_cap);
			pci_read_config_word(pdev,
				pcie_dev_cap_reg + PCI_EXP_DEVCTL,
				&pcie_dev_ctrl);
			if ((pcie_up_ctrl & PCI_EXP_DEVCTL_PAYLOAD) !=
				(pcie_dev_ctrl & PCI_EXP_DEVCTL_PAYLOAD)) {
				pcie_dev_ctrl &= ~PCI_EXP_DEVCTL_PAYLOAD;
				pcie_dev_ctrl |=
					pcie_up_ctrl & PCI_EXP_DEVCTL_PAYLOAD;
				pci_write_config_word(pdev,
					PCIE_CONFIG_EXT_DEVICE_CONTROL_OFFSET,
					pcie_dev_ctrl);
			}
		}
	}

	rv = pcim_iomap_regions(pdev,
		(1 << MTIP_ABAR) | (1 << MTIP_IOBAR), MTIP_DRV_NAME);
	if (rv >= 0) {
		dd->ioio = pcim_iomap_table(pdev)[MTIP_IOBAR];
	} else {
		dev_err(&pdev->dev, "Unable to map IOBAR: register sysfs nodes"
			" will be unavailable. Try booting with 'pci=nocrs'\n");

		/* Map BAR5 to memory */
		rv = pcim_iomap_regions(pdev, 1 << MTIP_ABAR, MTIP_DRV_NAME);
		if (rv < 0) {
			dev_err(&pdev->dev, "Unable to map regions\n");
			goto cleanup_driver_data;
		}
	}

	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
		rv = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));

		if (rv) {
			rv = pci_set_consistent_dma_mask(pdev,
						DMA_BIT_MASK(32));
			if (rv) {
				dev_warn(&pdev->dev,
					"64-bit DMA enable failed\n");
				goto iomap_cleanup;
			}
		}
	}

	pci_set_master(pdev);

	/* Create workq for IO completions */
	memset(dd->workq_name, 0, 32);
	snprintf(dd->workq_name, 31, "mtipq%d", dd->instance);
	dd->isr_workq = create_workqueue(dd->workq_name);
	if (!dd->isr_workq) {
		dev_err(&pdev->dev, "Can't create workq %d\n", dd->instance);
		rv = -ENOMEM;
		goto iomap_cleanup;
	}

#ifndef LEGACY_PPC
	rv = pci_enable_msi(pdev);
	if (rv) {
		dev_warn(&pdev->dev,
			"Unable to enable MSI interrupt.\n");
		goto workq_destroy;
	}
#endif

	/* NUMA setup */
	get_cpu_list(dd->numa_node, cpu_list, 256);
	dev_info(&pdev->dev, "Node %d on package %d has %d cpu(s): %s\n",
		dd->numa_node,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
		topology_physical_package_id(cpumask_first(cpumask_of_node(
							dd->numa_node))),
#else
		-1,
#endif
		nr_cpus_node(dd->numa_node),
		cpu_list);

	mtip_configure_workers(dd);

	/* Initialize pci layer sysfs entries */
	init_pci_sysfs(dd);

	/* Fixup ERO & NOSNOOP */
	if (pdev->bus && pdev->bus->self) {
		if (pdev->bus->self->vendor == 0x1002 &&
		    ((pdev->bus->self->device & 0xff00) == 0x5a00)) {
			mtip_disable_link_opts(dd, pdev->bus->self);
		} else {
			/* Check further up the topology */
			struct pci_dev *parent_dev = pdev->bus->self;
			if (parent_dev->bus &&
				parent_dev->bus->parent &&
				parent_dev->bus->parent->self &&
				parent_dev->bus->parent->self->vendor == 0x1002
				&&
				(parent_dev->bus->parent->self->device &
					0xff00) == 0x5a00) {
				mtip_disable_link_opts(dd,
					parent_dev->bus->parent->self);
			}
		}
	}

	/* Free any orphans */
	mtip_free_orphans();

	/* Initialize the block layer */
	rv = mtip_block_initialize(dd);
	if (rv < 0) {
		dev_err(&pdev->dev, "Unable to initialize block layer\n");
		mtip_unconfigure_workers(dd);
		goto disable_msi;
	}
	/* FTL Rebuild is OK */

	/* Add to online list even if in ftl rebuild */
	spin_lock_irqsave(&dev_lock, flags);
	list_add(&dd->online_list, &online_list);
	spin_unlock_irqrestore(&dev_lock, flags);

	return 0;

disable_msi:
#ifndef LEGACY_PPC
	pci_disable_msi(pdev);
#endif

workq_destroy:
	destroy_workqueue(dd->isr_workq);
	memset(dd->workq_name, 0, 32);
	dd->isr_workq = NULL;

iomap_cleanup:
	cleanup_pci_sysfs(dd);
	if (dd->ioio)
		pcim_iounmap_regions(pdev,
					(1 << MTIP_ABAR) | (1 << MTIP_IOBAR));
	else
		pcim_iounmap_regions(pdev, 1 << MTIP_ABAR);

cleanup_driver_data:
	free_percpu(dd->flags);
	vfree(dd);
	pci_set_drvdata(pdev, NULL);
	return rv;
}

/*
 * Called for each supported PCI device detected.
 *
 * @pdev Pointer to pci_dev structure
 * @end  Pointer to pci_device_id structure
 *
 * return value
 *      0 on success else an error code.
 */
static int mtip_pci_probe(struct pci_dev *pdev,
				const struct pci_device_id *ent)
{
	int my_node = 0, num_nodes = mtip_count_nodes();

	switch (numa_mode) {
	case 0: /* Round robin */
		my_node = get_next_rr_node(num_nodes);
		break;
	case 1:
		/* Proximity based */
		my_node = pcibus_to_node(pdev->bus);
		if (my_node == -1) {
			dev_warn(&pdev->dev, "Kernel is not reporting "
				"proximity, defaulting to Round Robin\n");
			my_node = get_next_rr_node(num_nodes);
			numa_mode = 0;
		}
		break;
	case 2:
		my_node = cpu_to_node(smp_processor_id());
		WARN_ON(my_node == -1);
		break;
	case 3:
#if ((defined(RHEL_MAJOR) && RHEL_MAJOR == 5))
		my_node = cpu_to_node(smp_processor_id());
#else
		my_node = dev_to_node(&pdev->dev);
		if (my_node == -1) {
			dev_warn(&pdev->dev, "pci_dev structure node "
				"undefined, defaulting to Round Robin\n");
			my_node = get_next_rr_node(num_nodes);
			numa_mode = 0;
		}
#endif
		WARN_ON(my_node == -1);
		break;
	default:
		dev_warn(&pdev->dev, "Unrecognized numa_node value %d, "
			"defaulting to Round Robin\n", numa_mode);
		my_node = get_next_rr_node(num_nodes);
		numa_mode = 0;
		break;
	}

	WARN_ON(nr_cpus_node(my_node) == 0);
	dev_info(&pdev->dev, "%d NUMA node(s)\n", num_nodes);

	return mtip_init_device(pdev, ent, my_node, instance++);
}

/*
 * Called for each probed device when the device is removed or the
 * driver is unloaded.
 *
 * @pdev Pointer to pci_dev structure
 *
 * return value
 *	None
 */
void mtip_pci_remove(struct pci_dev *pdev)
{
	struct driver_data *dd = pci_get_drvdata(pdev);
	unsigned long flags, to;
	int wa, sr = 0;

	if (!dd)
		return;

	pci_dev_get(pdev);

	flags = 0;

	mtip_set_bit(MTIP_DDF_FAIL_OPEN_BIT, dd->flags);

	spin_lock_irqsave(&dev_lock, flags);
	list_del_init(&dd->online_list);
	list_add(&dd->remove_list, &removing_list);
	spin_unlock_irqrestore(&dev_lock, flags);

	sr = mtip_check_surprise_removal(dd);
	if (sr) {
		mtip_set_bit(MTIP_DDF_SR_BIT, dd->flags);
		wake_up_interruptible(&dd->svc_wait);

		dev_warn(&dd->pdev->dev,
			"Surprise removal: cleaning residual IOs\n");

		synchronize_irq(dd->pdev->irq);

		/* Spin until workers are done */
		to = jiffies + msecs_to_jiffies(10000);
		do {
			msleep(10);
		} while ((wa = atomic_read(&dd->irq_workers_active)) != 0 &&
			time_before(jiffies, to));

		WARN_ON(wa != 0);
		if (wa != 0)
			dev_warn(&dd->pdev->dev,
				"%d completion workers still active!\n", wa);

		/* Cleanup the outstanding commands */
		mtip_command_cleanup(dd, 100);
	} else {
		dev_warn(&dd->pdev->dev, "Normal removal.\n");
		fsync_bdev(dd->bdev);
	}

	if (atomic_read(&dd->refcount)) {
		dev_warn(&dd->pdev->dev, "Orphaning device %s: refcount %d\n",
				dd->disk_name, atomic_read(&dd->refcount));
		mtip_set_bit(MTIP_DDF_ORPHAN_BIT, dd->flags);
	}
		
	if (dd->queue) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
		spin_lock_irqsave(dd->queue->queue_lock, flags);
		blk_stop_queue(dd->queue);
		spin_unlock_irqrestore(dd->queue->queue_lock, flags);
#endif
	}

	if (!sr)
		mtip_quiesce_io(dd->port, MTIP_QUIESCE_TIMEOUT_MS, GFP_KERNEL);


	mtip_set_bit(MTIP_DDF_REMOVE_PENDING_BIT, dd->flags);

	/* Clean up the block layer */
	mtip_block_remove(dd);

	cleanup_pci_sysfs(dd);

#ifndef LEGACY_PPC
	pci_disable_msi(pdev);
#endif

	if (dd->isr_workq) {
		flush_workqueue(dd->isr_workq);
		destroy_workqueue(dd->isr_workq);
		mtip_unconfigure_workers(dd);
	}

	if (dd->ioio)
		pcim_iounmap_regions(pdev,
					(1 << MTIP_ABAR) | (1 << MTIP_IOBAR));
	else
		pcim_iounmap_regions(pdev, 1 << MTIP_ABAR);

	pci_set_drvdata(pdev, NULL);

	if (mtip_test_bit(MTIP_DDF_ORPHAN_BIT, dd->flags)) {
		unsigned long flags;
		spin_lock_irqsave(&orphan_lock, flags);
		list_add(&dd->orphan_list, &orphan_list);
		spin_unlock_irqrestore(&orphan_lock, flags);

		spin_lock_irqsave(&dev_lock, flags);
		list_del_init(&dd->remove_list);
		spin_unlock_irqrestore(&dev_lock, flags);

		/* 
		 * Must be after removing from remove_list, otherwise read of
		 * device_status node could get NULL deref
		 */
		dd->pdev = NULL;
	} else {
		unsigned long flags;
		spin_lock_irqsave(&dev_lock, flags);
		list_del_init(&dd->remove_list);
		spin_unlock_irqrestore(&dev_lock, flags);
		free_percpu(dd->flags);
		vfree(dd);
	}

	pci_dev_put(pdev);
}

/*
 * Called for each probed device when the device is suspended.
 *
 * @pdev Pointer to pci_dev structure
 * @mesg Not used
 *
 * return value
 *	0  Success
 *	<0 Error
 */
static int mtip_pci_suspend(struct pci_dev *pdev, pm_message_t mesg)
{
	int rv = 0;
	struct driver_data *dd = pci_get_drvdata(pdev);

	if (!dd) {
		dev_err(&pdev->dev,
			"Driver private data is NULL\n");
		return -EFAULT;
	}

	mtip_set_bit(MTIP_DDF_RESUME_BIT, dd->flags);

	/* Disable ports & interrupts then send standby immediate */
	rv = mtip_block_suspend(dd);
	if (rv < 0) {
		dev_err(&pdev->dev,
			"Failed to suspend drive\n");
		return rv;
	}

	/*
	 * Save the pci config space to pdev structure &
	 * disable the device
	 */
	pci_save_state(pdev);
	pci_disable_device(pdev);

	/* Move to low power state */
	pci_set_power_state(pdev, PCI_D3hot);

	return rv;
}

/*
 * Called for each probed device when the device is resumed.
 *
 * @pdev Pointer to pci_dev structure
 *
 * return value
 *      0  Success
 *      <0 Error
 */
static int mtip_pci_resume(struct pci_dev *pdev)
{
	int rv = 0;
	struct driver_data *dd;

	dd = pci_get_drvdata(pdev);
	if (!dd) {
		dev_err(&pdev->dev,
			"Driver private data is NULL\n");
		return -EFAULT;
	}

	/* Move the device to active State */
	pci_set_power_state(pdev, PCI_D0);

	/* Restore PCI configuration space */
	pci_restore_state(pdev);

	/* Enable the PCI device */
	rv = pcim_enable_device(pdev);
	if (rv < 0) {
		dev_err(&pdev->dev,
			"Failed to enable card during resume\n");
		goto err;
	}
	pci_set_master(pdev);

	/*
	 * Calls hba reset, init port, and start port functions
	 * then enables interrupts
	 */
	rv = mtip_block_resume(dd);
	if (rv < 0)
		dev_err(&pdev->dev, "Unable to resume\n");

err:
	mtip_clear_bit(MTIP_DDF_RESUME_BIT, dd->flags);

	return rv;
}

/*
 * Shutdown routine
 *
 * @pdev Pointer to pci_dev structure
 *
 * return value
 *      None
 */
void mtip_pci_shutdown(struct pci_dev *pdev)
{
	struct driver_data *dd = pci_get_drvdata(pdev);
	if (dd)
		mtip_block_shutdown(dd);
}

/* Table of device ids supported by this driver */
static const struct pci_device_id mtip_pci_tbl[] = {
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P320H_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P322H_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P320S_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P325M_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P420H_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P420M_DEVICE_ID) },
	{ PCI_DEVICE(PCI_VENDOR_ID_MICRON, P425M_DEVICE_ID) },
	{ 0 }
};

/* Structure that describes the PCI driver functions */
static struct pci_driver mtip_pci_driver = {
	.name		= MTIP_DRV_NAME,
	.id_table	= mtip_pci_tbl,
	.probe		= mtip_pci_probe,
	.remove		= mtip_pci_remove,
	.suspend	= mtip_pci_suspend,
	.resume		= mtip_pci_resume,
	.shutdown	= mtip_pci_shutdown,
};

MODULE_DEVICE_TABLE(pci, mtip_pci_tbl);

/*
 * Module initialization function.
 *
 * Called once when the module is loaded. This function allocates a major
 * block device number to the Cyclone devices and registers the PCI layer
 * of the driver.
 *
 * Return value
 *      0 on success else error code.
 */
static int __init mtip_init(void)
{
	int rv = 0;

	pr_info(MTIP_DRV_NAME " Version " MTIP_DRV_VERSION "\n");

	memset(cpu_use, 0, sizeof(cpu_use));

	/* Allocate a major block device number to use with this driver */
	mtip_major = register_blkdev(0, MTIP_DRV_NAME);
	if (mtip_major <= 0) {
		pr_err("Unable to register block device (%d)\n", mtip_major);
		return -EBUSY;
	}

	dfs_parent = debugfs_create_dir("rssd", NULL);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
	if (IS_ERR_OR_NULL(dfs_parent)) {
#else
	if (!dfs_parent) {
#endif
		pr_err("Error creating debugfs parent\n");
		dfs_parent = NULL;
	}

	mtip_extra_init(dfs_parent);

	/* Register PCI operations */
	rv = pci_register_driver(&mtip_pci_driver);

	if (rv >= 0) {
		/* Create the sysfile for verbosity */
		rv = mtip_create_driver_sysfs(&mtip_pci_driver);
		if (rv < 0) {
			pr_err("Unable to create sys files\n");

			if (dfs_parent) {
				mtip_extra_destroy(dfs_parent);
				debugfs_remove(dfs_parent);
				dfs_parent = NULL;
			}
			unregister_blkdev(mtip_major, MTIP_DRV_NAME);
			pci_unregister_driver(&mtip_pci_driver);
			mtip_major = 0;
			return rv;
		}
	}

	return rv;
}

/*
 * Module de-initialization function.
 *
 * Called once when the module is unloaded. This function deallocates
 * the major block device number allocated by mtip_init() and
 * unregisters the PCI layer of the driver.
 *
 * Return value
 *      none
 */
static void __exit mtip_exit(void)
{

	mtip_remove_driver_sysfs(&mtip_pci_driver);

	if (dfs_parent) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
		mtip_extra_destroy(dfs_parent);
		debugfs_remove_recursive(dfs_parent);
		dfs_parent = NULL;
#endif
	}

	/* Release the allocated major block device number */
	unregister_blkdev(mtip_major, MTIP_DRV_NAME);

	/* Unregister the PCI driver */
	pci_unregister_driver(&mtip_pci_driver);

	/* Free any orphans */
	mtip_free_orphans();

	if (dfs_parent) {
		mtip_extra_destroy(dfs_parent);
		debugfs_remove(dfs_parent);
		dfs_parent = NULL;
	}

	mtip_major = 0;
}

MODULE_AUTHOR("Micron Technology, Inc");
MODULE_DESCRIPTION("Micron RealSSD p32x/p42x PCIe Block Driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(MTIP_DRV_VERSION);

module_init(mtip_init);
module_exit(mtip_exit);
