/*
 * extra.h - Helper header file for the P320/P420 SSD Block Driver
 *   Copyright (C) 2013 Micron Technology, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef __EXTRA_H__
#define __EXTRA_H__

#include <linux/hdreg.h>
#include <linux/bio.h>
#include <linux/version.h>
#include <linux/time.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR == 5)  || \
	(defined(RHEL_MINOR) && RHEL_MINOR == 0)   || \
	(defined(CONFIG_SUSE_KERNEL) && !(defined(SLES11SP2)))) 
	#define __percpu
#endif

struct driver_data;
struct host_to_dev_fis;
struct mtip_cmd;
struct mtip_port;

extern int mtip_exec_internal_command(struct mtip_port *port,
					struct host_to_dev_fis *fis,
					int fis_len,
					dma_addr_t buffer,
					int buf_len,
					u32 opts,
					gfp_t atomic,
					unsigned long timeout);
extern void mtip_pci_remove(struct pci_dev *pdev);
extern int mtip_init_device(struct pci_dev *pdev,
				const struct pci_device_id *ent,
				int my_node,
				int id);
extern inline void mtip_set_bit(u32 bit, unsigned long __percpu *pcpu);
extern inline void mtip_clear_bit(u32 bit, unsigned long __percpu *pcpu);
extern inline int mtip_test_bit(u32 bit, unsigned long __percpu *pcpu);

/* Demux fua & flush on breadth of kernels supported */

#if LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 32) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6 && \
	  defined(RHEL_MINOR) && RHEL_MINOR != 0))

	/* RHEL 6.1 & 6.2 */
	#define flushflag	(bio->bi_rw & BIO_FLUSH)
	#define fuaflag		(bio->bi_rw & BIO_FUA)
	#define trimflag	(bio_rw_flagged(bio, BIO_RW_DISCARD))

#elif LINUX_VERSION_CODE == KERNEL_VERSION(3, 0, 13) && \
	(defined(CONFIG_SUSE_KERNEL))

	/* SLES 11 SP2 */
	#define flushflag	(bio->bi_rw & REQ_FLUSH)
	#define fuaflag		(bio->bi_rw & REQ_FUA)
	#define trimflag	(bio->bi_rw & REQ_DISCARD)

#elif LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 18) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 5))

	/* Steal some unused bi_rw bits on RHEL 5.x */
	#define BIO_RW_FLUSH	8
	#define BIO_RW_FUA	9
	#define flushflag	(bio->bi_rw & (1 << BIO_RW_FLUSH))
	#define fuaflag		(bio->bi_rw & (1 << BIO_RW_FUA))
	#define trimflag	0 /* not supported */

#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 1, 0)

	#define flushflag	(bio->bi_rw & REQ_FLUSH)
	#define fuaflag		(bio->bi_rw & REQ_FUA)
	#define trimflag	(bio->bi_rw & REQ_DISCARD)

#else

	#define flushflag	0
	#define fuaflag		0
	#define trimflag	0

#endif

/* Timeout to rebind a driver instance to a new node */
#define REBIND_TIMEOUT		40

/*
 * Logging level: each definition corresponds
 * to a bit in 32-bit verbosity value
 */
#define	MTIP_ERR		(1 << 0)
#define	MTIP_WARNING		(1 << 1)
#define	MTIP_INFO		(1 << 2)
#define	MTIP_DEBUG		(1 << 3)

/* By default Warnings, Errors, and Info are enabled */
#define MTIP_LOG_DEFAULT	(MTIP_ERR | MTIP_WARNING | MTIP_INFO)
#define MTIP_LOG_ALL		(MTIP_ERR | MTIP_WARNING | MTIP_INFO | \
                                   MTIP_DEBUG)

/*
 * Subsystems for loggging
 * each definition corresponds to a bit in 32-bit log subsystem value
*/
#define	MTIP_INIT		(1 << 0)	/* Initialization activities */
#define MTIP_PCI		(1 << 1)	/* PCI layer */
#define MTIP_BLOCK		(1 << 2)	/* Block layer */
#define MTIP_AHCI		(1 << 3)	/* AHCI layer */
#define MTIP_HOTPLUG		(1 << 4)	/* Hot Plug activities */
#define MTIP_NCQ		(1 << 5)	/* NCQ commands logging */
#define MTIP_NONNCQ		(1 << 6)	/* Non NCQ commands logging */

#define MTIP_MOD_ALL     (MTIP_INIT | MTIP_PCI | MTIP_BLOCK | MTIP_AHCI | \
                            MTIP_HOTPLUG | MTIP_NCQ | MTIP_NONNCQ)
#define MTIP_MOD_DEFAULT MTIP_MOD_ALL /* By default all subsystems are enabled */

DECLARE_PER_CPU(int, pcpu_verbosity);
DECLARE_PER_CPU(int, pcpu_log_subsys);
DECLARE_PER_CPU(int, pcpu_debug_mode);
DECLARE_PER_CPU(int, pcpu_force_fua);

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 18)
	#define DEV_NAME(dd)	dev_name(&dd->pdev->dev)
#else
	#define DEV_NAME(dd)	(dd->pdev->dev.bus_id)
#endif

/*
 * Macro for logging
 */
#define mtip_printk(subsys, level, dd, format, arg...)			   \
	if ((subsys & __get_cpu_var(pcpu_log_subsys)) &&		   \
	    (level & __get_cpu_var(pcpu_verbosity))) {			   \
		switch (level) {					   \
		case MTIP_INFO:						   \
			printk(KERN_INFO "%s %s: "			   \
				format, dev_driver_string(&dd->pdev->dev), \
				DEV_NAME(dd), ## arg);			   \
			break;						   \
		case MTIP_WARNING:					   \
			printk(KERN_WARNING "%s %s: "			   \
				format, dev_driver_string(&dd->pdev->dev), \
				DEV_NAME(dd), ## arg);			   \
			break;						   \
		case MTIP_ERR:						   \
			printk(KERN_ERR "%s %s: "			   \
				format, dev_driver_string(&dd->pdev->dev), \
				DEV_NAME(dd), ## arg);			   \
			break;						   \
		case MTIP_DEBUG:					   \
			printk(KERN_DEBUG "%s %s: "			   \
				format, dev_driver_string(&dd->pdev->dev), \
				DEV_NAME(dd), ## arg);			   \
			break;						   \
		}							   \
	}

#ifndef pr_err
	#define pr_err(fmt, ...) \
		printk(KERN_ERR fmt, ##__VA_ARGS__)
#endif

struct vu_trim_entry {
	/* starting LBA of region to trim */
	u32 lba;
	/* unused */
	u16 rsvd;
	/* # of 512b blocks to trim starting at 'lba' */
	u16 range;
} __packed;

#define TRIM_TIMEOUT_MS		240000
#define MAX_VU_TRIM_ENTRIES     8       
#define MAX_VU_TRIM_ENTRY_LEN   0xfff8
struct vu_trim {
	/* Array of regions to trim */
	struct vu_trim_entry entry[MAX_VU_TRIM_ENTRIES];
} __packed;

typedef enum {
	MTIP_DBG_MODE_NONE = 0,
	MTIP_DBG_MODE_HALT = 1,    /* halt system on first error/timeout */
	MTIP_DBG_MODE_QUIESCE = 2, /* quiesce driver on first error/timeout */
	MTIP_DBG_MODE_MAX,
} debug_mode_e;

/* Collecting debug data interface structure */
#define DEBUG_DATA_FIRST_ERROR       0x1
#define DEBUG_DATA_LAST_ERROR        0x2

#define DEBUG_DATA_MAJOR_VER         0x1
#define DEBUG_DATA_MINOR_VER         0x0

#define DEBUG_SUCCESS                0x0
#define DEBUG_STATUS                 0x50

#define REQUEST_INFO                 0x01
#define RESET_DEBUG_DATA             0x02
#define GET_DEBUG_DATA               0x04
#define GET_EXT_DEBUG_DATA           0x08

#define RETRIEVE_FIRST_ERROR_DATA    0x00
#define RETRIEVE_LAST_ERROR_DATA     0x01
#define RETRIEVE_CURRENT_DATA        0x02

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 31)
	#define SECS_PER_HOUR	(60 * 60)
	#define SECS_PER_DAY	(SECS_PER_HOUR * 24)
#endif

struct os_calendar_time {
	int sec;
	int min;
	int hour;
	int mday;
	int mon;
	int year;
};

enum debug_data_error_code {
	debug_data_cmd_time_out = 0x1,
	debug_data_task_file_err,
	debug_data_host_bus_fatal_err,
	debug_data_host_bus_data_err,
	debug_data_interface_fatal_err,
	debug_data_data_len_mismatch_err,
	debug_data_non_queued_recovery_err
};

struct dd_cmd_prdt_info {
	unsigned int dba_l;
	unsigned int dba_u;
	unsigned int dbc:22;
	unsigned int reserved1:9;
	unsigned int i:1;
};

struct dd_ahci_h2d_register_fis {
	unsigned char fis_type;
	unsigned char port_mplex:4;
	unsigned char reserved:3;
	unsigned char c:1;
	unsigned char command;
	unsigned char feature_low;
	unsigned char lba0;
	unsigned char lba1_l;
	unsigned char lba2_h;
	unsigned char device;
	unsigned char lba3;
	unsigned char lba4_l;
	unsigned char lba5_h;
	unsigned char feature_high;
	unsigned char count_low;
	unsigned char count_high;
	unsigned char reserved1;
	unsigned char control;
	unsigned char reserved2[4];
};

struct dd_ahci_d2h_register_fis {
	unsigned char fis_type;
	unsigned char port_mplex:4;
	unsigned char reserved:2;
	unsigned char i:1;
	unsigned char reserved1:1;
	unsigned char status;
	unsigned char error;
	unsigned char lba0;
	unsigned char lba1_l;
	unsigned char lba2_h;
	unsigned char device;
	unsigned char lba3;
	unsigned char lba4_l;
	unsigned char lba5_h;
	unsigned char reserved2;
	unsigned char count_low;
	unsigned char count_high;
	unsigned char reserved3[6];
};

struct dd_pio_setup_fis {
	unsigned char  fis_type;
	unsigned char  port_mplex:4;
	unsigned char  reserved:1;
	unsigned char  d:1;
	unsigned char  i:1;
	unsigned char  reserved1:1;
	unsigned char  status;
	unsigned char  error;
	unsigned char  lba0;
	unsigned char  lba1_l;
	unsigned char  lba2_h;
	unsigned char  device;
	unsigned char  lba3;
	unsigned char  lba4_l;
	unsigned char  lba5_h;
	unsigned char  reserved2;
	unsigned char  count_low;
	unsigned char  count_high;
	unsigned char  reserved3;
	unsigned char  estatus;
	unsigned short tc;
	unsigned char  reserved4[2];
};

struct dd_dma_setup_fis {
	unsigned char fis_type;
	unsigned char port_mplex:4;
	unsigned char reserved:1;
	unsigned char d:1;
	unsigned char i:1;
	unsigned char a:1;
	unsigned char reserved1[2];
	unsigned int  dma_buf_low;
	unsigned int  dma_buf_high;
	unsigned int  reserved2;
	unsigned int  dma_buf_offset;
	unsigned int  dma_trans_cnt;
	unsigned int  reserved3;
};

struct dd_sdb_fis {
	unsigned char fis_type;
	unsigned char pm_port:4;
	unsigned char reserved:2;
	unsigned char i:1;
	unsigned char n:1;
	unsigned char status_low:3;
	unsigned char status_high:3;
	unsigned char reserved2:1;
	unsigned char error;
	unsigned int  reserved3;
};

struct dd_ahci_cmd_hdr_desc_info {
	unsigned int cfl:5;
	unsigned int a:1;
	unsigned int w:1;
	unsigned int p:1;
	unsigned int r:1;
	unsigned int b:1;
	unsigned int c:1;
	unsigned int reserved:1;
	unsigned int pmp:4;
	unsigned int prdtl:16;
};

struct dd_cmd_list_details {
	struct dd_ahci_h2d_register_fis  cfis;
	struct dd_ahci_cmd_hdr_desc_info di;
	unsigned int                     prd_byte_cnt;
	struct dd_cmd_prdt_info          prdt[33];
};

struct dd_ahci_received_fis {
	struct dd_dma_setup_fis         dma_setup_fis;
	unsigned char                   reserved1[4];
	struct dd_pio_setup_fis         pio_setup_fis;
	unsigned char                   reserved2[12];
	struct dd_ahci_d2h_register_fis d2h_fis;
	unsigned char                   reserved3[4];
	struct dd_sdb_fis               sdb_fis;
	unsigned char                   unknown_fis[64];
	unsigned char                   reserved4[96];
};

struct dd_ahci_mem_structure {
	struct dd_ahci_received_fis received_fis;
	unsigned int                cnt;
	struct dd_cmd_list_details  cmd_list[256];
};

struct dd_debug_data_header {
	unsigned short major_version;
	unsigned short minor_version;
	unsigned int   data_length;
	unsigned int   data_item_offset;
	unsigned int   reserved1;
	unsigned short month;
	unsigned short date;
	unsigned short year;
	unsigned short hour;
	unsigned short min;
	unsigned short sec;
	unsigned char  reserved[36];
};

struct pcie_capability {
	unsigned char  capid;
	unsigned char  nextcapptr;
	unsigned short pciecap;
	unsigned int   pciedevcap;
	unsigned short pciedevctrl;
	unsigned short pciedevsts;
	unsigned int   pcielnkcap;
	unsigned short pcielnkctrl;
	unsigned short pcielnksts;
};

struct pcie_pwrmgt_capability {
	unsigned char  pwrmgtcapid;
	unsigned char  nextcapptr;
	unsigned short pwrmgtcap;
	unsigned int   pwrmgtsts;
};

struct dd_pci_config {
	unsigned short vendor_id;
	unsigned short device_id;
	unsigned short command;
	unsigned short status;
	unsigned char  revision_id;
	unsigned char  prog_if;
	unsigned char  sub_class;
	unsigned char  base_class;
	unsigned char  cache_line_size;
	unsigned char  latency_timer;
	unsigned char  header_type;
	unsigned char  bist;
	unsigned int   base_addresses[6];
	unsigned int   cis;
	unsigned short sub_vendor_id;
	unsigned short sub_system_id;
	unsigned int   rom_base_address;
	unsigned char  cap;
	unsigned char  reserved2[3];
	unsigned int   reserved3;
	unsigned char  interrupt_line;
	unsigned char  interrupt_pin;
	unsigned char  minimum_grant;
	unsigned char  maximum_latency;
	struct pcie_capability pcie_cap;
	struct pcie_pwrmgt_capability  pcie_pwrmgt;
};

struct dd_hba_id {
	unsigned char id_string[21];
	unsigned char fw_version[8];
	unsigned char model[20];
	unsigned char reserved[64];
};

struct dd_micron_multiport_cmd_reg {
	unsigned int sact;
	unsigned int ci;
};

struct dd_micron_hw_sw_org {
	unsigned int num_slot_groups:3;
	unsigned int asic_style_design:1;
	unsigned int reserved0:4;
	unsigned int interface_rev_num:8;
	unsigned int disable_slot_grp_pxis:1;
	unsigned int reserved1:7;
	unsigned int disable_slot_grp_intr:1;
	unsigned int reserved2:7;
};

struct dd_ahci_port_reg {
	unsigned int px_clb;
	unsigned int px_clbu;
	unsigned int px_fb;
	unsigned int px_fbu;
	unsigned int px_is;
	unsigned int px_ie;
	unsigned int px_cmd;
	unsigned int reserved;
	unsigned int px_tfd;
	unsigned int px_sig;
	unsigned int px_ssts;
	unsigned int px_sctl;
	unsigned int px_serr;
	unsigned int px_sact;
	unsigned int px_ci;
	unsigned int px_sntf;
	unsigned int px_fbs;
	unsigned int reserved1[11];
	unsigned int px_micron_vs0;
	unsigned int px_micron_vs1;
	unsigned int px_vs_reserved;
	unsigned int px_sdbv;
};

struct dd_ahci_ghc_reg {
	unsigned int cap;
	unsigned int ghc;
	unsigned int is;
	unsigned int pi;
	unsigned int ver;
	unsigned int ccc_ctl;
	unsigned int ccc_ports;
	unsigned int em_loc;
	unsigned int em_ctl;
	unsigned int cap2;
	unsigned int bhoc;
};

struct dd_ahci_mem_reg {
	struct dd_ahci_ghc_reg             hba_reg;
	unsigned int                       reserved[0x1d];
	struct dd_micron_multiport_cmd_reg export_cmd_reg[7];
	unsigned int                       ven_specfic[0x9];
	struct dd_micron_hw_sw_org         hw_sw_org;
	struct dd_ahci_port_reg            port_reg;
};

/* This is the correctly padded structure of the above for reference */
struct dd_ahci_mem_reg_internal {
	struct dd_ahci_ghc_reg     hba_reg;
	u8                         rsvd[116];
	u8                         vend_spec_pad[92];
	struct dd_micron_hw_sw_org hw_sw_org;
	struct dd_ahci_port_reg    port_reg[8];
};

struct dd_driver_debug_data {
	struct dd_debug_data_header  debug_header;
	unsigned int                 error_code;
	struct dd_hba_id             hba_id;
	struct dd_ahci_mem_reg       ahci_mem_registers;
	struct dd_pci_config         pci_config;
	struct dd_ahci_mem_structure ahci_mem_struct;
};

struct dd_request_info {
	struct dd_debug_data_header  debug_header;
	unsigned int                 debug_data_size;
};

void mtip_getahcimemreg(struct driver_data *dd,
				struct dd_ahci_mem_structure *ahci_mem_struct);
void mtip_getahcipci(struct driver_data *dd, struct dd_pci_config *pciconfig);
void mtip_getahciid(struct driver_data *dd, struct dd_hba_id *hba_id);
void mtip_getahciregs(struct driver_data *dd, struct dd_ahci_mem_reg *mem_reg);
void mtip_getdebugheader(struct driver_data *dd,
				struct dd_debug_data_header *header_data);
void mtip_getdebugdata(struct driver_data *dd,
				struct dd_driver_debug_data *debugdata);
void mtip_collecttime(struct driver_data *dd, struct os_calendar_time *time);
int mtip_getdebugioctl(struct driver_data *dd, 
				struct host_to_dev_fis *fis,
				ide_task_request_t *req_task, 
				u8 *outbuf, 
				u32 buflen);

void diskstat_start(struct driver_data *dd, struct bio *bio);
void diskstat_end(struct driver_data *dd, struct mtip_cmd *cmd);
void diskstat_abort(struct driver_data *dd, struct bio *bio);
void init_pci_sysfs(struct driver_data *dd);
void cleanup_pci_sysfs(struct driver_data *dd);
int mtip_create_driver_sysfs(struct pci_driver *mtip_pci_driver);
void mtip_remove_driver_sysfs(struct pci_driver *mtip_pci_driver);
void mtip_extra_init(struct dentry *dfs_parent);
void mtip_extra_destroy(struct dentry *dfs_parent);
void debuglog_io_queued(struct driver_data *dd, u32 dir, sector_t sector,
							int len, u32 flags);
void debuglog_io_start(struct driver_data *dd, struct mtip_cmd *cmd, u32 dir,
					sector_t sector, int len, u32 flags);
void debuglog_io_complete(struct driver_data *dd, struct mtip_cmd *cmd,
				u32 dir, sector_t sector, int len, u32 flags);


#endif
