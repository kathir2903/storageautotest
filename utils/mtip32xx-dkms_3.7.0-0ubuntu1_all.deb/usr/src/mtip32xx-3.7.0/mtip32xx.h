/*
 * mtip32xx.h - Header file for the P320/P420 SSD Block Driver
 *   Copyright (C) 2013 Micron Technology, Inc.
 *
 * Portions of this code were derived from works subjected to the
 * following copyright:
 *    Copyright (C) 2009 Integrated Device Technology, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#ifndef __MTIP32XX_H__
#define __MTIP32XX_H__

#include <linux/spinlock.h>
#include <linux/rwsem.h>
#include <linux/ata.h>
#include <linux/interrupt.h>
#include <linux/genhd.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/circ_buf.h>

#include "extra.h"

enum {
	AHCI_CMD_TBL_HDR_SZ     = 0x80,
	AHCI_RX_FIS_SZ          = 256,
	AHCI_CMD_PREFETCH       = (1 << 7),
	RX_FIS_D2H_REG          = 0x40, /* offset of D2H Register FIS data */
	RX_FIS_PIO_SETUP        = 0x20, /* offset of PIO Setup FIS data */
	/* global controller registers */
	HOST_CAP                = 0x00, /* host capabilities */
	HOST_CTL                = 0x04, /* global host control */
	HOST_IRQ_STAT           = 0x08, /* interrupt status */
	HOST_PORTS_IMPL         = 0x0c, /* bitmap of implemented ports */
	HOST_VERSION            = 0x10, /* AHCI spec. version compliancy */
	HOST_EM_LOC             = 0x1c, /* Enclosure Management location */
	HOST_EM_CTL             = 0x20, /* Enclosure Management Control */
	HOST_CAP2               = 0x24, /* host capabilities, extended */
	/* HOST_CTL bits */
	HOST_RESET              = (1 << 0),  /* reset controller; self-clear */
	HOST_IRQ_EN             = (1 << 1),  /* global IRQ enable */
	HOST_AHCI_EN            = (1 << 31), /* AHCI enabled */
	/* HOST_CAP bits */
	HOST_CAP_SXS            = (1 << 5),  /* Supports External SATA */
	HOST_CAP_EMS            = (1 << 6),  /* Enclosure Management support */
	HOST_CAP_CCC            = (1 << 7),  /* Cmd Completion Coalescing */
	HOST_CAP_PART           = (1 << 13), /* Partial state capable */
	HOST_CAP_SSC            = (1 << 14), /* Slumber state capable */
	HOST_CAP_PIO_MULTI      = (1 << 15), /* PIO multiple DRQ support */
	HOST_CAP_FBS            = (1 << 16), /* FIS-based switching support */
	HOST_CAP_PMP            = (1 << 17), /* Port Multiplier support */
	HOST_CAP_ONLY           = (1 << 18), /* Supports AHCI mode only */
	HOST_CAP_CLO            = (1 << 24), /* Cmd List Override support */
	HOST_CAP_LED            = (1 << 25), /* Supports activity LED */
	HOST_CAP_ALPM           = (1 << 26), /* Aggressive Link PM support */
	HOST_CAP_SSS            = (1 << 27), /* Staggered Spin-up */
	HOST_CAP_MPS            = (1 << 28), /* Mechanical presence switch */
	HOST_CAP_SNTF           = (1 << 29), /* SNotification register */
	HOST_CAP_NCQ            = (1 << 30), /* Native Command Queueing */
	HOST_CAP_64             = (1 << 31), /* PCI DAC (64-bit DMA) support */
	/* HOST_CAP2 bits */
	HOST_CAP2_BOH           = (1 << 0),  /* BIOS/OS handoff supported */
	HOST_CAP2_NVMHCI        = (1 << 1),  /* NVMHCI supported */
	HOST_CAP2_APST          = (1 << 2),  /* Automatic partial to slumber */
	/* registers for each SATA port */
	PORT_LST_ADDR           = 0x00, /* command list DMA addr */
	PORT_LST_ADDR_HI        = 0x04, /* command list DMA addr hi */
	PORT_FIS_ADDR           = 0x08, /* FIS rx buf addr */
	PORT_FIS_ADDR_HI        = 0x0c, /* FIS rx buf addr hi */
	PORT_IRQ_STAT           = 0x10, /* interrupt status */
	PORT_IRQ_MASK           = 0x14, /* interrupt enable/disable mask */
	PORT_CMD                = 0x18, /* port command */
	PORT_TFDATA             = 0x20, /* taskfile data */
	PORT_SIG                = 0x24, /* device TF signature */
	PORT_SCR_STAT           = 0x28, /* SATA phy register: SStatus */
	PORT_SCR_CTL            = 0x2c, /* SATA phy register: SControl */
	PORT_SCR_ERR            = 0x30, /* SATA phy register: SError */
	PORT_SCR_ACT            = 0x34, /* SATA phy register: SActive */
	PORT_SCR_NTF            = 0x3c, /* SATA phy register: SNotification */
	/* PORT_IRQ_{STAT,MASK} bits */
	PORT_IRQ_COLD_PRES      = (1 << 31), /* cold presence detect */
	PORT_IRQ_TF_ERR         = (1 << 30), /* task file error */
	PORT_IRQ_HBUS_ERR       = (1 << 29), /* host bus fatal error */
	PORT_IRQ_HBUS_DATA_ERR  = (1 << 28), /* host bus data error */
	PORT_IRQ_IF_ERR         = (1 << 27), /* interface fatal error */
	PORT_IRQ_IF_NONFATAL    = (1 << 26), /* interface non-fatal error */
	PORT_IRQ_OVERFLOW       = (1 << 24), /* xfer exhausted available S/G */
	PORT_IRQ_BAD_PMP        = (1 << 23), /* incorrect port multiplier */
	PORT_IRQ_PHYRDY         = (1 << 22), /* PhyRdy changed */
	PORT_IRQ_CONNECT        = (1 << 6), /* port connect change status */
	PORT_IRQ_SG_DONE        = (1 << 5), /* descriptor processed */
	PORT_IRQ_UNK_FIS        = (1 << 4), /* unknown FIS rx'd */
	PORT_IRQ_SDB_FIS        = (1 << 3), /* Set Device Bits FIS rx'd */
	PORT_IRQ_DMAS_FIS       = (1 << 2), /* DMA Setup FIS rx'd */
	PORT_IRQ_PIOS_FIS       = (1 << 1), /* PIO Setup FIS rx'd */
	PORT_IRQ_D2H_REG_FIS    = (1 << 0), /* D2H Register FIS rx'd */
	/* PORT_CMD bits */
	PORT_CMD_ASP            = (1 << 27), /* Aggressive Slumber/Partial */
	PORT_CMD_ALPE           = (1 << 26), /* Aggressive Link PM enable */
	PORT_CMD_ATAPI          = (1 << 24), /* Device is ATAPI */
	PORT_CMD_PMP            = (1 << 17), /* PMP attached */
	PORT_CMD_LIST_ON        = (1 << 15), /* cmd list DMA engine running */
	PORT_CMD_FIS_ON         = (1 << 14), /* FIS DMA engine running */
	PORT_CMD_FIS_RX         = (1 << 4), /* Enable FIS receive DMA engine */
	PORT_CMD_CLO            = (1 << 3), /* Command list override */
	PORT_CMD_POWER_ON       = (1 << 2), /* Power up device */
	PORT_CMD_SPIN_UP        = (1 << 1), /* Spin up device */
	PORT_CMD_START          = (1 << 0), /* Enable port DMA engine */
};

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 25)
enum {
	ATA_CMD_SEC_SET_PASS		= 0xF1,
	ATA_CMD_SEC_UNLOCK		= 0xF2,
	ATA_CMD_SEC_ERASE_PREP		= 0xF3,
	ATA_CMD_SEC_ERASE_UNIT		= 0xF4,
	ATA_CMD_SEC_DISABLE_PASS	= 0xF6,
	ATA_CMD_DOWNLOAD_MICRO		= 0x92,
	ATA_CMD_SMART			= 0xB0,
	ATA_SMART_ENABLE		= 0xD8,
	ATA_SMART_READ_VALUES		= 0xD0,
	ATA_SMART_READ_THRESHOLDS	= 0xD1,
};
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	#define mtip_bio_endio(b, sz, st)       bio_endio(b, st);
#else
	#define mtip_bio_endio(b, sz, st)       bio_endio(b, sz, st);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18) && \
	((defined(RHEL_MAJOR) && RHEL_MAJOR == 5)  || \
	(defined(RHEL_MINOR) && RHEL_MINOR == 0)   || \
	(defined(CONFIG_SUSE_KERNEL)))
	#define __percpu
	#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 0, 13)) 
		#define this_cpu_ptr(p) per_cpu_ptr(p, smp_processor_id())
	#endif
#endif

/*
 * Length of Disk name in gendisk Structure
 */
#define DISK_NAME_LEN			32

#define MTIP_FLAGS_BUFLEN		128

/* check for erase mode support during secure erase */
#define MTIP_SEC_ERASE_MODE		0x2

/* Offset of Subsystem Device ID in pci confoguration space */
#define PCI_SUBSYSTEM_DEVICEID		0x2E

/* offset of Device Control register in PCIe extended capabilites space */
#define PCIE_CONFIG_EXT_DEVICE_CONTROL_OFFSET	0x48

/* # of times to retry timed out IOs */
#define MTIP_MAX_RETRIES		3	

/* # of unhandled timeouts before invoking timeout handler directly */
#define MTIP_UNHANDLED_TO_THRESHOLD	125

/* Various timeout values in ms */
#define MTIP_NCQ_COMMAND_TIMEOUT_MS     15000
#define MTIP_INT_CMD_TIMEOUT_MS         5000
#define MTIP_QUIESCE_TIMEOUT_MS         (MTIP_NCQ_COMMAND_TIMEOUT_MS * \
					(MTIP_MAX_RETRIES + 1))

/* check for timeouts every 500ms */
#define MTIP_TIMEOUT_CHECK_PERIOD	500

/* ftl rebuild */
#define MTIP_FTL_REBUILD_OFFSET		142
#define MTIP_FTL_REBUILD_MAGIC		0xED51
#define MTIP_FTL_REBUILD_TIMEOUT_MS	2400000

/* unaligned IO handling */
#define MTIP_MAX_UNALIGNED_SLOTS	2	

/* Macro to extract the tag bit number from a tag value. */
#define MTIP_TAG_BIT(tag)		(tag & 0x1F)

/*
 * Macro to extract the tag index from a tag value. The index
 * is used to access the correct SActive/Command Issue register based
 * on the tag value.
 */
#define MTIP_TAG_INDEX(tag)		(tag >> 5)

/*
 * Maximum number of scatter gather entries
 * a single command may have.
 *
 * Notes on conditional below:
 * 1) 2.6.37 and earlier kernels have a bug in the direct io path
 *    where large direct IOs (> BIO_MAX_PAGES) are not properly
 *    checked for size before calling dio_bio_alloc().  A NULL
 *    return is then dereferenced, causing a kernel crash.
 * 2) XFS on SLES 11 SP2 contains a bug in the xfs_alloc_ioend_bio()
 *    routine where a bio_alloc() call can be made for more segments 
 *    than the block layer bio allocator can handle and the return code 
 *    for the failed allocation is not checked.  This results in a NULL 
 *    deference and kernel crash.
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 38) &&         \
	(!(defined(CONFIG_SUSE_KERNEL) &&                     \
	   (LINUX_VERSION_CODE == KERNEL_VERSION(3, 0, 13))))
	#define MTIP_MAX_SG		504
#else
	#define MTIP_MAX_SG		256
#endif

/*
 * Maximum number of slot groups (Command Issue & s_active registers)
 */
#define MTIP_MAX_SLOT_GROUPS		8

/* Internal command tag. */
#define MTIP_TAG_INTERNAL		0

/* Micron Vendor ID & P320/P420 Device IDs */
#define PCI_VENDOR_ID_MICRON		0x1344
#define P320H_DEVICE_ID     		0x5150
#define P322H_DEVICE_ID     		0x5151
#define P320S_DEVICE_ID     		0x5152
#define P325M_DEVICE_ID     		0x5153
#define P420H_DEVICE_ID     		0x5160
#define P420M_DEVICE_ID     		0x5161
#define P425M_DEVICE_ID      		0x5163

/* Driver name and version strings */
#define MTIP_DRV_NAME			"mtip32xx"
#define MTIP_DRV_VERSION		"3.7.0"

#define MTIP_DFS_MAX_BUF_SIZE		512

/*
 * Maximum number of minor device numbers per device.
 * For RHEL 6.X and SLES 11 => Max 255 partitions supported
 * For RHEL 5.X => Only 15 partitions supported
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
	#define MTIP_MAX_MINORS		256
#else
	#define MTIP_MAX_MINORS		16
#endif

/* Maximum number of supported command slots. */
#define MTIP_MAX_COMMAND_SLOTS	(MTIP_MAX_SLOT_GROUPS * 32)

/*
 * Per-tag bitfield size in longs.
 * Linux bit manipulation functions
 * (i.e. test_and_set_bit, find_next_zero_bit)
 * manipulate memory in longs, so we try to make the math work.
 * take the slot groups and find the number of longs, rounding up.
 * Careful! i386 and x86_64 use different size longs!
 */
#define U32_PER_LONG	(sizeof(long) / sizeof(u32))
#define SLOTBITS_IN_LONGS ((MTIP_MAX_SLOT_GROUPS + \
				(U32_PER_LONG-1))/U32_PER_LONG)

/* BAR number used to access the HBA registers. */
#define MTIP_ABAR			5
#define MTIP_IOBAR			4

/* Forced Unit Access Bit */
#define FUA_BIT    			0x80

#define dbg_printk(format, arg...) \
	mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd, format, ##arg);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
 #define MTIP_INIT_WORK(grp)                                     \
	INIT_WORK(&dd->work[grp].work, workq_sdbf##grp);
 #define DEFINE_HANDLER(group)                                   \
	static void workq_sdbf##group(struct work_struct *work) \
	{							\
		struct mtip_work *w =				\
			(struct mtip_work *) work;		\
		workq_sdbfx(w->port, group, w->completed);	\
	}
#else
 #define MTIP_INIT_WORK(grp) \
	INIT_WORK((struct work_struct *) &dd->work[grp].work,	\
		workq_sdbf##grp, (void *) &dd->work[grp]);
 #define DEFINE_HANDLER(group)					\
	static void workq_sdbf##group(void *arg)		\
	{							\
		struct mtip_work *w =				\
			(struct mtip_work *) arg;		\
		workq_sdbfx(w->port, group, w->completed);	\
	}
#endif

#define __force_bit2int (unsigned int __force)

enum {
	/* below are bit numbers in 'flags' defined in driver_data */
	MTIP_DDF_IC_ACTIVE_BIT		= 0,  /* pio/ioctl */
	MTIP_DDF_EH_ACTIVE_BIT		= 1,  /* error handling */
	MTIP_DDF_SE_ACTIVE_BIT		= 2,  /* secure erase */
	MTIP_DDF_DM_ACTIVE_BIT		= 3,  /* download microcde */
	MTIP_DDF_TO_ACTIVE_BIT		= 4,  /* timeout */
	MTIP_DDF_ISSUE_CMDS_BIT		= 5,  /* queued IOs to issue */
	MTIP_DDF_REBUILD_BIT		= 6,  /* ftl rebuild */
	MTIP_DDF_SVC_THD_ACTIVE_BIT	= 7,  /* service thread active */
	MTIP_DDF_SVC_THD_STOP_BIT	= 8,  /* service thread stop */
	MTIP_DDF_REMOVE_PENDING_BIT	= 9,  /* surprise/orderly removal */
	MTIP_DDF_OVER_TEMP_BIT		= 10, /* drive over temp */
	MTIP_DDF_WRITE_PROTECT_BIT	= 11, /* EOL write protect */
	MTIP_DDF_FW_RESET_BIT		= 12, /* FW is in reset */
	MTIP_DDF_RESUME_BIT		= 13, /* resume in process */
	MTIP_DDF_REBUILD_FAILED_BIT	= 14, /* rebuild failure */
	MTIP_DDF_FROZEN_BIT		= 15, /* fs frozen */
	MTIP_DDF_SYSFS_INIT_BIT		= 16, /* sysfs init done */
	MTIP_DDF_ORPHAN_BIT		= 17, /* device orphan'd */
	MTIP_DDF_FAIL_OPEN_BIT		= 18, /* fail opens */
	MTIP_DDF_SEC_LOCK_BIT		= 19, /* drive security locked */
	MTIP_DDF_SR_BIT			= 20, /* surprise removal */
	MTIP_DDF_QUIESCE_BIT		= 21, /* quiesce driver */
	MTIP_DDF_HALT_BIT		= 22, /* driver is halted */
	MTIP_DDF_LAST_BIT		= 23, /* always last, don't use */


	MTIP_DDF_SVC_THD_WORK   = ((1 << MTIP_DDF_EH_ACTIVE_BIT)      | \
				   (1 << MTIP_DDF_TO_ACTIVE_BIT)      | \
				   (1 << MTIP_DDF_ISSUE_CMDS_BIT)     | \
				   (1 << MTIP_DDF_REBUILD_BIT)        | \
				   (1 << MTIP_DDF_SVC_THD_STOP_BIT)),


	MTIP_DDF_FAIL_IO	= ((1 << MTIP_DDF_REMOVE_PENDING_BIT) | \
				   (1 << MTIP_DDF_OVER_TEMP_BIT)      | \
				   (1 << MTIP_DDF_REBUILD_FAILED_BIT) | \
				   (1 << MTIP_DDF_WRITE_PROTECT_BIT)  | \
				   (1 << MTIP_DDF_SEC_LOCK_BIT)       | \
				   (1 << MTIP_DDF_SR_BIT)             | \
				   (1 << MTIP_DDF_QUIESCE_BIT)        | \
				   (1 << MTIP_DDF_SE_ACTIVE_BIT)      | \
				   (1 << MTIP_DDF_FW_RESET_BIT)),

	MTIP_DDF_QUEUE_IO	= ((1 << MTIP_DDF_EH_ACTIVE_BIT)	| \
				   (1 << MTIP_DDF_TO_ACTIVE_BIT)),
};

const char *mtip_flag_str[MTIP_DDF_LAST_BIT] = {
	"IC_ACT" , "EH_ACT", "SE_ACT", "DM_ACT", "TO_ACT", "ISS_CMD", "RBLD",
	"SVC_ACT", "SVC_STOP", "REM_PEND", "OVER_TEMP", "W_PROT", 
	"FW_RESET", "RESUME", "RBLD_FAIL", "FRZN", "SYSFS_INIT", "ORPHAN",
	"FAIL_OPEN", "SEC_LOCK", "SURP_REM", "QUIESCE_MODE", "HALT_MODE"
};

struct smart_attr {
	u8 attr_id;
	u16 flags;
	u8 cur;
	u8 worst;
	u32 data;
	u8 res[3];
} __packed;

struct mtip_trim_entry {
	u32 lba; /* starting LBA of region to trim */
	u16 rsvd;
	u16 range; /* # of 512b blocks to trim starting at 'lba' */
} __packed;

#define MTIP_MAX_TRIM_ENTRIES   	8
#define MTIP_MAX_TRIM_ENTRY_LEN 	0xfff8
struct mtip_trim {
	/* Array of regions to trim */
	struct mtip_trim_entry entry[MTIP_MAX_TRIM_ENTRIES];
} __packed;

/* Register Frame Information Structure (FIS), host to device. */
struct host_to_dev_fis {
	/*
	 * FIS type.
	 * - 27h Register FIS, host to device.
	 * - 34h Register FIS, device to host.
	 * - 39h DMA Activate FIS, device to host.
	 * - 41h DMA Setup FIS, bi-directional.
	 * - 46h Data FIS, bi-directional.
	 * - 58h BIST Activate FIS, bi-directional.
	 * - 5Fh PIO Setup FIS, device to host.
	 * - A1h Set Device Bits FIS, device to host.
	 */
	unsigned char type;
	unsigned char opts;
	unsigned char command;
	unsigned char features;

	union {
		unsigned char lba_low;
		unsigned char sector;
	};
	union {
		unsigned char lba_mid;
		unsigned char cyl_low;
	};
	union {
		unsigned char lba_hi;
		unsigned char cyl_hi;
	};
	union {
		unsigned char device;
		unsigned char head;
	};

	union {
		unsigned char lba_low_ex;
		unsigned char sector_ex;
	};
	union {
		unsigned char lba_mid_ex;
		unsigned char cyl_low_ex;
	};
	union {
		unsigned char lba_hi_ex;
		unsigned char cyl_hi_ex;
	};
	unsigned char features_ex;

	unsigned char sect_count;
	unsigned char sect_cnt_ex;
	unsigned char res2;
	unsigned char control;

	unsigned int res3;
};

/* Command header structure. */
struct mtip_cmd_hdr {
	/*
	 * Command options.
	 * - Bits 31:16 Number of PRD entries.
	 * - Bits 15:8 Unused in this implementation.
	 * - Bit 7 Prefetch bit, informs the drive to prefetch PRD entries.
	 * - Bit 6 Write bit, should be set when writing data to the device.
	 * - Bit 5 Unused in this implementation.
	 * - Bits 4:0 Length of the command FIS in DWords (DWord = 4 bytes).
	 */
	unsigned int opts;
	/* This field is unsed when using NCQ. */
	union {
		unsigned int byte_count;
		unsigned int status;
	};
	/*
	 * Lower 32 bits of the command table address associated with this
	 * header. The command table addresses must be 128 byte aligned.
	 */
	unsigned int ctba;
	/*
	 * If 64 bit addressing is used this field is the upper 32 bits
	 * of the command table address associated with this command.
	 */
	unsigned int ctbau;
	/* Reserved and unused. */
	unsigned int res[4];
};

/* Command scatter gather structure (PRD). */
struct mtip_cmd_sg {
	/*
	 * Low 32 bits of the data buffer address. For P320 this
	 * address must be 8 byte aligned signified by bits 2:0 being
	 * set to 0.
	 */
	unsigned int dba;
	/*
	 * When 64 bit addressing is used this field is the upper
	 * 32 bits of the data buffer address.
	 */
	unsigned int dba_upper;
	/* Unused. */
	unsigned int reserved;
	/*
	 * Bit 31: interrupt when this data block has been transferred.
	 * Bits 30..22: reserved
	 * Bits 21..0: byte count (minus 1).  For P320 the byte count must be
	 * 		8 byte aligned signified by bits 2:0 being set to 1.
	 */
	unsigned int info;
};
struct mtip_port;

/* Structure used to describe a command. */
struct mtip_cmd {

	struct mtip_cmd_hdr *command_header; /* ptr to command header entry */

	dma_addr_t command_header_dma; /* corresponding physical address */

	void *command; /* ptr to command table entry */

	dma_addr_t command_dma; /* corresponding physical address */

	void *comp_data; /* data passed to completion function comp_func() */

	/*
	 * Completion function called by the ISR upon completion of
	 * a command.
	 */
	void (*comp_func)(struct mtip_port *port,
				int tag,
				void *data,
				int status);

	/* Additional callback function that may be called by comp_func() */
	void (*async_callback)(void *data, int status);

	void *async_data; /* Addl. data passed to async_callback() */

	int unaligned; /* command is unaligned on 4k boundary */

	int scatter_ents; /* Number of scatter list entries used */

	struct scatterlist sg[MTIP_MAX_SG]; /* Scatter list entries */

	int retries; /* The number of retries left for this command. */

	int direction; /* Data transfer direction */

	unsigned long comp_time; /* command completion time, in jiffies */

	unsigned long issue_time; /* jiffies time,command was submitted to hw */

	unsigned long start_time; /* jiffies time,command submitted to driver */

	atomic_t active; /* declares if this command sent to the drive. */

#ifdef MTIP_DEBUGLOG
	struct timespec submit_tv;
	struct timespec complete_tv;
#endif

} ____cacheline_aligned_in_smp;

/* Structure used to describe a port. */
struct mtip_port {

	/* Pointer back to the driver data for this port. */
	struct driver_data *dd;

	/*
	 * Used to determine if the data pointed to by the
	 * identify field is valid.
	 */
	unsigned long identify_valid;

	/* Base address of the memory mapped IO for the port. */
	void __iomem *mmio;

	/* Array of pointers to the memory mapped s_active registers. */
	void __iomem *s_active[MTIP_MAX_SLOT_GROUPS];

	/* Array of pointers to the memory mapped completed registers. */
	void __iomem *completed[MTIP_MAX_SLOT_GROUPS];

	/* Array of pointers to the memory mapped Command Issue registers. */
	void __iomem *cmd_issue[MTIP_MAX_SLOT_GROUPS];

	/* DMA region for RX Fis, Identify, RLE10, and SMART buffers */
	void *block1;
	dma_addr_t block1_dma;

	/* RX Fix pointers */
	void *rxfis;
	dma_addr_t rxfis_dma;

	/* Identify buffer pointers */
	u16 *identify;
	dma_addr_t identify_dma;

	/* Sector buffer pointers */
	u16 *log_buf;
	dma_addr_t log_buf_dma;

	/* Smart buffer pointers */
	u8 *smart_buf;
	dma_addr_t smart_buf_dma;

	/* DMA region for command list */
	void *command_list;
	dma_addr_t command_list_dma;

	/*
	 * Bit significant, used to determine if a command slot has
	 * been allocated. i.e. the slot is in use.  Bits are cleared
	 * when the command slot and all associated data structures
	 * are no longer needed.
	 */
	unsigned long allocated[SLOTBITS_IN_LONGS];

	/*
	 * used to queue commands when an internal command is in progress
	 * or error handling is active
	 */
	unsigned long cmds_to_issue[SLOTBITS_IN_LONGS];

	/*
	 * Array of command slots. Structure includes pointers to the
	 * command header and command table, and completion function and data
	 * pointers.
	 */
	struct mtip_cmd commands[MTIP_MAX_COMMAND_SLOTS];

	/*
	 * Timer used to complete commands that have been active for too long.
	 */
	struct timer_list cmd_timer;
	unsigned long ic_pause_timer;

	/*
	 * Semaphore used to block threads if there are no
	 * command slots available.
	 */
	struct semaphore cmd_slot;

	/* 
	 * Semaphore to control queue depth of unaligned IOs
	 */
	struct semaphore cmd_slot_unal;

	/* Spinlock for working around command-issue bug. */
	spinlock_t cmd_issue_lock[MTIP_MAX_SLOT_GROUPS];

	/* Variable to propagate internal command status */
	int int_cmd_status;
} ____cacheline_aligned_in_smp;

/* Structure to track completion workers */
struct mtip_work {
	struct work_struct work;
	void *port;
	int cpu_binding;
	u32 completed;
} ____cacheline_aligned_in_smp;

/*
 * Driver private data structure.
 *
 * One structure is allocated per probed device.
 */
struct driver_data {
	void __iomem *mmio; /* Base address of the HBA registers. */

	int major; /* Major device number. */

	int instance; /* Instance number. First device probed is 0, ... */

	unsigned long index; /* Index to determine the disk name */

	struct rw_semaphore sync_sem; /* Synchronize internal/external IOs */

	struct gendisk *disk; /* Pointer to our gendisk structure. */

	struct pci_dev *pdev; /* Pointer to the PCI device structure. */

	const struct pci_device_id *pent; /* storage for pci_device_id */

	struct request_queue *queue; /* Our request queue. */

	struct block_device *bdev; /* freeze/thaw during suspend/resume */

	struct super_block *frozen_sb; /* FS layer super block for freezing */

	struct mtip_port *port; /* Pointer to the port data structure. */

	unsigned long __percpu *flags; /* bit set after getting pcpu var */

	struct task_struct *mtip_svc_handler; /* task_struct of svc thd */

	wait_queue_head_t svc_wait; /* svc thd wait control */

	struct dentry *dfs_node; /* debugfs entry containers */
	struct dentry *dfs_flags;
	struct dentry *dfs_registers;

	int numa_node; /* Numa node device is affinitized to */

	int isr_binding; /* Core to which interrupt is affinitized */

	char workq_name[32]; /* Workq name */

	struct workqueue_struct *isr_workq; /* Workq for completion threads */
	
	struct mtip_work work[MTIP_MAX_SLOT_GROUPS]; /* completion workers */

	atomic_t irq_workers_active; /* Count of active completion workers */

	u32 port_stat; /* Storage for error handler */

	char disk_name[DISK_NAME_LEN]; /* Copy of disk name */

	int unal_qdepth; /* qdepth of unaligned IO queue */

	struct dd_driver_debug_data first_error_state; /*  Debug state */

	struct dd_driver_debug_data last_error_state;

	struct dd_driver_debug_data current_state;

	unsigned int first_error_flag;  /* Flag to indicate error state */

	/* IO mapped IO bar for register sysfs interface */
	void __iomem *ioio;

	/* Container for register address */
	u32 reg_offset;

	/* Flag to indicate pci sysfs initialization */
	int pci_sysfs;

	/* Track open/release */
	atomic_t refcount;

	/* Online dd's linkage */
	struct list_head online_list;

	/* Orphaned dd's linkage */
	struct list_head orphan_list;

	/* Removing list */
	struct list_head remove_list;

	/* Trim support flag */
	int trim_supp;

	/* Stuck condition counters */
	atomic_t timeout_cnt;

	/* Lock used to access the queue */
	spinlock_t completion_lock;

#ifdef MTIP_DEBUGLOG
	struct circ_buf debuglog;
	spinlock_t debuglog_lock;
#endif

} ____cacheline_aligned_in_smp;

#endif
