/*
 * Helper Functions for Driver for the Micron P320/P420 family of SSDs
 *   Copyright (C) 2013 Micron Technology, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <linux/time.h>
#include <linux/ctype.h>
#include "extra.h"
#include "mtip32xx.h"

static int stats = 0;
module_param(stats, int, 0644);
MODULE_PARM_DESC(stats, "Enable (1) or disable (0) IO statistics collection.");
static DEFINE_PER_CPU(int, pcpu_stats);

DEFINE_PER_CPU(int, pcpu_verbosity);
DEFINE_PER_CPU(int, pcpu_log_subsys);
DEFINE_PER_CPU(int, pcpu_debug_mode);
DEFINE_PER_CPU(int, pcpu_force_fua);

struct list_head online_list;
struct list_head orphan_list;
struct list_head removing_list;
spinlock_t dev_lock;
spinlock_t orphan_lock;
struct mutex rebind_mutex;
struct completion rebind_comp;
struct dentry *dfs_device_status = NULL;
static int new_binding;

/*
 * Following are routines to track disk statistics and
 * export data through /sys/block/rssdX/stat
 */

void diskstat_start(struct driver_data *dd, struct bio *bio)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)
	if (!__get_cpu_var(pcpu_stats))
		return;
	
	{
		struct hd_struct *part;
		int cpu;

		cpu = part_stat_lock();
		part = disk_map_sector_rcu(dd->disk, bio->bi_sector);

		/* This is not SMP safe pre 2.6.39 */
		part_inc_in_flight(part, bio_data_dir(bio));

		part_stat_unlock();
	}
#endif
}

void diskstat_end(struct driver_data *dd, struct mtip_cmd *cmd)
{
	if (!__get_cpu_var(pcpu_stats))
		return;

	{
		struct bio *bio = cmd->async_data;
		unsigned long hw_wait = jiffies - cmd->issue_time;
		unsigned long queue_wait = cmd->issue_time - cmd->start_time;
		unsigned long n_sect = bio->bi_size >> 9;
		int rw = bio_data_dir(bio);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
		{
			struct hd_struct *part;
			int cpu = part_stat_lock(); 

			part = disk_map_sector_rcu(dd->disk, bio->bi_sector);

 #if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)
			/* This is not SMP safe pre 2.6.39 */
			part_dec_in_flight(part, rw);
 #endif
			part_stat_inc(cpu, part, ios[rw]);
			part_stat_add(cpu, part, ticks[rw], hw_wait);
			part_stat_add(cpu, part, sectors[rw], n_sect);
			part_stat_add(cpu, part, io_ticks, hw_wait);
			part_stat_add(cpu, part, time_in_queue, queue_wait);

			part_stat_unlock();
		}
#else
		all_stat_add(dd->disk, ios[rw], 1, bio->bi_sector);
		all_stat_add(dd->disk, ticks[rw], hw_wait, bio->bi_sector);
		all_stat_add(dd->disk, sectors[rw], n_sect, bio->bi_sector);
		all_stat_add(dd->disk, io_ticks, hw_wait, bio->bi_sector);
		all_stat_add(dd->disk, time_in_queue, queue_wait, bio->bi_sector);
#endif
	}
}

void diskstat_abort(struct driver_data *dd, struct bio *bio)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 39)
	if (!__get_cpu_var(pcpu_stats))
		return;

	{
		struct hd_struct *part;
		int cpu;

		cpu = part_stat_lock();
		part = disk_map_sector_rcu(dd->disk, bio->bi_sector);

		/* This is not SMP safe pre 2.6.39 */
		part_dec_in_flight(part, bio_data_dir(bio));

		part_stat_unlock();
	}
#endif
}

static ssize_t read_dump_reg(struct device *dev, 
				struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev;
	struct driver_data *dd = NULL;
	u32 valid, val, reg_val;
	unsigned long to;

	pdev = to_pci_dev(dev);
	if (pdev)
		dd = pci_get_drvdata(pdev);

	if (!dd) {
		pr_err(MTIP_DRV_NAME "%s: unable to get drive data\n", 
								__func__);
		return -EFAULT;
	}

	if (!dd->ioio) {
		mtip_printk(MTIP_PCI, MTIP_WARNING, dd,
			"%s: iobar not setup for register access, trying booting with 'pci=nocrs'\n",
			__func__);
		return -EFAULT;
	}

	reg_val = dd->reg_offset;
	iowrite32(reg_val, dd->ioio + 0x8);

	to = jiffies + msecs_to_jiffies(5000);
	valid = 0;
	do {
		if (ioread32(dd->ioio + 0x8) & (1 << 13)) {
			val = ioread32(dd->ioio + 0xc);
			valid = 1;
			break;
		}
		msleep(1);
	} while (time_before(jiffies, to));

	if (valid)
		return sprintf(&buf[0], "%08x:%08x\n", dd->reg_offset, val);
	else
		return sprintf(&buf[0], "%08x:<timeout>\n", dd->reg_offset);
}

static ssize_t read_set_reg(struct device *dev, struct device_attribute *attr, 
				const char *buf, size_t count)
{
	struct pci_dev *pdev;
        struct driver_data *dd = NULL;
	u32 val;

	pdev = to_pci_dev(dev);
	if (pdev)
		dd = pci_get_drvdata(pdev);

	if (!dd) {
		pr_err(MTIP_DRV_NAME "%s: unable to get drive data\n",
								 __func__);
		return -EFAULT;
	}

	if (sscanf(buf, "%x", &val) < 0) {
		mtip_printk(MTIP_PCI, MTIP_DEBUG, dd, 
			"%s: Bad input\n", __func__);
		return -EINVAL;
	}

	mtip_printk(MTIP_PCI, MTIP_DEBUG, dd, "%s: Register %08x\n", __func__, val);

	dd->reg_offset = val;
	return count;
}

static DEVICE_ATTR(read_reg, (S_IWUSR | S_IRUGO), read_dump_reg, read_set_reg);


static ssize_t write_reg(struct device *dev, struct device_attribute *attr, 
				const char *buf, size_t count)
{
	unsigned long to;
	struct pci_dev *pdev;
	struct driver_data *dd = NULL;
	u32 reg = 0, val = 0, valid = 0;

	pdev = to_pci_dev(dev);
	if (pdev)
		dd = pci_get_drvdata(pdev);

	if (!dd) {
		pr_err(MTIP_DRV_NAME "%s: unable to get drive data\n", 
								__func__);
		return -EFAULT;
	}

	if (!dd->ioio) {
		mtip_printk(MTIP_PCI, MTIP_WARNING, dd,
			"%s: iobar not setup for register access, trying booting with 'pci=nocrs'\n",
			__func__);
		return -EFAULT;
	}

	if (sscanf(buf, "%x:%x", &reg, &val) < 0) {
		mtip_printk(MTIP_PCI, MTIP_DEBUG, dd, 
			"%s: Bad input\n", __func__);
		return -EINVAL;
	}

	iowrite32(val, dd->ioio + 0xc);
	wmb();
	iowrite32(reg, dd->ioio + 0x8);

	to = jiffies + msecs_to_jiffies(5000);
	valid = 0;
	do {
		if (ioread32(dd->ioio + 0x8) & (1 << 13)) {
			val = ioread32(dd->ioio + 0xc);
			valid = 1;
			break;
		}
		msleep(1);
	} while (time_before(jiffies, to));

	if (valid)
		return count;
	else
		return -EFAULT;
}

static DEVICE_ATTR(write_reg, S_IWUSR, NULL, write_reg);

/**
 * Cleanup pci sysfs entries.
 *
 * @return None 
 */
void cleanup_pci_sysfs(struct driver_data *dd)
{
	struct pci_dev *pdev;
	struct kobject *kobj;

	if (!dd->pci_sysfs)
		return;

	pdev = dd->pdev;

	kobj = kobject_get(&pdev->dev.kobj);
	if (!kobj)
		return;

	sysfs_remove_file(kobj, &dev_attr_read_reg.attr);
	sysfs_remove_file(kobj, &dev_attr_write_reg.attr);

	kobject_put(kobj);
}

/**
 * Initialize pci subsystem sysfs entries.
 *
 * @return None 
 */
void init_pci_sysfs(struct driver_data *dd)
{
	struct pci_dev *pdev;
	struct kobject *kobj;

	if (dd->pci_sysfs)
		return;

	pdev = dd->pdev;

	kobj = kobject_get(&pdev->dev.kobj);
	if (!kobj)
		return;

	if (sysfs_create_file(kobj, &dev_attr_read_reg.attr)) {
		mtip_printk(((MTIP_PCI | MTIP_INIT)), MTIP_ERR, dd,
			"%s: Error creating read_reg sysfs attribute\n", 
			__func__);
		goto pci_sysfs_cleanup;
	}

	if (sysfs_create_file(kobj, &dev_attr_write_reg.attr)) {
		mtip_printk(((MTIP_PCI | MTIP_INIT)), MTIP_ERR, dd,
			"%s: Error creating write_reg sysfs attribute\n", 
			__func__);
		sysfs_remove_file(kobj, &dev_attr_read_reg.attr);
		goto pci_sysfs_cleanup;
	}
	dd->pci_sysfs = 1;

pci_sysfs_cleanup:
	kobject_put(kobj);
}

static ssize_t store_logging_verbosity(struct device_driver *dev,
					const char *buf, size_t count)
{
	int i, value = 0;

	sscanf(buf, "%d", &value);
	value &= MTIP_LOG_ALL;
	if (__get_cpu_var(pcpu_verbosity) != value) {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32)
		pr_warn(MTIP_DRV_NAME " User changed verbosity: %08x -> %08x\n",
			__get_cpu_var(pcpu_verbosity), value);
#else
		pr_info(MTIP_DRV_NAME " User changed verbosity: %08x -> %08x\n",
			__get_cpu_var(pcpu_verbosity), value);
#endif
	}
	
	for_each_possible_cpu(i)
		per_cpu(pcpu_verbosity, i) = value;
	
	return count;
}

static ssize_t store_logging_subsys(struct device_driver *dev,
					const char *buf, size_t count)
{
	int i, value = 0;
	
	sscanf(buf, "%d", &value);
	value &= MTIP_MOD_ALL;
	if (__get_cpu_var(pcpu_log_subsys) != value) {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6,32)
		pr_warn(MTIP_DRV_NAME " User changed log level: %08x -> %08x\n",
			__get_cpu_var(pcpu_log_subsys), value);
#else
		pr_info(MTIP_DRV_NAME " User changed log level: %08x -> %08x\n",
			__get_cpu_var(pcpu_log_subsys), value);
#endif
	}
	
	for_each_possible_cpu(i)
		per_cpu(pcpu_log_subsys, i) = value;
	
	return count;
}

static ssize_t show_logging_verbosity(struct device_driver *dev, char *buf)
{
	int count = 0;
	u32 verbosity = __get_cpu_var(pcpu_verbosity);

	count += sprintf(&buf[count], "%d [%08x]", verbosity, verbosity);
	if (!verbosity) {
		count += sprintf(&buf[count], "\n");
		return count;
	} else {
		count += sprintf(&buf[count], " => ");
	}

	if (verbosity & MTIP_ERR)
		count += sprintf(&buf[count], " Error");
	if (verbosity & MTIP_WARNING)
		count += sprintf(&buf[count], " Warning");
	if (verbosity & MTIP_INFO)
		count += sprintf(&buf[count], " Info");
	if (verbosity & MTIP_DEBUG)
		count += sprintf(&buf[count], " Debug");
	count += sprintf(&buf[count], "\n");

	return count;
}

static ssize_t show_logging_subsys(struct device_driver *dev, char *buf)
{
	int count = 0;
	u32 log_subsys = __get_cpu_var(pcpu_log_subsys);

	count += sprintf(&buf[count], "%d [%08x]", log_subsys, log_subsys);

	if (!log_subsys) {
		count += sprintf(&buf[count], "\n");
		return count;
	} else {
		count += sprintf(&buf[count], " => ");
	}

	if (log_subsys & MTIP_INIT)
		count += sprintf(&buf[count], " Initialization");
	if (log_subsys & MTIP_PCI)
		count += sprintf(&buf[count], " PCI");
	if (log_subsys & MTIP_BLOCK)
		count += sprintf(&buf[count], " Block");
	if (log_subsys & MTIP_AHCI)
		count += sprintf(&buf[count], " AHCI");
	if (log_subsys & MTIP_HOTPLUG)
		count += sprintf(&buf[count], " Hotplug");
	if (log_subsys & MTIP_NCQ)
		count += sprintf(&buf[count], " NCQ");
	if (log_subsys & MTIP_NONNCQ)
		count += sprintf(&buf[count], " Non-NCQ");

	count += sprintf(&buf[count], "\n");

	return count;
}

/* 
 * TODO: Need to make sure we don't write more than PAGE_SIZE - 1 
 *       bytes to *buf.  This could happen if there are *lots* of
 *       drives.                   
 */
#define MTIP_ID_BUF_SZ 42
static ssize_t show_device_status(struct device_driver *drv, char *buf)
{
	int i, size = 0;
	struct driver_data *dd, *tmp;
	unsigned long flags;
	char id_buf[MTIP_ID_BUF_SZ];
	u16 status = 0;

	if (!buf)
		return -EINVAL;

	spin_lock_irqsave(&dev_lock, flags);
	size += sprintf(&buf[size], "Devices Present: \n");
	list_for_each_entry_safe(dd, tmp, &online_list, online_list) {
		memset(id_buf, 0, MTIP_ID_BUF_SZ);
		if (dd && dd->pdev) {
			if (dd->port && 
			    dd->port->identify && 
			    dd->port->identify_valid) {
				strlcpy(id_buf, 
					(char *) (dd->port->identify + 10), 21);
				status = *(dd->port->identify + 141);
				for (i = 0; i < 21; i++)
					if (!isalnum(id_buf[i]))
						id_buf[i] = '\0';
			} else
				status = 0;
			
			if (dd->port && 
			    mtip_test_bit(MTIP_DDF_REBUILD_BIT, 
							dd->flags)) {
				size += sprintf(&buf[size],
					" device %s %s (ftl rebuild %d %%)\n",
					DEV_NAME(dd),
					id_buf,
					status);
			} else {
				size += sprintf(&buf[size],
					" device %s %s\n",
					DEV_NAME(dd),
					id_buf);
			}
		}
	}

	size += sprintf(&buf[size], "Devices Being Removed: \n");
	list_for_each_entry_safe(dd, tmp, &removing_list, remove_list) {
		memset(id_buf, 0, MTIP_ID_BUF_SZ);
		if (dd && dd->pdev) {
			if (dd->port &&
			    dd->port->identify &&
			    dd->port->identify_valid) {
				strlcpy(id_buf,
					(char *) (dd->port->identify + 10), 21);
				status = *(dd->port->identify + 141);
				for (i = 0; i < 21; i++)
					if (!isalnum(id_buf[i]))
						id_buf[i] = '\0';
			} else
				status = 0;

			if (dd->port &&
			    mtip_test_bit(MTIP_DDF_REBUILD_BIT, 
							dd->flags)) {
				size += sprintf(&buf[size],
					" device %s %s (ftl rebuild %d %%)\n",
					DEV_NAME(dd),
					id_buf,
					status);
			} else {
				size += sprintf(&buf[size], 
					" device %s %s\n", 
					DEV_NAME(dd), 
					id_buf);
			}
		}
	}
	spin_unlock_irqrestore(&dev_lock, flags);
	
	return size;
}

static ssize_t store_debug_mode(struct device_driver *dev, const char *buf, 
					size_t count)
{
	int i, tmp;
	
	sscanf(buf, "%d", &tmp);
	if (tmp > 0 && tmp < MTIP_DBG_MODE_MAX) {
		for_each_possible_cpu(i)
			per_cpu(pcpu_debug_mode, i) = tmp;
		return count;
	}
	return -EINVAL;
}

static const char *stringify_debug_mode(int mode)
{
	switch (mode) {
	case MTIP_DBG_MODE_NONE:
		return "NONE";
	case MTIP_DBG_MODE_HALT:
		return "HALT";
	case MTIP_DBG_MODE_QUIESCE:
		return "QUIESCE";
	default:
		return "UNKNOWN";
	}
}

static ssize_t show_debug_mode(struct device_driver *dev, char *buf)
{
	return sprintf(&buf[0], "%d (%s)\n", 
		__get_cpu_var(pcpu_debug_mode), 
		stringify_debug_mode(__get_cpu_var(pcpu_debug_mode)));
}

static ssize_t store_force_fua(struct device_driver *dev, const char *buf, 
								size_t count)
{
	int i, tmp;
	
	sscanf(buf, "%d", &tmp);
	if (tmp < 0)
		return -EINVAL;
	if (tmp > 0)
		tmp = 1;

	for_each_possible_cpu(i)
		per_cpu(pcpu_force_fua, i) = tmp;

	return count;
}

static ssize_t show_force_fua(struct device_driver *dev, char *buf)
{
	return sprintf(&buf[0], "%d\n", __get_cpu_var(pcpu_force_fua));
}

static inline struct pci_dev *iterate_px20_devices(struct pci_dev *pdev)
{
	struct pci_dev *p, *s = pdev;

	if (s) {
		switch (s->device) {
		case P320H_DEVICE_ID:
			goto query_p320h;
		case P320S_DEVICE_ID:
			goto query_p320s;
		case P322H_DEVICE_ID:
			goto query_p322h;
		case P325M_DEVICE_ID:
			goto query_p325m;
		case P420H_DEVICE_ID:
			goto query_p420h;
		case P420M_DEVICE_ID:
			goto query_p420m;
		case P425M_DEVICE_ID:
			goto query_p425m;
		}
	}

query_p320h:
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P320H_DEVICE_ID, s);
	if (p)
		return p;
	s = NULL;

query_p320s:
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P320S_DEVICE_ID, s);
	if (p)
		return p;
	s = NULL;

query_p322h:
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P322H_DEVICE_ID, s);
	if (p)
		return p;

query_p325m:
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P325M_DEVICE_ID, s);
	if (p)
		return p;

query_p420h:
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P420H_DEVICE_ID, s);
	if (p)
		return p;

query_p420m:			
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P420M_DEVICE_ID, s);
	if (p)
		return p;

query_p425m:			
	p = pci_get_device(PCI_VENDOR_ID_MICRON, P425M_DEVICE_ID, s);
	if (p)
		return p;

	return NULL;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
void reinit_device(struct work_struct *work)
{
	struct mtip_work *w = (struct mtip_work *) work;
	struct mtip_port *port = w->port;
#else
void reinit_device(void *arg)
{
	struct mtip_port *port = (struct mtip_port *) arg;
#endif
	struct driver_data *dd = port->dd;
	int cardid = dd->instance;
	struct pci_dev *pdev = dd->pdev;
	const struct pci_device_id *pent = dd->pent;

	/* Rebind */
	pr_info(MTIP_DRV_NAME " Removing device bindings for %s ...\n",
							dd->disk->disk_name);
	mtip_pci_remove(pdev);

	pr_info(MTIP_DRV_NAME " Rebinding device node %d ...\n", new_binding);
	mtip_init_device(pdev, pent, new_binding, cardid);

	/* Complete */
	complete(&rebind_comp);
}

static ssize_t rebind_numa(struct device_driver *dev, const char *buf, 
								size_t count)
{
	char device[32];
	char node[32];
	int i, rv = 0, max_node = 0, cardid, cpu, found, new = 0;
	struct pci_dev *pdev = NULL;
	const struct pci_device_id *pent = NULL;
	struct driver_data *dd = NULL;
	struct workqueue_struct *rebind_wq = NULL;
	struct mtip_work worker;

	memset(node, 0, 32);
	memset(device, 0, 32);
	memset(&worker, 0, sizeof(struct mtip_work));

	/* Scan in the inputted value */
	for (i = 0, found = 0; i < count; i++) {
		if (buf[i] == ':' && i < 32) {
			memcpy(device, buf, i);
			memcpy(node, &buf[i+1], (count - (i + 1)) < 32 ? 
							(count - (i + 1)): 32);
			found = 1;
			break;
		}
	}
	if (!found)
		return -EINVAL;

	if (sscanf(node, "%u", &new) != 1)
		return -EINVAL;

	for_each_online_cpu(cpu) {
		if (cpu_to_node(cpu) > max_node)
			max_node++;
	}

	if (new > max_node)
		return -EINVAL;

	mutex_lock(&rebind_mutex);
	new_binding = new;
	init_completion(&rebind_comp);

	found = 0;
	while ((pdev = iterate_px20_devices(pdev))) {
		dd = pci_get_drvdata(pdev);
		if (dd && dd->port && dd->disk && dd->disk->disk_name) {
			if (strncmp(dd->disk->disk_name, device, 6) == 0) {
				pent = dd->pent;
				cardid = dd->instance;
				found = 1;
				break;
			}
		}
	}
	/* pdev points to matched struct pci_dev */

	if (!found) {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 32)
		pr_warn(MTIP_DRV_NAME " Device %s not found.\n", device);
#else
		pr_info(MTIP_DRV_NAME " Device %s not found.\n", device);
#endif
		rv = -EINVAL;
		goto rebind_err;
	}

	pr_info(MTIP_DRV_NAME " Request to rebind %s to %d ...\n", 
							device, new_binding);

	if (dd && atomic_read(&dd->refcount)) {
		pr_err(MTIP_DRV_NAME " Failing to rebind due to non-zero refcount on device %s (refcount %d)\n", 
			device, atomic_read(&dd->refcount));
		rv = -EFAULT;
		goto rebind_err;
	}

	rebind_wq = create_workqueue("rebind_wq");
	if (!rebind_wq) {
		pr_err(MTIP_DRV_NAME " Error creating rebind workqueue.\n");
		rv = -EFAULT;
		goto rebind_err;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29) 
	INIT_WORK((struct work_struct *) &worker, reinit_device);
	cpu = cpumask_first(cpumask_of_node(new_binding));
	worker.port = dd->port;
	queue_work_on(cpu, rebind_wq, (struct work_struct *) &worker);
#else
	INIT_WORK((struct work_struct *) &worker, reinit_device, (void *) dd->port);
	for_each_online_cpu(cpu) {
		if (cpu_to_node(cpu) == new_binding)
			break;
	}
	worker.port = dd->port;
	queue_work(rebind_wq, (struct work_struct *) &worker);
#endif

	rv = wait_for_completion_interruptible_timeout(&rebind_comp, REBIND_TIMEOUT * HZ);
	if (rv <= 0) {
		if (rv == -ERESTARTSYS) /* interrupted */
			pr_err(MTIP_DRV_NAME " Rebinding interrupted.\n");

		if (rv == 0) {
			pr_err(MTIP_DRV_NAME " Rebinding timed out.\n");
			rv = -ETIMEDOUT;
		}
		goto rebind_err;
	}

	rv = count;

rebind_err:
	mutex_unlock(&rebind_mutex);

	if (rebind_wq) {
		flush_workqueue(rebind_wq);
		destroy_workqueue(rebind_wq);
		rebind_wq = NULL;
	}

	return rv;
}

static ssize_t show_numa_bindings(struct device_driver *dev, char *buf)
{
	int count = 0;
	struct driver_data *dd;
	struct pci_dev *pdev = NULL;

	while ((pdev = iterate_px20_devices(pdev))) {
		dd = pci_get_drvdata(pdev);
		if (dd && dd->port) {
			if (dd->disk && dd->disk->disk_name)
				count += sprintf(&buf[count], "%s: %d\n", 
					dd->disk->disk_name, dd->numa_node);
			else
				count += sprintf(&buf[count], 
					"<initializing>: %d\n", dd->numa_node);
		}
	}
	return count;
}

static DRIVER_ATTR(verbosity, (S_IWUSR | S_IRUGO),
		show_logging_verbosity, store_logging_verbosity);
static DRIVER_ATTR(log_subsys, (S_IWUSR | S_IRUGO),
		show_logging_subsys, store_logging_subsys);
static DRIVER_ATTR(device_status, S_IRUGO, show_device_status, NULL);
static DRIVER_ATTR(debug_mode, (S_IWUSR | S_IRUGO), 
		show_debug_mode, store_debug_mode);
static DRIVER_ATTR(force_fua, (S_IWUSR | S_IRUGO), 
		show_force_fua, store_force_fua);
static DRIVER_ATTR(numa_bindings, (S_IWUSR | S_IRUGO), 
		show_numa_bindings, rebind_numa);

int mtip_create_driver_sysfs(struct pci_driver *mtip_pci_driver)
{
	int error = 0;

	error = driver_create_file(&mtip_pci_driver->driver,
					&driver_attr_verbosity);
	error |= driver_create_file(&mtip_pci_driver->driver,
					&driver_attr_log_subsys);
	error |= driver_create_file(&mtip_pci_driver->driver, 
					&driver_attr_device_status);
	error |= driver_create_file(&mtip_pci_driver->driver, 
					&driver_attr_debug_mode);
	error |= driver_create_file(&mtip_pci_driver->driver, 
					&driver_attr_force_fua);
	error |= driver_create_file(&mtip_pci_driver->driver, 
					&driver_attr_numa_bindings);

	return error;
}

void mtip_remove_driver_sysfs(struct pci_driver *mtip_pci_driver)
{

	driver_remove_file(&mtip_pci_driver->driver,
					&driver_attr_verbosity);
	driver_remove_file(&mtip_pci_driver->driver,
					&driver_attr_log_subsys);
	driver_remove_file(&mtip_pci_driver->driver, 
					&driver_attr_device_status);
	driver_remove_file(&mtip_pci_driver->driver, 
					&driver_attr_debug_mode);
	driver_remove_file(&mtip_pci_driver->driver, 
					&driver_attr_force_fua);
	driver_remove_file(&mtip_pci_driver->driver, 
					&driver_attr_numa_bindings);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
static ssize_t mtip_show_bindings(struct device *dev, 
				struct device_attribute *attr, char *buf)
#else
static ssize_t mtip_show_bindings(struct gendisk *disk, char *buf)
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
	struct driver_data *dd = dev_to_disk(dev)->private_data;
#else
	struct driver_data *dd = disk->private_data;
#endif
	int i, j = 0, cpu, size = 0;
	char cpu_list[256];

	memset(cpu_list, 0, sizeof(cpu_list));

	for_each_online_cpu(cpu) {
		if (cpu_to_node(cpu) == dd->numa_node) {
			snprintf(&cpu_list[j], 256 - j, "%d ", cpu);
			j = strlen(cpu_list);
		}
	}

	size += sprintf(&buf[size], "Node: %d (on package %d)\n",
		dd->numa_node, topology_physical_package_id(dd->isr_binding));
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	size += sprintf(&buf[size], "PCI device closest to node %d\n",
		pcibus_to_node(dd->pdev->bus));
	size += sprintf(&buf[size], "Device memory on node %d\n",
		dev_to_node(&dd->pdev->dev));
#endif
	size += sprintf(&buf[size], "Cores: %s\n", cpu_list);
	size += sprintf(&buf[size], "IRQ: %d\n", dd->isr_binding);
	for (i = 0; i < MTIP_MAX_SLOT_GROUPS; i++) {
		size += sprintf(&buf[size], "wq%d: %d\n", i, 
						dd->work[i].cpu_binding);
	}
	return size;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
static DEVICE_ATTR(numa, S_IRUGO, mtip_show_bindings, NULL);
#else
static struct disk_attribute dev_attr_numa = {
	/* filename, owner, attributes */
	.attr  = { "numa", THIS_MODULE, S_IRUGO },
	.show  = mtip_show_bindings,
	.store = NULL
};
#endif

#ifdef MTIP_DEBUGLOG
static void mtip_debuglog_sysfs_init(struct driver_data *dd, struct kobject *kobj);
static void mtip_debuglog_sysfs_destroy(struct driver_data *dd, struct kobject *kobj);
#endif

void mtip_extra_sysfs_init(struct driver_data *dd, struct kobject *kobj)
{
	if (!dd || !kobj)
		return;

	if (sysfs_create_file(kobj, &dev_attr_numa.attr))
		mtip_printk(MTIP_INIT, MTIP_WARNING, dd,
			"Error creating 'numa' sysfs entry.\n");
#ifdef MTIP_DEBUGLOG
	mtip_debuglog_sysfs_init(dd, kobj);
#endif
}

void mtip_extra_sysfs_destroy(struct driver_data *dd, struct kobject *kobj)
{
	if (dd && kobj)
		sysfs_remove_file(kobj, &dev_attr_numa.attr);

#ifdef MTIP_DEBUGLOG
	mtip_debuglog_sysfs_destroy(dd, kobj);
#endif	
}

static ssize_t mtip_debugfs_device_status(struct file *f, char __user *ubuf,
						size_t len, loff_t *offset)
{
	int size = *offset;
	char *buf;

	if (!len || *offset)
		return 0;
	
	buf = kzalloc(MTIP_DFS_MAX_BUF_SIZE, GFP_KERNEL);
	if (!buf)
		return -ENOMEM;

	size += show_device_status(NULL, buf);

	*offset = size <= len ? size : len;
	size = copy_to_user(ubuf, buf, *offset);
	kfree(buf);	

	if (size)
		return -EFAULT;

	return *offset;
}

static const struct file_operations device_status_fops = {
	.owner  = THIS_MODULE,
	.open   = mtip_simple_open,
	.read   = mtip_debugfs_device_status,
	.llseek = no_llseek,
};

void mtip_extra_init(struct dentry *dfs_parent)
{
	int i;
	for_each_possible_cpu(i) {
		per_cpu(pcpu_verbosity, i) = MTIP_LOG_DEFAULT;
		per_cpu(pcpu_log_subsys, i) = MTIP_MOD_DEFAULT;
		per_cpu(pcpu_debug_mode, i) = MTIP_DBG_MODE_NONE;
		per_cpu(pcpu_force_fua, i) = 0;
		per_cpu(pcpu_stats, i) = stats;
	}

	spin_lock_init(&dev_lock);
	spin_lock_init(&orphan_lock);

	INIT_LIST_HEAD(&online_list);
	INIT_LIST_HEAD(&orphan_list);
	INIT_LIST_HEAD(&removing_list);

	mutex_init(&rebind_mutex);

	dfs_device_status = debugfs_create_file("device_status", S_IRUGO,
					dfs_parent, NULL, &device_status_fops); 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32) && \
	(!defined(CONFIG_SUSE_KERNEL))
	if (IS_ERR_OR_NULL(dfs_device_status)) {
#else
	if (!dfs_device_status) {
#endif
		pr_err(MTIP_DRV_NAME " %s: Error creating 'device_status' node under debugfs\n",
								__func__);
		dfs_device_status = NULL;
	}
}

void mtip_extra_destroy(struct dentry *dfs_parent)
{
	if (dfs_device_status)
		debugfs_remove(dfs_device_status);
	dfs_device_status = NULL;
}

/**
 * This function is to collect the AHCI memory register, port register
 * and PCI Configuration for debug purpose.
 */

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 31)
static long math_div(long a, long b)
{
	return a / b - (a % b < 0);
}

static long leaps_between(long y1, long y2)
{
	long leaps1 = math_div(y1 - 1, 4) - math_div(y1 - 1, 100)
		+ math_div(y1 - 1, 400);
	long leaps2 = math_div(y2 - 1, 4) - math_div(y2 - 1, 100)
		+ math_div(y2 - 1, 400);
	return leaps2 - leaps1;
}

static const unsigned short int __mon_yday[2][13] = {
	{ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 },
	/* Leap years.  */
	{ 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 }
};

static int __isleap(long year)
{
	return (year) % 4 == 0 && ((year) % 100 != 0 || (year) % 400 == 0);
}

#endif

void mtip_collecttime(struct driver_data *dd, struct os_calendar_time *time)
{
	struct timeval tv;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 31)
	long days, rem, y;
	const unsigned short *ip;
	time_t totalsecs;
	do_gettimeofday(&tv);
	totalsecs = tv.tv_sec;
	days = totalsecs / SECS_PER_DAY;
	rem = totalsecs % SECS_PER_DAY;

	while (rem < 0) {
		rem += SECS_PER_DAY;
		--days;
	}

	while (rem >= SECS_PER_DAY) {
		rem -= SECS_PER_DAY;
		++days;
	}

	time->hour = rem / SECS_PER_HOUR;
	rem %= SECS_PER_HOUR;
	time->min =  (u8) (rem / 60);
	time->sec = (u8) (rem % 60);
	y = 1970;

	while (days < 0 || days >= (__isleap(y) ? 366 : 365)) {
		/* Guess a corrected year, assuming 365 days per year. */
		long yg = y + math_div(days, 365);

		/* Adjust DAYS and Y to match the guessed year. */
		days -= (yg - y) * 365 + leaps_between(y, yg);
		y = yg;
	}

	time->year = (u16) (y);
	ip = __mon_yday[__isleap(y)];

	for (y = 11; days < ip[y]; y--)
		continue;
	days -= ip[y];

	time->mon = (u8) (y + 1);
	time->mday = (u8) (days + 1);
#else
	struct tm tms;

	memset(time, 0, sizeof(struct os_calendar_time));
	do_gettimeofday(&tv);

	time_to_tm(tv.tv_sec, 0 , &tms);
	time->year = (u16) (1900 + tms.tm_year);
	time->mon  = (u8) (1 + tms.tm_mon);
	time->mday = (u8) tms.tm_mday;
	time->hour = (u8) tms.tm_hour;
	time->min  = (u8) tms.tm_min;
	time->sec  = (u8) tms.tm_sec;
#endif

}

void mtip_getdebugheader(struct driver_data *dd,
			struct dd_debug_data_header *header_data)
{
	struct os_calendar_time time;

	if (dd) {
		mtip_collecttime(dd, &time);
		header_data->major_version = DEBUG_DATA_MAJOR_VER;
		header_data->minor_version = DEBUG_DATA_MINOR_VER;
		header_data->data_length = sizeof(dd->first_error_state);
		header_data->month = time.mon;
		header_data->date  = time.mday;
		header_data->year  = time.year;
		header_data->hour  = time.hour;
		header_data->min   = time.min;
		header_data->sec   = time.sec;
	}
}

void mtip_getahciregs(struct driver_data *dd, struct dd_ahci_mem_reg *mem_reg)
{
	if (dd && dd->port) {
		memset(mem_reg, 0, sizeof(struct dd_ahci_mem_reg));

		/* 
		 * port register information collection
		 * This is buggy - registers end up at wrong offsets
		 * should use structure definition dd_ahci_mem_reg_internal
		 * instead
		 */
		memcpy(mem_reg, dd->mmio, sizeof(struct dd_ahci_mem_reg));
	}
}

void mtip_getahciid(struct driver_data *dd, struct dd_hba_id *hba_id)
{
	if (dd && dd->port && dd->port->identify_valid) {
		memset(hba_id, 0, sizeof(struct dd_hba_id));
		memcpy(hba_id->id_string,
			(unsigned char *) (dd->port->identify + 10), 21);
		memcpy(hba_id->fw_version,
			(unsigned char *) (dd->port->identify + 23), 8);
		memcpy(hba_id->model,
			(unsigned char *) (dd->port->identify + 27), 41);
	}
}

void mtip_getahcipci(struct driver_data *dd, struct dd_pci_config *pciconfig)
{
	u8 pcibuf[512], pcicap[20], pcipwr[8];
	int i, j;

	if (!dd || !dd->port)
		return;

	for (i = 0; i < 512; i++)
		pci_read_config_byte(dd->pdev, i , &pcibuf[i]);
		
	memcpy(pciconfig, pcibuf, sizeof(pcibuf));

	for (i = 0, j = pciconfig->cap; i < 20; i++)
		pci_read_config_byte(dd->pdev, j + i, &pcicap[i]);

	memcpy(&pciconfig->pcie_cap, pcicap, sizeof(struct pcie_capability));

	for (i = 0, j = pciconfig->pcie_cap.nextcapptr; i < 8; i++)
		pci_read_config_byte(dd->pdev, j + i , &pcipwr[i]);

	memcpy(&pciconfig->pcie_pwrmgt, pcipwr,
				sizeof(struct pcie_pwrmgt_capability));
}

void mtip_getahcimemreg(struct driver_data *dd,
			struct dd_ahci_mem_structure *ahci_mem)
{
	int i, j;

	if (!dd || !dd->port)
		return;

	/* Skip collecting this for now as its broken and useless */
	return;

	memset(ahci_mem, 0, sizeof(struct dd_ahci_mem_structure));

	/* For some reason, we don't collect RX Fis bytes */
	memcpy(&ahci_mem->received_fis, dd->port->rxfis,
					sizeof(struct dd_ahci_received_fis));

	for (i = 0, ahci_mem->cnt = 0;
	     i < (MTIP_MAX_COMMAND_SLOTS < 256 ? MTIP_MAX_COMMAND_SLOTS : 256);
	     i++) {
		memcpy(&ahci_mem->cmd_list[ahci_mem->cnt].di,
			dd->port->command_list + (sizeof(struct mtip_cmd_hdr) *
								ahci_mem->cnt),
			sizeof(struct dd_ahci_cmd_hdr_desc_info));

		memcpy(&ahci_mem->cmd_list[ahci_mem->cnt].cfis,
			dd->port->commands[ahci_mem->cnt].command,
			sizeof(struct dd_ahci_h2d_register_fis));

		/* assign PRD byte count */
		ahci_mem->cmd_list[ahci_mem->cnt].prd_byte_cnt =
			dd->port->commands[ahci_mem->cnt].command_header->byte_count;
		
		/* Debug Data spec says to collect only first 33 PRDT entries?? */
		for (j = 0; j < 33; j++) {
			memcpy((&ahci_mem->cmd_list[ahci_mem->cnt].prdt[j]),
				((char *) dd->port->commands[ahci_mem->cnt].command
					+ 0x80 + (sizeof(struct dd_cmd_prdt_info) * j)),
				sizeof(struct dd_cmd_prdt_info));
		}
		ahci_mem->cnt++;
	}
}

int mtip_getdebugioctl(struct driver_data *dd,
	struct host_to_dev_fis *fis, ide_task_request_t *req_task,
	u8 *outbuf, u32 buflen)
{
	struct dd_debug_data_header header_data;
	struct dd_driver_debug_data *driver_data = NULL;
	struct dd_request_info req_info;
	u8 *pbuf = outbuf;

	/* Sanity check params */
	if (!outbuf || !buflen)
		return -EINVAL;

	req_task->io_ports[1] = DEBUG_SUCCESS;

	switch (fis->sect_count) {
	case REQUEST_INFO:
		mtip_getdebugheader(dd, &header_data);
		req_info.debug_data_size =
			sizeof(struct dd_driver_debug_data);
		memcpy(pbuf, &req_info,
			sizeof(struct dd_request_info));
		break;
	case RESET_DEBUG_DATA:
		memset(&driver_data, 0, sizeof(driver_data));
		memset(&dd->first_error_state, 0,
			sizeof(struct dd_driver_debug_data));
		memset(&dd->last_error_state, 0,
			sizeof(struct dd_driver_debug_data));
		dd->first_error_flag = 0;
		break;
	case GET_DEBUG_DATA:
		switch (fis->cyl_hi) {
		case RETRIEVE_FIRST_ERROR_DATA:
			driver_data = &dd->first_error_state;
			break;
		case RETRIEVE_LAST_ERROR_DATA:
			driver_data = &dd->last_error_state;
			break;
		case RETRIEVE_CURRENT_DATA:
			/* we can call the function directly */
			mtip_getdebugdata(dd, &dd->current_state);
			driver_data = &dd->current_state;
			break;
		default:
			mtip_printk(MTIP_AHCI, MTIP_WARNING, dd,
				"%s: Unrecognized cylHi %d\n",
				__func__, fis->cyl_hi);
			break;
		}
		memcpy(pbuf, driver_data,
			sizeof(struct dd_driver_debug_data));
		break;
	case GET_EXT_DEBUG_DATA:
		req_task->io_ports[1] = 0x1;
		break;
	default:
		req_task->io_ports[1] = 0x1;
		mtip_printk(MTIP_AHCI, MTIP_INFO, dd,
			"%s: Unrecognized request %d\n",
			__func__, fis->sect_count);
		break;
	}

	req_task->io_ports[2] = fis->sect_count;
	req_task->io_ports[3] = fis->sector;
	req_task->io_ports[4] = fis->cyl_low;
	req_task->io_ports[5] = fis->cyl_hi;
	req_task->io_ports[6] = 0;
	req_task->io_ports[7] = DEBUG_STATUS;

	return 0;
}

void mtip_getdebugdata(struct driver_data *dd,
				struct dd_driver_debug_data *debugdata)
{
	mtip_getdebugheader(dd, &debugdata->debug_header);
	mtip_getahciid(dd, &debugdata->hba_id);
	mtip_getahciregs(dd, &debugdata->ahci_mem_registers);
	mtip_getahcimemreg(dd, &debugdata->ahci_mem_struct);
	mtip_getahcipci(dd, &debugdata->pci_config);
}

/*
 * TRIM entry point
 *
 * TRIM is implemented as a Vendor Unique command
 * 
 * Firmware indicates VU TRIM support by setting both
 * of the following bits in the identify structure:
 *      DRAT = 1 (Word 69, bit 14)
 *      RZAT = 1 (Word 69, bit 5)
 *
 */
int mtip_trim(struct driver_data *dd, u64 lba, u64 len)
{
	int i, rv = 0;
	u64 tlba, tlen, sect_left;
	struct vu_trim_entry *buf;
	dma_addr_t dma_addr;
	struct host_to_dev_fis fis;

	mtip_printk(MTIP_AHCI, MTIP_DEBUG, dd,
		"Trim request: %llu 512b sectors starting @ %llu\n", len, lba);

	if (len == 0)
		return -EINVAL;

	WARN_ON(!dd->trim_supp);

	WARN_ON(len > (MAX_VU_TRIM_ENTRY_LEN * MAX_VU_TRIM_ENTRIES));
	WARN_ON(len % 8 != 0);

	/* Allocate a 512b buffer but warn if vu_trim structure is too big */
	WARN_ON(sizeof(struct vu_trim) > ATA_SECT_SIZE);

	/* Allocate a DMA buffer for the command */
	buf = dmam_alloc_coherent(&dd->pdev->dev, ATA_SECT_SIZE, &dma_addr, 
						GFP_KERNEL);
	if (!buf) {
		mtip_printk(MTIP_AHCI, MTIP_ERR, dd,
			"Memory allocation failed (%d bytes).\n", ATA_SECT_SIZE);
		return -ENOMEM;
	}
	memset(buf, 0, ATA_SECT_SIZE);

	for (i = 0, sect_left = len, tlba = lba;
		i < MAX_VU_TRIM_ENTRIES && sect_left;
		i++) {
		tlen = (sect_left >= MAX_VU_TRIM_ENTRY_LEN ? 
					MAX_VU_TRIM_ENTRY_LEN :
					sect_left);

		buf[i].lba = (u32) tlba;
		buf[i].range = (u16) tlen;

		//printk("Trim[%d]: LBA: %016llx, len %016llx [%016llx]\n", 
		//		i, tlba, tlen, *((u64 *) &buf[i]));
                
		tlba += tlen;
		sect_left -= tlen;
	}
	WARN_ON(sect_left != 0);

	/* Build the fis */
	memset(&fis, 0, sizeof(struct host_to_dev_fis));
	fis.type       = 0x27;
	fis.opts       = 1 << 7;
	fis.command    = 0xFB;
	fis.features   = 0x60;
	fis.sect_count = 1; /* transfer only a single vu_trim structure */
	fis.device     = ATA_DEVICE_OBS;

	down_write(&dd->sync_sem);

	/* Execute the command */
	if (mtip_exec_internal_command(dd->port,
					&fis,
					5,
					dma_addr,
					ATA_SECT_SIZE,
					0,
					GFP_KERNEL,
					TRIM_TIMEOUT_MS) < 0) {
		mtip_printk(MTIP_AHCI, MTIP_WARNING, dd,
			"TRIM command did not execute succcessfully.\n");
		rv = -EIO;
	}

	up_write(&dd->sync_sem);

	dmam_free_coherent(&dd->pdev->dev, ATA_SECT_SIZE, buf, dma_addr);

	return rv;
}

#ifdef MTIP_DEBUGLOG

#include <linux/circ_buf.h>

#define MTIP_DBGLOG_SIZE          (4096 * 16)
#define MTIP_DBGLOG_ENTRY_SZ      (64)

static struct timespec start_tv;
static char empty_buf[MTIP_DBGLOG_ENTRY_SZ];

static int dbglog = 0;
module_param(dbglog, int, 0644);
MODULE_PARM_DESC(stats, "Enable (1) or disable (0) debug IO logging.");

extern int mtip_major;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
static ssize_t debuglog_show(struct device *dev, struct device_attribute *attr,
								char *buf)
#else
static ssize_t debuglog_show(struct gendisk *disk, char *buf)
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
	struct driver_data *dd = dev_to_disk(dev)->private_data;
#else
	struct driver_data *dd = disk->private_data;
#endif
	int len = 0, buf_len, ccnt;
	struct circ_buf *dbglog = &dd->debuglog;
	unsigned long flags;

	if (!dbglog->buf)
                return 0;

        spin_lock_irqsave(&dd->debuglog_lock, flags);

	/* Spit back 4k chunks at most */
	len = 0;
	buf_len = (PAGE_SIZE) - 1;

	while (len < buf_len) 
	{
		ccnt = CIRC_CNT_TO_END(dbglog->head, dbglog->tail, 
						MTIP_DBGLOG_SIZE);
		if (!ccnt)
			break;

                if ((size_t) ccnt > buf_len - len)
                        ccnt = buf_len - len;

                memcpy(buf + len, &dbglog->buf[dbglog->tail], ccnt);
                len += ccnt;

                dbglog->tail = (dbglog->tail + ccnt) & 
					(MTIP_DBGLOG_SIZE - 1);
        }
	
	spin_unlock_irqrestore(&dd->debuglog_lock, flags);
        
	return len;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) 
static DEVICE_ATTR(debuglog, S_IRUGO, debuglog_show, NULL);
#else
static struct disk_attribute dev_attr_debuglog = {
	/* filename, owner, attributes */
	.attr  = { "debuglog", THIS_MODULE, S_IRUGO },
	.show  = debuglog_show,
	.store = NULL
};
#endif

/* Init function */
int debuglog_init(struct driver_data *dd)
{
	if (dbglog) {
		spin_lock_init(&dd->debuglog_lock);

		getnstimeofday(&start_tv);
		memset(empty_buf, ' ', MTIP_DBGLOG_ENTRY_SZ);

		dd->debuglog.buf = vmalloc_node(MTIP_DBGLOG_SIZE, 
							dd->numa_node);
		if (dd->debuglog.buf == NULL)
			return -ENOMEM;
		dd->debuglog.head = 0;
		dd->debuglog.tail = 0;
	}

	return 0;
}

/* Teardown function */
void debuglog_destroy(struct driver_data *dd)
{
	if (dd->debuglog.buf)
		vfree(dd->debuglog.buf);
	dd->debuglog.buf = NULL;
}

int debuglog_add(struct driver_data *dd, const void *buf, size_t buf_len)
{
	struct circ_buf *dbglog = &dd->debuglog;
	size_t space;
	int i;
	unsigned long flags;

	if (!dbglog->buf)
		return 0;

	if (WARN_ON(buf_len != MTIP_DBGLOG_ENTRY_SZ))
		return -EINVAL;

	spin_lock_irqsave(&dd->debuglog_lock, flags);
	
	space = CIRC_SPACE(dbglog->head, dbglog->tail, MTIP_DBGLOG_SIZE);
        if (space < buf_len) {
                /* discard oldest slot */
                dbglog->tail = (dbglog->tail + MTIP_DBGLOG_ENTRY_SZ) & 
						(MTIP_DBGLOG_SIZE - 1);
		BUG_ON(dbglog->tail > MTIP_DBGLOG_SIZE);
	}

        for (i = 0; i < buf_len; i += space) {
                space = CIRC_SPACE_TO_END(dbglog->head, dbglog->tail, 
						MTIP_DBGLOG_SIZE);

                if ((size_t) space > buf_len - i)
                        space = buf_len - i;

                memcpy(&dbglog->buf[dbglog->head], buf, space);
                dbglog->head = (dbglog->head + space) & 
					(MTIP_DBGLOG_SIZE - 1);
		BUG_ON(dbglog->head > MTIP_DBGLOG_SIZE);
        }

	spin_unlock_irqrestore(&dd->debuglog_lock, flags);
	
	return 0;
}

void debuglog_io_queued(struct driver_data *dd, u32 dir, sector_t sector, 
							int len, u32 flags)
{
	char buf[MTIP_DBGLOG_ENTRY_SZ];
	struct timespec tv;

	if (dd->debuglog.buf) {

		getnstimeofday(&tv);
	
		snprintf(&buf[0], MTIP_DBGLOG_ENTRY_SZ,
			"%3d %2d %5lu.%09lu %5d Q %s%s %lu + %d [%s] %s",
			mtip_major, smp_processor_id(), 
			tv.tv_sec - start_tv.tv_sec, tv.tv_nsec, 
			current->pid, dir == WRITE ? "W" : "R",
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36) || \
        ((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6   && \
         defined(RHEL_MINOR) && RHEL_MINOR != 0)) 
			flags & REQ_SYNC ? "S" : " ",
#else
			"",
#endif
			(unsigned long) sector, len, current->comm, empty_buf);
		buf[MTIP_DBGLOG_ENTRY_SZ - 1] = '\n';

		debuglog_add(dd, buf, MTIP_DBGLOG_ENTRY_SZ);
	}
}

void debuglog_io_start(struct driver_data *dd, struct mtip_cmd *cmd, u32 dir,
					sector_t sector, int len, u32 flags)
{
	if (dd->debuglog.buf) {
		char buf[MTIP_DBGLOG_ENTRY_SZ];
		getnstimeofday(&cmd->submit_tv);

		snprintf(&buf[0], MTIP_DBGLOG_ENTRY_SZ,
			"%3d %2d %5lu.%09lu %5d S %s%s %lu + %d [%s] %s",
			mtip_major, smp_processor_id(),
			cmd->submit_tv.tv_sec - start_tv.tv_sec,
			cmd->submit_tv.tv_nsec,
			current->pid, dir == WRITE ? "W" : "R",
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36) || \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6   && \
	 defined(RHEL_MINOR) && RHEL_MINOR != 0)) 
			flags & REQ_SYNC ? "S" : " ",
#else
			"",
#endif
			(unsigned long) sector, len, current->comm, empty_buf);
		buf[MTIP_DBGLOG_ENTRY_SZ - 1] = '\n';

		debuglog_add(dd, buf, MTIP_DBGLOG_ENTRY_SZ);
	}
}

/* 
 * In RHEL 5.x, timespec_sub references set_normalized_timespec, which is
 * defined in time.c.  External modules can't get access to the symbol so
 * we re-define it here.
 */
#if LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 18) && \
	(defined(RHEL_MAJOR) && RHEL_MAJOR == 5)
void set_normalized_timespec(struct timespec *ts, time_t sec, long nsec)
{
	while (nsec >= NSEC_PER_SEC) {
		nsec -= NSEC_PER_SEC;
		++sec;
	}
	while (nsec < 0) {
		nsec += NSEC_PER_SEC;
		--sec;
	}
	ts->tv_sec = sec;
	ts->tv_nsec = nsec;
}
#endif

void debuglog_io_complete(struct driver_data *dd, struct mtip_cmd *cmd, 
				u32 dir, sector_t sector, int len, u32 flags)
{
	if (dd->debuglog.buf) {
		char buf[MTIP_DBGLOG_ENTRY_SZ];
		struct timespec delta;
		getnstimeofday(&cmd->complete_tv);
		delta = timespec_sub(cmd->complete_tv, cmd->submit_tv);

		snprintf(&buf[0], MTIP_DBGLOG_ENTRY_SZ,
			"%3d %2d %5lu.%09lu %5d C %s%s %lu + %d %lu.%09lu %s",
			mtip_major, smp_processor_id(),
			cmd->complete_tv.tv_sec - start_tv.tv_sec,
			cmd->complete_tv.tv_nsec,
			current->pid, dir == WRITE ? "W" : "R",
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36) || \
	((defined(RHEL_MAJOR) && RHEL_MAJOR >= 6   && \
	 defined(RHEL_MINOR) && RHEL_MINOR != 0)) 
			flags & REQ_SYNC ? "S" : " ",
#else
			"",
#endif
			(unsigned long) sector, len,
			delta.tv_sec, delta.tv_nsec, empty_buf);
		buf[MTIP_DBGLOG_ENTRY_SZ - 1] = '\n';

		debuglog_add(dd, buf, MTIP_DBGLOG_ENTRY_SZ);
	}
}

static void mtip_debuglog_sysfs_init(struct driver_data *dd, struct kobject *kobj)
{
	if (!dd || !kobj)
		return;

	if (dbglog) {
		if (sysfs_create_file(kobj, &dev_attr_debuglog.attr)) {
			mtip_printk(MTIP_INIT, MTIP_WARNING, dd,
				"Error creating 'debuglog' sysfs entry.\n");
		} else 
			debuglog_init(dd);
	}
}

static void mtip_debuglog_sysfs_destroy(struct driver_data *dd, struct kobject *kobj)
{
	if (dd && kobj && dbglog) {
		sysfs_remove_file(kobj, &dev_attr_debuglog.attr);
		debuglog_destroy(dd);
	}
}

#endif /* #ifdef MTIP_DEBUGLOG */
